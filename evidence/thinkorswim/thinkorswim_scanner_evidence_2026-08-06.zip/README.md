# thinkorswim scanner evidence package - 2026-08-06

**Paper testing only. No demonstrated profitable edge.** Every reported confidence interval includes zero, and the historical universe has selection/survivorship bias.

## Operational configuration
- Use the split-stage scanner: fresh saved V3 confirmed universe, followed by the daily V4 confirmation/ATR stage. Do not run the whole-universe combined expression; it timed out live.
- Frozen daily settings: max ATR 4%, minimum confirmations 4/5, DAY aggregation, extended hours off.
- The previously live-compiled V4.2 chart study remains the fallback. V4.2.2 is the current experimental candidate and adds neutral no-flow MFI handling; it has not been live-compiled/applied.
- Current actionable sizing is fail-closed: actual entry and observed dollar spread/share are mandatory; cost/share is spread + expected slippage + fees. Risk is 0.50%, capital cap 20%, stop 1.5 prior-day ATR, whole shares only. Zero means skip.
- Optional V4.7 daily scan/quote and account-affordability scan/quote are separate experimental arms; do not overwrite or silently pool them with frozen V4.

## Install folders
- `install_current/frozen_core/`: seven frozen/last-live-proved scanner/alert scripts. Keep only its V4.2 alert study enabled for the fallback arm.
- `install_current/reference_only_do_not_install/`: superseded sizing reference retained for audit; do not install it.
- `install_current/candidates_not_live_verified/`: seven new candidates requiring thinkorswim compile/render proof. Do not enable its V4.2.2 alert study alongside V4.2.
- `scripts/`: full audit archive, including superseded revisions; it is not a paste-all install set.

## Evidence status
- Fourteen-script scoped static audit: 102/102 pass; nine bundled regression suites pass. Static checks are not thinkorswim compilation.
- V4.2 was previously compiled/rendered live and was the only enabled SAN alert study at the last proved checkpoint. V4.2.1/V4.2.2, revised sizing, affordability scripts, and spread quote still require live compile/render proof.
- The daily Score quote was repaired, compiled at DAY, saved, and reloaded 0-5 values in the active session. Restart persistence and a second extended-hours-off proof remain open.
- No genuine closed-bar Ring has been observed. Actual alert latency is therefore unknown.
- Intraday extended-hours display has not been proved off. Clock gating does not prevent extended-hours bars from contaminating indicator lookbacks.
- Historical selected-universe affordability produced zero whole-share V4 observations for a $100 account under frozen risk/cap rules. The affordability prefilter removes impossible names but does not create an edge.
- Point-in-time universe/market data remain missing, so unbiased OOS testing is incomplete.
- The V3 cohort included ETFs UGL and NVDL; product type is now a hard workflow gate. Historical ETF removal did not change the no-edge conclusion.
- The latest live UI access attempt detected thinkorswim but could not capture the disabled/minimized Watchlist; no settings were inferred from that failed attempt.
