# V4.1 intraday dashboard. Use only on 5m/15m regular-hours charts.
input mfiLength = 14;
input rsiLength = 14;
input bbLength = 20;
input bbStd = 2.0;
input alertOnVwapReclaim = yes;
input requireBoxBreakForConfirmation = yes;
input alertOnClosedBarConfirmation = yes;

def agg = GetAggregationPeriod();
def validAgg = agg == AggregationPeriod.FIVE_MIN or agg == AggregationPeriod.FIFTEEN_MIN;
def rth = SecondsFromTime(0930) >= 0 and SecondsTillTime(1600) > 0;
AddLabel(!validAgg, "WARNING: USE 5m OR 15m", Color.RED);

def vw = reference VWAP()."VWAP";
plot VWAPLine = vw;
VWAPLine.SetDefaultColor(Color.CYAN);
VWAPLine.SetLineWeight(2);
def aboveVWAP = rth and close > vw;
def reclaim = rth and close crosses above vw;

def tenkan = (Highest(high, 9) + Lowest(low, 9)) / 2;
def kijun = (Highest(high, 26) + Lowest(low, 26)) / 2;
def spanASeries = (tenkan + kijun) / 2;
def spanBSeries = (Highest(high, 52) + Lowest(low, 52)) / 2;
def spanA = spanASeries[26];
def spanB = spanBSeries[26];
def cloudOK = close > Max(spanA, spanB) and close > kijun;
plot KijunLine = kijun;
KijunLine.SetDefaultColor(Color.ORANGE);

# thinkScript requires Highest/Lowest lengths to be compile-time constants.
# Calculate both fixed alternatives, then select by aggregation.
def boxTop5m = Highest(high[1], 78);
def boxBottom5m = Lowest(low[1], 78);
def boxTop15m = Highest(high[1], 26);
def boxBottom15m = Lowest(low[1], 26);
plot BoxTop = if agg == AggregationPeriod.FIVE_MIN then boxTop5m else boxTop15m;
plot BoxBottom = if agg == AggregationPeriod.FIVE_MIN then boxBottom5m else boxBottom15m;
BoxTop.SetDefaultColor(Color.GREEN);
BoxBottom.SetDefaultColor(Color.RED);
BoxTop.SetPaintingStrategy(PaintingStrategy.DASHES);
BoxBottom.SetPaintingStrategy(PaintingStrategy.DASHES);
def boxBreak = close > BoxTop;

def mid = Average(close, bbLength);
def sd = StDev(close, bbLength);
plot BBUpper = mid + bbStd * sd;
plot BBLower = mid - bbStd * sd;
BBUpper.SetDefaultColor(Color.GRAY);
BBLower.SetDefaultColor(Color.GRAY);
def bbOK = close > mid;

def tp = (high + low + close) / 3;
def mf = tp * volume;
def pMF = Sum(if tp > tp[1] then mf else 0, mfiLength);
def nMF = Sum(if tp < tp[1] then mf else 0, mfiLength);
def mfi = if nMF == 0 then 100 else 100 - 100 / (1 + pMF / nMF);
def mfiOK = mfi > 50;
def rsi = RSI(length = rsiLength);
def rsiOK = rsi > 50;

AddLabel(yes, if aboveVWAP then "VWAP ABOVE" else "VWAP WAIT", if aboveVWAP then Color.GREEN else Color.RED);
AddLabel(yes, if cloudOK then "CLOUD ABOVE" else "CLOUD WAIT", if cloudOK then Color.GREEN else Color.RED);
AddLabel(yes, if boxBreak then "BOX BREAK" else "BOX INSIDE", if boxBreak then Color.GREEN else Color.GRAY);
AddLabel(yes, if bbOK then "BB ABOVE MID" else "BB WAIT", if bbOK then Color.GREEN else Color.RED);
AddLabel(yes, "MFI " + Round(mfi, 0), if mfiOK then Color.GREEN else Color.RED);
AddLabel(yes, "RSI " + Round(rsi, 0), if rsiOK then Color.GREEN else Color.RED);
def boxRequirement = !requireBoxBreakForConfirmation or boxBreak;
def allGreen = validAgg and rth and aboveVWAP and cloudOK and boxRequirement and bbOK and mfiOK and rsiOK;
AddLabel(yes, if allGreen then "INTRADAY CONFIRMED" else "INTRADAY WAIT", if allGreen then Color.CYAN else Color.DARK_GRAY);
Alert(alertOnVwapReclaim and validAgg and reclaim, "VWAP reclaim", Alert.BAR, Sound.Ding);
# Using [1] makes this alert occur at the start of the next bar, after the
# confirming candle is complete: about 5 minutes on a 5m chart or 15 on 15m.
def closedBarConfirmed = allGreen[1] and !allGreen[2];
Alert(alertOnClosedBarConfirmation and closedBarConfirmed,
    "V4 closed-bar intraday confirmation", Alert.BAR, Sound.Ring);
