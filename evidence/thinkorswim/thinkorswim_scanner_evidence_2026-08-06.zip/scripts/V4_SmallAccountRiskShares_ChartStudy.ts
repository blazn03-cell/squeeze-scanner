# Paper-trading sizing aid for $100-$1,000 accounts.
# Uses explicit DAY secondary aggregation so sizing does not change with chart timeframe.
# Zero shares is a valid outcome. This is not an order or profitability claim.
input accountSize = 250.0;
input riskPercent = 0.50;
input maxPositionPercent = 20.0;
input stopATR = 1.5;
input gapATR = 0.4;
input roundTripCostPerShare = 0.06;

def validAccount = accountSize >= 100 and accountSize <= 1000;
def chartAgg = GetAggregationPeriod();
def validAggregation = chartAgg == AggregationPeriod.FIVE_MIN or
                       chartAgg == AggregationPeriod.FIFTEEN_MIN or
                       chartAgg == AggregationPeriod.DAY;
def validInputs = riskPercent > 0 and riskPercent <= 1 and
                  maxPositionPercent > 0 and maxPositionPercent <= 100 and
                  stopATR > 0 and gapATR >= 0 and roundTripCostPerShare >= 0;
def dayHigh = high(period = AggregationPeriod.DAY);
def dayLow = low(period = AggregationPeriod.DAY);
def dayClose = close(period = AggregationPeriod.DAY);
def priorClose = dayClose[1];
def atrSeries = Average(TrueRange(dayHigh, dayClose, dayLow), 14);
def atr = atrSeries[1];
def entry = priorClose + gapATR * atr;
def riskPerShare = stopATR * atr + roundTripCostPerShare;
def riskBudget = accountSize * riskPercent / 100;
def riskShares = if riskPerShare > 0 then Floor(riskBudget / riskPerShare) else 0;
def capShares = if entry > 0 then Floor(accountSize * maxPositionPercent / 100 / entry) else 0;
def shares = if validAccount and validInputs and validAggregation then Min(riskShares, capShares) else 0;

AddLabel(!validAccount, "ACCOUNT INPUT MUST BE $100-$1,000", Color.RED);
AddLabel(!validAggregation, "USE 5m, 15m, OR DAY TIME CHART", Color.RED);
AddLabel(validAccount and !validInputs, "INVALID RISK INPUT", Color.RED);
AddLabel(validAccount and validInputs and validAggregation, "SIZE " + shares + " SH", if shares > 0 then Color.CYAN else Color.YELLOW);
AddLabel(validAccount and validInputs and validAggregation, "RISK $" + Round(shares * riskPerShare, 2) + " / BUDGET $" + Round(riskBudget, 2), Color.LIGHT_GRAY);
AddLabel(validAccount and validInputs and validAggregation, "POSITION $" + Round(shares * entry, 2) + " / CAP $" + Round(accountSize * maxPositionPercent / 100, 2), Color.LIGHT_GRAY);
AddLabel(validAccount and validInputs and validAggregation, "COST/SH $" + Round(roundTripCostPerShare, 2), Color.LIGHT_GRAY);
AddLabel(validAccount and validInputs and validAggregation, "CONFIG " + riskPercent + "% RISK | " + maxPositionPercent + "% CAP", Color.GRAY);
