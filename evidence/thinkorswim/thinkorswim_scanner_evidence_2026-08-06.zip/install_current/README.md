# Clean install map

**Paper only. Do not paste every file from `scripts/`.**

## frozen_core

| File | Editor/role | Required setting |
|---|---|---|
| V3_StableScore_CustomQuote.ts | Custom quote, Score 0-100 | DAY, extended off |
| V3_ModelATRpct_CustomQuote.ts | Custom quote, model ATR% | DAY, extended off |
| V3_LiquidUniverse_Stable_Scan.ts | First-stage universe scan | DAY, extended off |
| V3_EntryConfirmed_Daily_Scan_Threshold65_INSTALL.ts | V3 confirmation scan with frozen 65 default | DAY, extended off; do not reset to 60 |
| V4_ConfirmLayer_CustomQuote_v2.ts | Confirmation count 0-5 | DAY, extended off |
| V4_ConfirmATR_Daily_Scan.ts | Lightweight V4 stage after fresh V3 | DAY, extended off |
| V4_2_IntradayConfirm_ChartStudy_EXPERIMENTAL.ts | Last live-compiled alert fallback | One study only; 5m/15m; regular-hours display |

## reference_only_do_not_install

`V3_RiskShares_ChartStudy_v2.ts` is retained only to reproduce the frozen historical workflow. It sizes capital from chart `close` and uses a modeled entry/risk buffer, so it is not the current actionable sizing control. The canonical `V3_EntryConfirmed_Daily_Scan.ts` is also retained here because its source default is 60; the install-safe copy differs only by the preregistered default of 65. Do not install either reference file. No paper action is allowed until the manual-entry candidate compiles and passes live parity.

## candidates_not_live_verified

Compile each under a new name. A successful static/package check is not thinkorswim compile proof.

| File | Adoption rule |
|---|---|
| V4_2_2_IntradayConfirm_ChartStudy_EXPERIMENTAL.ts | Replace V4.2 only after compile/render; verify visible MF+/MF- diagnostics; never enable both |
| V4_1_ManualEntryRiskShares_ChartStudy.ts | Replace hypothetical sizing after zero-entry/zero-spread and timeframe-parity proof |
| V4_LiveSpreadPct_CustomQuote_EXPERIMENTAL.ts | Copied layout; verify five regular-hours bid/ask calculations; blank is unknown |
| V4_SmallAccountAffordability_Daily_Scan_EXPERIMENTAL.ts | Optional third stage after V4/V4.7; DAY, extended off |
| V4_EstimatedAffordableShares_CustomQuote_EXPERIMENTAL.ts | Match affordability scan inputs; DAY, extended off |
| V4_7_ConfirmATR_Daily_Scan_EXPERIMENTAL.ts | Separate V4.7 arm; do not overwrite/pool with V4 |
| V4_7_ConfirmLayer_CustomQuote_EXPERIMENTAL.ts | Separate V4.7 quote; DAY, extended off |

Use `evidence/NEXT_SESSION_LIVE_RUNBOOK_CURRENT.md` for the checkpoint sequence and hard gates.
