﻿# V4.7 EXPERIMENTAL no-flow-MFI reliability quote; do not overwrite frozen V4.
# V4.1 prior-session confirmation count. Set quote aggregation to DAY.
# VWAP is intentionally excluded; use the intraday chart study.
input minConfirms = 4;
input mfiLength = 14;
input rsiLength = 14;
input bbLength = 20;
input bbStd = 2.0;
input boxLength = 20;

def tp = (high + low + close) / 3;
def mf = tp * volume;
def posMF = Sum(if tp > tp[1] then mf else 0, mfiLength);
def negMF = Sum(if tp < tp[1] then mf else 0, mfiLength);
def mfi = if negMF == 0 and posMF == 0 then 50
    else if negMF == 0 then 100
    else 100 - 100 / (1 + posMF / negMF);
def mfiOK = mfi[1] > 50 and mfi[1] >= mfi[2];

def rsi = RSI(length = rsiLength);
def rsiOK = rsi[1] > 50;

def mid = Average(close, bbLength);
def sd = StDev(close, bbLength);
def width = if mid > 0 then (2 * bbStd * sd) / mid else 0;
def bbOK = close[1] > mid[1] and width[1] > width[2];

def tenkan = (Highest(high, 9) + Lowest(low, 9)) / 2;
def kijun = (Highest(high, 26) + Lowest(low, 26)) / 2;
def spanASeries = (tenkan + kijun) / 2;
def spanBSeries = (Highest(high, 52) + Lowest(low, 52)) / 2;
def spanA = spanASeries[26];
def spanB = spanBSeries[26];
def ichiOK = close[1] > Max(spanA[1], spanB[1]) and close[1] > kijun[1];

# Simplified stable rolling box, not a canonical Darvas implementation.
def boxTop = Highest(high[2], boxLength);
def darvasOK = close[1] > boxTop and boxTop == Highest(high[4], boxLength);
def count = mfiOK + rsiOK + bbOK + ichiOK + darvasOK;

plot ConfirmCount = count;
ConfirmCount.AssignValueColor(if count >= minConfirms then Color.BLACK else if count == minConfirms - 1 then Color.YELLOW else Color.LIGHT_GRAY);
AssignBackgroundColor(if count >= minConfirms then Color.GREEN else Color.BLACK);

