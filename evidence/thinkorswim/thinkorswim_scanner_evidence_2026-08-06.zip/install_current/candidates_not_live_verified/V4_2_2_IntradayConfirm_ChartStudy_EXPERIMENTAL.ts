﻿# V4.2.2 EXPERIMENTAL reliability revision of V4.2.1.
# Do not overwrite the frozen V4.1 study. Use on 5m/15m, regular-hours charts.
# Adds a 09:45 start and an ATR-based anti-chase gate for forward testing.
input mfiLength = 14;
input rsiLength = 14;
input bbLength = 20;
input bbStd = 2.0;
input alertStart = 0945;
input alertEnd = 1530;
input maxDistanceAboveVWAP_ATR = 1.0;
input requireBoxBreak = yes;
input alertOnVwapReclaim = yes;
input alertOnClosedBarConfirmation = yes;
input firstConfirmationOnlyPerSession = yes;
input showMfiFlowDiagnostics = yes;

def agg = GetAggregationPeriod();
def validAgg = agg == AggregationPeriod.FIVE_MIN or agg == AggregationPeriod.FIFTEEN_MIN;
def rth = SecondsFromTime(0930) >= 0 and SecondsTillTime(1600) > 0;
def alertWindow = SecondsFromTime(alertStart) >= 0 and SecondsTillTime(alertEnd) > 0;
AddLabel(!validAgg, "WARNING: USE 5m OR 15m", Color.RED);

def vw = reference VWAP()."VWAP";
plot VWAPLine = vw;
VWAPLine.SetDefaultColor(Color.CYAN);
VWAPLine.SetLineWeight(2);
def aboveVWAP = rth and close > vw;
def reclaim = alertWindow and close crosses above vw;

def atr = Average(TrueRange(high, close, low), 14);
def distanceVWAP_ATR = if atr > 0 then (close - vw) / atr else 99;
def notChasing = distanceVWAP_ATR >= 0 and distanceVWAP_ATR <= maxDistanceAboveVWAP_ATR;

def tenkan = (Highest(high, 9) + Lowest(low, 9)) / 2;
def kijun = (Highest(high, 26) + Lowest(low, 26)) / 2;
def spanASeries = (tenkan + kijun) / 2;
def spanBSeries = (Highest(high, 52) + Lowest(low, 52)) / 2;
def spanA = spanASeries[26];
def spanB = spanBSeries[26];
def cloudOK = close > Max(spanA, spanB) and close > kijun;
plot KijunLine = kijun;
KijunLine.SetDefaultColor(Color.ORANGE);

def boxTop5m = Highest(high[1], 78);
def boxBottom5m = Lowest(low[1], 78);
def boxTop15m = Highest(high[1], 26);
def boxBottom15m = Lowest(low[1], 26);
plot BoxTop = if agg == AggregationPeriod.FIVE_MIN then boxTop5m else boxTop15m;
plot BoxBottom = if agg == AggregationPeriod.FIVE_MIN then boxBottom5m else boxBottom15m;
BoxTop.SetDefaultColor(Color.GREEN);
BoxBottom.SetDefaultColor(Color.RED);
BoxTop.SetPaintingStrategy(PaintingStrategy.DASHES);
BoxBottom.SetPaintingStrategy(PaintingStrategy.DASHES);
def boxBreak = close > BoxTop;

def mid = Average(close, bbLength);
def sd = StDev(close, bbLength);
plot BBUpper = mid + bbStd * sd;
plot BBLower = mid - bbStd * sd;
BBUpper.SetDefaultColor(Color.GRAY);
BBLower.SetDefaultColor(Color.GRAY);
def bbOK = close > mid;

def tp = (high + low + close) / 3;
def mf = tp * volume;
def pMF = Sum(if tp > tp[1] then mf else 0, mfiLength);
def nMF = Sum(if tp < tp[1] then mf else 0, mfiLength);
def mfi = if nMF == 0 and pMF == 0 then 50
    else if nMF == 0 then 100
    else 100 - 100 / (1 + pMF / nMF);
def mfiOK = mfi > 50;
def mfiNoFlow = pMF == 0 and nMF == 0;
def rsi = RSI(length = rsiLength);
def rsiOK = rsi > 50;

def coreConfirmed = validAgg and alertWindow and aboveVWAP and cloudOK
    and (!requireBoxBreak or boxBreak) and bbOK and mfiOK and rsiOK;
def qualified = coreConfirmed and notChasing;

AddLabel(yes, if alertWindow then "ALERT WINDOW" else "TIME WAIT", if alertWindow then Color.GREEN else Color.DARK_GRAY);
AddLabel(yes, if aboveVWAP then "VWAP ABOVE" else "VWAP WAIT", if aboveVWAP then Color.GREEN else Color.RED);
AddLabel(yes, if distanceVWAP_ATR < 0 then "BELOW VWAP" else if notChasing then "EXTENSION OK" else "TOO EXTENDED", if notChasing then Color.GREEN else Color.RED);
AddLabel(yes, if cloudOK then "CLOUD ABOVE" else "CLOUD WAIT", if cloudOK then Color.GREEN else Color.RED);
AddLabel(yes, if boxBreak then "BOX BREAK" else "BOX INSIDE", if boxBreak then Color.GREEN else Color.GRAY);
AddLabel(yes, if bbOK then "BB ABOVE MID" else "BB WAIT", if bbOK then Color.GREEN else Color.RED);
AddLabel(yes, "MFI " + Round(mfi, 0), if mfiOK then Color.GREEN else Color.RED);
AddLabel(showMfiFlowDiagnostics, if mfiNoFlow then "CURRENT MFI FLOW NONE" else "CURRENT MFI FLOW PRESENT", if mfiNoFlow then Color.RED else Color.DARK_GRAY);
AddLabel(yes, "RSI " + Round(rsi, 0), if rsiOK then Color.GREEN else Color.RED);
AddLabel(yes, if qualified then "QUALIFIED: WAIT FOR BAR CLOSE" else "INTRADAY WAIT", if qualified then Color.CYAN else Color.DARK_GRAY);

# [1] deliberately delays the signal until the confirming candle has closed.
def rawClosedBarConfirmation = qualified[1] and !qualified[2];
def newSession = GetYYYYMMDD() != GetYYYYMMDD()[1];
rec confirmationSeen = if newSession then 0
    else if rawClosedBarConfirmation then 1
    else confirmationSeen[1];
def firstClosedBarConfirmation = rawClosedBarConfirmation and confirmationSeen[1] == 0;
def alertConfirmation = rawClosedBarConfirmation
    and (!firstConfirmationOnlyPerSession or firstClosedBarConfirmation);
rec lastRingPositiveFlow = if newSession then Double.NaN
    else if alertConfirmation then pMF[1]
    else lastRingPositiveFlow[1];
rec lastRingNegativeFlow = if newSession then Double.NaN
    else if alertConfirmation then nMF[1]
    else lastRingNegativeFlow[1];
AddLabel(showMfiFlowDiagnostics and !IsNaN(lastRingPositiveFlow),
    "LAST RING MF+ " + Round(lastRingPositiveFlow, 0) + " | MF- " + Round(lastRingNegativeFlow, 0),
    if lastRingPositiveFlow == 0 and lastRingNegativeFlow == 0 then Color.RED else Color.DARK_GRAY);
plot ConfirmArrow = if alertConfirmation then low else Double.NaN;
ConfirmArrow.SetPaintingStrategy(PaintingStrategy.ARROW_UP);
ConfirmArrow.SetDefaultColor(Color.CYAN);
ConfirmArrow.SetLineWeight(3);

Alert(alertOnVwapReclaim and validAgg and reclaim, "V4.2.2 VWAP reclaim - early warning only", Alert.BAR, Sound.Ding);
Alert(alertOnClosedBarConfirmation and alertConfirmation,
    "V4.2.2 closed-bar confirmation - verify risk size", Alert.BAR, Sound.Ring);


