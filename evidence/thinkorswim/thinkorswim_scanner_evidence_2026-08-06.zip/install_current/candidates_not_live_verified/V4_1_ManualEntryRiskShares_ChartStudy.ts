# V4.1 paper-only sizing aid for $100-$1,000 accounts.
# Requires the actual intended/fill entry price; zero means NOT READY.
# Uses prior completed DAY ATR and does not place orders.
input accountSize = 250.0;
input riskPercent = 0.50;
input maxPositionPercent = 20.0;
input entryPrice = 0.0;
input stopATR = 1.5;
input observedSpreadPerShare = 0.0;
input expectedRoundTripSlippagePerShare = 0.04;
input feesPerShare = 0.0;

def validAccount = accountSize >= 100 and accountSize <= 1000;
def chartAgg = GetAggregationPeriod();
def validAggregation = chartAgg == AggregationPeriod.FIVE_MIN or
                       chartAgg == AggregationPeriod.FIFTEEN_MIN or
                       chartAgg == AggregationPeriod.DAY;
def validInputs = riskPercent > 0 and riskPercent <= 1 and
                  maxPositionPercent > 0 and maxPositionPercent <= 100 and
                  entryPrice > 0 and stopATR > 0 and observedSpreadPerShare > 0 and
                  expectedRoundTripSlippagePerShare >= 0 and feesPerShare >= 0;
def dayHigh = high(period = AggregationPeriod.DAY);
def dayLow = low(period = AggregationPeriod.DAY);
def dayClose = close(period = AggregationPeriod.DAY);
def atrSeries = Average(TrueRange(dayHigh, dayClose, dayLow), 14);
def atr = atrSeries[1];
def roundTripCostPerShare = observedSpreadPerShare + expectedRoundTripSlippagePerShare + feesPerShare;
def riskPerShare = stopATR * atr + roundTripCostPerShare;
def stopPrice = entryPrice - stopATR * atr;
def riskBudget = accountSize * riskPercent / 100;
def riskShares = if riskPerShare > 0 then Floor(riskBudget / riskPerShare) else 0;
def capShares = if entryPrice > 0 then Floor(accountSize * maxPositionPercent / 100 / entryPrice) else 0;
def shares = if validAccount and validInputs and validAggregation and stopPrice > 0
             then Min(riskShares, capShares) else 0;

AddLabel(!validAccount, "ACCOUNT INPUT MUST BE $100-$1,000", Color.RED);
AddLabel(!validAggregation, "USE 5m, 15m, OR DAY TIME CHART", Color.RED);
AddLabel(validAccount and validAggregation and entryPrice <= 0, "ENTER ACTUAL ENTRY PRICE: SIZE DISABLED", Color.RED);
AddLabel(validAccount and validAggregation and entryPrice > 0 and observedSpreadPerShare <= 0, "ENTER OBSERVED $/SH SPREAD: SIZE DISABLED", Color.RED);
AddLabel(validAccount and validAggregation and entryPrice > 0 and !validInputs, "INVALID RISK/COST INPUT", Color.RED);
AddLabel(validAccount and validInputs and validAggregation and stopPrice <= 0, "INVALID MODEL STOP", Color.RED);
AddLabel(validAccount and validInputs and validAggregation and stopPrice > 0, "SIZE " + shares + " SH", if shares > 0 then Color.CYAN else Color.YELLOW);
AddLabel(validAccount and validInputs and validAggregation and stopPrice > 0, "ENTRY $" + Round(entryPrice, 2) + " | STOP $" + Round(stopPrice, 2), Color.LIGHT_GRAY);
AddLabel(validAccount and validInputs and validAggregation and stopPrice > 0, "RISK/SH $" + Round(riskPerShare, 2) + " | COST/SH $" + Round(roundTripCostPerShare, 2), Color.LIGHT_GRAY);
AddLabel(validAccount and validInputs and validAggregation and stopPrice > 0, "SPREAD/SH $" + Round(observedSpreadPerShare, 2) + " | SLIP/SH $" + Round(expectedRoundTripSlippagePerShare, 2), Color.LIGHT_GRAY);
AddLabel(validAccount and validInputs and validAggregation and stopPrice > 0, "RISK $" + Round(shares * riskPerShare, 2) + " / BUDGET $" + Round(riskBudget, 2), Color.LIGHT_GRAY);
AddLabel(validAccount and validInputs and validAggregation and stopPrice > 0, "POSITION $" + Round(shares * entryPrice, 2) + " / CAP $" + Round(accountSize * maxPositionPercent / 100, 2), Color.LIGHT_GRAY);
AddLabel(validAccount and validInputs and validAggregation and stopPrice > 0, "CONFIG " + riskPercent + "% RISK | " + maxPositionPercent + "% CAP", Color.GRAY);
