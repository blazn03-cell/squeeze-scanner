# Live bid/ask spread diagnostic for watchlists. Use during regular market hours.
# A blank value means bid/ask data is unavailable; never treat blank as zero spread.
input cautionSpreadPct = 0.25;
input highSpreadPct = 0.50;

# Direct bid/ask functions are designed for Custom Quotes and return current values.
def bidPrice = bid;
def askPrice = ask;
def midpoint = (bidPrice + askPrice) / 2;
def validQuote = bidPrice > 0 and askPrice >= bidPrice and midpoint > 0;
def spreadPct = if validQuote then 100 * (askPrice - bidPrice) / midpoint else Double.NaN;

plot SpreadPercent = spreadPct;
SpreadPercent.AssignValueColor(
    if !validQuote then Color.GRAY
    else if spreadPct <= cautionSpreadPct then Color.GREEN
    else if spreadPct <= highSpreadPct then Color.YELLOW
    else Color.RED
);
AssignBackgroundColor(
    if !validQuote then Color.BLACK
    else if spreadPct <= cautionSpreadPct then Color.DARK_GREEN
    else if spreadPct <= highSpreadPct then Color.DARK_ORANGE
    else Color.DARK_RED
);
