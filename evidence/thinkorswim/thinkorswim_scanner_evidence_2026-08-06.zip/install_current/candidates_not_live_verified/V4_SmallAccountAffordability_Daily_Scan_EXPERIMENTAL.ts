# Experimental third-stage affordability prefilter. DAY, extended hours OFF.
# Apply only after a fresh V4/V4.7 result set; not a profitability filter.
input accountSize = 100.0;
input riskPercent = 0.50;
input maxPositionPercent = 20.0;
input stopATR = 1.5;
input plannedEntryATRBuffer = 0.4;
input minimumRoundTripCostPerShare = 0.06;

def validInputs = accountSize >= 100 and accountSize <= 1000 and
                  riskPercent > 0 and riskPercent <= 1 and
                  maxPositionPercent > 0 and maxPositionPercent <= 100 and
                  stopATR > 0 and plannedEntryATRBuffer >= 0 and
                  minimumRoundTripCostPerShare > 0;
def c = close[1];
def atrSeries = Average(TrueRange(high, close, low), 14);
def atr = atrSeries[1];
def plannedEntry = c + plannedEntryATRBuffer * atr;
def riskPerShare = stopATR * atr + minimumRoundTripCostPerShare;
def riskBudget = accountSize * riskPercent / 100;
def capitalBudget = accountSize * maxPositionPercent / 100;
def riskShares = if riskPerShare > 0 then Floor(riskBudget / riskPerShare) else 0;
def capitalShares = if plannedEntry > 0 then Floor(capitalBudget / plannedEntry) else 0;
def estimatedShares = Min(riskShares, capitalShares);

plot scan = validInputs and c > 0 and atr > 0 and estimatedShares >= 1;
