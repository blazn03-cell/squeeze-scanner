# V3 completed-session score/status — custom quote
# REQUIRED: aggregation DAY, extended hours OFF.
# Replaces the drifting live Score + DarvasScanner columns with one quote.
# Numeric value is the prior completed session's score.
# CYAN background = the prior session satisfied the confirmed-entry condition.

input scoreThreshold = 60;
input minPrice = 5.0;
input minAvgDollarVolume = 20000000;
input breakoutLength = 20;
input relVolLength = 30;

def c = close[1];
def ema20Series = ExpAverage(close, 20);
def sma50Series = Average(close, 50);
def sma200Series = Average(close, 200);
def ema20 = ema20Series[1];
def sma50 = sma50Series[1];
def sma200 = sma200Series[1];

def trend = if c > ema20 and ema20 > sma50 and sma50 > sma200 then 100
    else if c > ema20 and ema20 > sma50 then 70
    else if c > sma50 then 40 else 0;

def priorHigh = Highest(high[2], breakoutLength);
def atrSeries = Average(TrueRange(high, close, low), 14);
def atr = atrSeries[1];
def distanceATR = if atr > 0 then (priorHigh - c) / atr else 99;
def structure = Max(0, Min(100, 100 - 35 * distanceATR));

def baseVolume = Average(volume[2], relVolLength);
def relativeVolume = if baseVolume > 0 then volume[1] / baseVolume else 0;
def participation = Min(100, relativeVolume / 2.5 * 100);

def range5Series = Average(high - low, 5);
def range20Series = Average(high - low, 20);
def range5 = range5Series[1];
def range20 = range20Series[1];
def compression = if range20 > 0
    then Max(0, Min(100, (1.25 - range5 / range20) * 200))
    else 0;

def closePosition = if high[1] > low[1]
    then (c - low[1]) / (high[1] - low[1])
    else 0.5;
def candle = Max(0, Min(100, closePosition * 100));
def roc20 = if close[21] > 0 then (c / close[21] - 1) * 100 else 0;
def momentum = Max(0, Min(100, (roc20 + 5) / 25 * 100));

def rawScore = 0.25 * trend + 0.25 * structure + 0.15 * participation
    + 0.15 * compression + 0.10 * candle + 0.10 * momentum;
def extensionATR = if atr > 0 then (c - ema20) / atr else 0;
def extensionPenalty = if extensionATR <= 2 then 1
    else if extensionATR <= 3 then 0.75 else 0.50;
def score = rawScore * extensionPenalty;

def avgDollarVolume = Average(close[1] * volume[1], 20);
def liquid = c >= minPrice and avgDollarVolume >= minAvgDollarVolume;
def confirmed = liquid
    and score >= scoreThreshold
    and c > priorHigh
    and relativeVolume >= 1.2
    and extensionATR <= 3;

plot StableScore = if liquid then Round(score, 0) else Double.NaN;
StableScore.AssignValueColor(
    if confirmed then Color.BLACK
    else if score >= scoreThreshold then Color.GREEN
    else if score >= 45 then Color.YELLOW
    else Color.GRAY
);
AssignBackgroundColor(if confirmed then Color.CYAN else Color.BLACK);
