# INSTALL CONFIG: frozen threshold 65. Canonical default-60 source retained in reference_only_do_not_install.
# Stable prior-session candidate scan.
# DAILY aggregation. Run premarket or after the close; every input uses completed bars.
input scoreThreshold = 65;
input breakoutLength = 20;
input relVolLength = 30;

def c = close[1];
def ema20Series = ExpAverage(close, 20);
def sma50Series = Average(close, 50);
def sma200Series = Average(close, 200);
def ema20 = ema20Series[1];
def sma50 = sma50Series[1];
def sma200 = sma200Series[1];
def trend = if c > ema20 and ema20 > sma50 and sma50 > sma200 then 100
    else if c > ema20 and ema20 > sma50 then 70
    else if c > sma50 then 40 else 0;
def priorHigh = Highest(high[2], breakoutLength);
def atrSeries = Average(TrueRange(high, close, low), 14);
def atr = atrSeries[1];
def distanceATR = if atr > 0 then (priorHigh - c) / atr else 99;
def structure = Max(0, Min(100, 100 - 35 * distanceATR));
def baseVol = Average(volume[2], relVolLength);
def rv = if baseVol > 0 then volume[1] / baseVol else 0;
def participation = Min(100, rv / 2.5 * 100);
def range5Series = Average(high - low, 5);
def range20Series = Average(high - low, 20);
def range5 = range5Series[1];
def range20 = range20Series[1];
def compression = if range20 > 0 then Max(0, Min(100, (1.25 - range5 / range20) * 200)) else 0;
def closePos = if high[1] > low[1] then (c - low[1]) / (high[1] - low[1]) else 0.5;
def candle = Max(0, Min(100, closePos * 100));
def roc20 = if close[21] > 0 then (c / close[21] - 1) * 100 else 0;
def momentum = Max(0, Min(100, (roc20 + 5) / 25 * 100));
def raw = .25 * trend + .25 * structure + .15 * participation
    + .15 * compression + .10 * candle + .10 * momentum;
def extensionATR = if atr > 0 then (c - ema20) / atr else 0;
def penalty = if extensionATR <= 2 then 1 else if extensionATR <= 3 then .75 else .50;
plot scan = raw * penalty >= scoreThreshold and c > priorHigh and rv >= 1.2 and extensionATR <= 3;
