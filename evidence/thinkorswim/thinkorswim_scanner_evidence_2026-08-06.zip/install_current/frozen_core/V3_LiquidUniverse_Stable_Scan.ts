# Equity-only daily prefilter using completed sessions for stable intraday membership.
input minPrice=5;
input maxPrice=500;
input minAvgVolume=500000;
input minAvgDollarVolume=20000000;
input minAtrPct=1;
input maxAtrPct=8;
def c=close[1];
def av=Average(volume[1],20);
def adv=Average(close[1]*volume[1],20);
def a=Average(TrueRange(high,close,low),14)[1];
def ap=if c>0 then 100*a/c else 0;
plot scan=c>=minPrice and c<=maxPrice and av>=minAvgVolume and adv>=minAvgDollarVolume and ap>=minAtrPct and ap<=maxAtrPct and c>Average(close,50)[1];
