# V3_ModelATRpct_CustomQuote
# Use Day aggregation.
# Prior completed-session 14-day SIMPLE ATR as a percent of prior close.
# This intentionally matches V3_StableScore, V3_EntryConfirmed, the strategy,
# historical Python model, and risk-sizing study. It is not Wilder ATR.

def tr = TrueRange(high, close, low);
def modelATRSeries = Average(tr, 14);
def modelATR = modelATRSeries[1];
def priorClose = close[1];

plot ModelATRpct =
    if priorClose > 0 then Round(100 * modelATR / priorClose, 2)
    else Double.NaN;

ModelATRpct.AssignValueColor(
    if ModelATRpct >= 4 then Color.ORANGE
    else if ModelATRpct >= 3 then Color.YELLOW
    else if ModelATRpct >= 2 then Color.LIGHT_GRAY
    else Color.GRAY
);
