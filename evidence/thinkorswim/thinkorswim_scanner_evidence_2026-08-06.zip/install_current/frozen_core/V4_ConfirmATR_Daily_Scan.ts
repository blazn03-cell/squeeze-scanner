# V4 confirmation/ATR stage. DAY aggregation, extended hours OFF.
# Preferred setup: set "Scan in" to the saved canonical V3 confirmed query,
# then use this as the ONLY study filter in the separate V4 saved query.
# This split avoids the whole-universe complexity/timeout seen when the entire
# V3 score and five V4 checks are compiled into one scanner expression.
input breakoutLength = 20;
input maxATRpct = 4.0;
input minConfirms = 4;
input mfiLength = 14;
input rsiLength = 14;
input bbLength = 20;
input bbStd = 2.0;

def c = close[1];
def atrSeries = Average(TrueRange(high, close, low), 14);
def atr = atrSeries[1];
def atrOK = c > 0 and 100 * atr / c < maxATRpct;

def tp = (high + low + close) / 3;
def mf = tp * volume;
def pMF = Sum(if tp > tp[1] then mf else 0, mfiLength);
def nMF = Sum(if tp < tp[1] then mf else 0, mfiLength);
def mfi = if nMF == 0 then 100 else 100 - 100 / (1 + pMF / nMF);
def mfiOK = mfi[1] > 50 and mfi[1] >= mfi[2];

def rsiSeries = RSI(length = rsiLength);
def rsiOK = rsiSeries[1] > 50;

def mid = Average(close, bbLength);
def sd = StDev(close, bbLength);
def width = if mid > 0 then (2 * bbStd * sd) / mid else 0;
def bbOK = c > mid[1] and width[1] > width[2];

def tenkan = (Highest(high, 9) + Lowest(low, 9)) / 2;
def kijun = (Highest(high, 26) + Lowest(low, 26)) / 2;
def spanASeries = (tenkan + kijun) / 2;
def spanBSeries = (Highest(high, 52) + Lowest(low, 52)) / 2;
def spanA = spanASeries[26];
def spanB = spanBSeries[26];
def ichiOK = c > Max(spanA[1], spanB[1]) and c > kijun[1];

def boxTop = Highest(high[2], breakoutLength);
def darvasOK = c > boxTop and boxTop == Highest(high[4], breakoutLength);
def confirms = mfiOK + rsiOK + bbOK + ichiOK + darvasOK;

plot scan = atrOK and confirms >= minConfirms;
