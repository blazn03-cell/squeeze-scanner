# V3_RiskShares_ChartStudy_v2
# PAPER-TRADING sizing aid. It does not read actual account equity or buying power.
# Uses prior completed daily SIMPLE ATR to match the V3 score/backtest model,
# regardless of the chart's intraday aggregation.

input accountSize = 250.00;
input riskPercent = 0.50;
input atrLength = 14;
input stopATR = 1.50;
input gapBufferR = 0.40;
input roundLot = 1;
input maxPositionPercent = 20.00;
input modeledRoundTripCostPerShare = 0.06;

def dHigh = high(period = AggregationPeriod.DAY);
def dLow = low(period = AggregationPeriod.DAY);
def dClose = close(period = AggregationPeriod.DAY);
def dailyTR = TrueRange(dHigh, dClose, dLow);
def modelATRSeries = Average(dailyTR, atrLength);
def modelATR = modelATRSeries[1];

def riskBudget = Max(0, accountSize * riskPercent / 100);
def riskPerShare = modelATR * (stopATR + gapBufferR)
    + modeledRoundTripCostPerShare;
def riskLimitedShares = if riskPerShare > 0
    then Floor(riskBudget / riskPerShare)
    else 0;

def capitalBudget = Max(0, accountSize * maxPositionPercent / 100);
def capitalLimitedShares = if close > 0
    then Floor(capitalBudget / close)
    else 0;

def uncappedShares = Min(riskLimitedShares, capitalLimitedShares);
def shares = if roundLot >= 1
    then Floor(uncappedShares / roundLot) * roundLot
    else 0;
def validInputs = accountSize > 0 and riskPercent > 0 and riskPercent <= 1
    and maxPositionPercent > 0 and maxPositionPercent <= 100
    and atrLength >= 2 and stopATR > 0 and gapBufferR >= 0
    and roundLot >= 1 and modeledRoundTripCostPerShare >= 0;
def safeShares = if validInputs then shares else 0;

AddLabel(
    yes,
    if !validInputs then "INVALID SIZING INPUTS — 0 SHARES"
    else if safeShares < 1 then
        "NO PAPER TRADE | Account input " + AsDollars(accountSize)
        + " | Risk budget " + AsDollars(riskBudget)
        + " | Risk/share " + AsDollars(riskPerShare)
    else
        "PAPER ONLY | Account input " + AsDollars(accountSize)
        + " | Risk " + AsDollars(riskBudget)
        + " | Risk/share " + AsDollars(riskPerShare)
        + " | Capital cap " + AsDollars(capitalBudget)
        + " | Shares " + safeShares,
    if !validInputs or safeShares < 1 then Color.RED else Color.YELLOW
);

plot PositionShares = safeShares;
PositionShares.Hide();
