from __future__ import annotations
import csv, importlib.util, tempfile
from pathlib import Path

HERE=Path(__file__).parent
spec=importlib.util.spec_from_file_location('validator',HERE/'validate_v4_2_intraday_alert_log.py')
v=importlib.util.module_from_spec(spec); spec.loader.exec_module(v)
base=dict(zip(v.REQUIRED,[
 '2026-08-07','SAN','5','V4.2.2','08:45','08:50','08:50:00','0','Ring','yes','yes','no','yes','yes','yes',
 '60','150','100','60','0.5','0.02','0.04','0','15','14.56','0.06','0.5','250','0.5','20','2','3','2','paper','valid']))

def accepted(rows):
 with tempfile.NamedTemporaryFile('w',newline='',suffix='.csv',delete=False,encoding='utf-8') as f:
  w=csv.DictWriter(f,fieldnames=v.REQUIRED); w.writeheader(); w.writerows(rows); p=Path(f.name)
 try: v.validate(p); return True
 except (ValueError,TypeError): return False
 finally: p.unlink(missing_ok=True)

tests=[
 ('valid_5m', [base], True),
 ('valid_final_delivery', [{**base,'qualifying_bar_start_ct':'14:25','qualifying_bar_close_ct':'14:30','alert_time_ct':'14:30'}], True),
 ('valid_delayed_delivery', [{**base,'alert_time_ct':'08:50:37','alert_latency_seconds':'37'}], True),
 ('latency_mismatch', [{**base,'alert_time_ct':'08:50:37','alert_latency_seconds':'0'}], False),
 ('negative_latency', [{**base,'alert_latency_seconds':'-1'}], False),
 ('unknown_version', [{**base,'script_version':'V4.9'}], False),
 ('early_delivery', [{**base,'alert_time_ct':'08:45'}], False),
 ('late_qualification', [{**base,'qualifying_bar_start_ct':'14:30','qualifying_bar_close_ct':'14:35','alert_time_ct':'14:35'}], False),
 ('prewindow_bar', [{**base,'qualifying_bar_start_ct':'08:40','qualifying_bar_close_ct':'08:45','alert_time_ct':'08:45'}], False),
 ('wrong_bar_span', [{**base,'qualifying_bar_close_ct':'08:49','alert_time_ct':'08:49'}], False),
 ('ding_not_ring', [{**base,'alert_sound':'Ding'}], False),
 ('cloud_missing', [{**base,'cloud_ok':'no'}], False),
 ('box_missing', [{**base,'box_ok':'no'}], False),
 ('mfi_boundary', [{**base,'mfi_value':'50'}], False),
 ('negative_distance', [{**base,'vwap_distance_atr':'-0.01'}], False),
 ('overextended', [{**base,'vwap_distance_atr':'1.01'}], False),
 ('zero_share_paper', [{**base,'risk_per_share':'2','risk_limited_shares':'0','calculated_shares':'0'}], False),
 ('missing_spread_paper', [{**base,'bid_ask_spread':''}], False),
 ('cost_omitted_from_risk', [{**base,'risk_per_share':'0.44','risk_limited_shares':'2'}], False),
 ('cost_below_spread', [{**base,'bid_ask_spread':'0.07'}], False),
 ('cost_below_spread_plus_slippage', [{**base,'expected_slippage_per_share':'0.05'}], False),
 ('negative_slippage', [{**base,'expected_slippage_per_share':'-0.01'}], False),
 ('negative_fees', [{**base,'fees_per_share':'-0.01'}], False),
 ('mfi_flow_mismatch', [{**base,'mfi_positive_flow':'100'}], False),
 ('negative_mfi_flow', [{**base,'mfi_negative_flow':'-1'}], False),
 ('v422_no_flow_rejected', [{**base,'mfi_value':'50','mfi_positive_flow':'0','mfi_negative_flow':'0'}], False),
 ('fallback_no_flow_paper_rejected', [{**base,'script_version':'V4.2','mfi_value':'100','mfi_positive_flow':'0','mfi_negative_flow':'0'}], False),
 ('fallback_no_flow_skip_logged', [{**base,'script_version':'V4.2','mfi_value':'100','mfi_positive_flow':'0','mfi_negative_flow':'0','action':'skip'}], True),
 ('risk_share_mismatch', [{**base,'risk_limited_shares':'1','calculated_shares':'1'}], False),
 ('capital_share_mismatch', [{**base,'capital_limited_shares':'2','calculated_shares':'2'}], False),
 ('risk_percent_changed', [{**base,'risk_percent':'1.0'}], False),
 ('duplicate_session', [base,{**base}], False),
]
fail=[]
for name,rows,expected in tests:
 got=accepted(rows)
 print(('PASS' if got==expected else 'FAIL'),name,'accepted='+str(got))
 if got!=expected: fail.append(name)
if fail: raise SystemExit('failed: '+','.join(fail))
print(f'PASS: {len(tests)}/{len(tests)} validator cases')
