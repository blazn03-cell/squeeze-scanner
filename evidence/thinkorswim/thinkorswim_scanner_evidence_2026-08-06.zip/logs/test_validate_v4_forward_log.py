"""Regression tests for validate_v4_forward_log.py."""
import csv, subprocess, sys, tempfile
from pathlib import Path

HERE = Path(__file__).parent
VALIDATOR = HERE / "validate_v4_forward_log.py"
FIELDS = next(csv.reader((HERE / "v4_forward_paper_log.csv").open(encoding="utf-8-sig")))
base = {k:"" for k in FIELDS}
base.update(signal_date="2026-08-07", signal_time_et="09:35", signal_time_ct="08:35", ticker="SAN",
 threshold="65", scan_type="V4", score="70", atr_pct="2.61", mfi_ok="1",
 rsi_ok="1", bollinger_ok="1", ichimoku_ok="1", darvas_ok="0",
 confirm_count="4", atr_cap_pass="1", v4_pass="1", eligible="1",
 affordability_stage_used="1", estimated_affordable_shares="1", affordability_stage_pass="1",
 load_error="0", planned_entry="14.87", next_open_entry="14.87", planned_stop="14.29",
 bid_ask_spread="0.02", slippage_per_share="0.02", fees_per_share="0.00", round_trip_cost_per_share="0.06", account_input="250",
 risk_percent="0.5", max_position_percent="20", risk_budget="1.25",
 risk_per_share="0.64", risk_limited_shares="1", capital_limited_shares="3",
 final_shares="1", sizing_status="paper_trade", shares="1")

def accepted(rows):
    with tempfile.TemporaryDirectory() as td:
        p=Path(td)/"log.csv"
        with p.open("w",newline="",encoding="utf-8") as f:
            w=csv.DictWriter(f,fieldnames=FIELDS);w.writeheader();w.writerows(rows)
        r=subprocess.run([sys.executable,str(VALIDATOR),str(p)],capture_output=True,text=True)
        return r.returncode==0, r.stdout+r.stderr

cases=[
 ("valid",[base],True),
 ("duplicate",[base,base],False),
 ("missing_component",[{**base,"mfi_ok":""}],False),
 ("count_mismatch",[{**base,"confirm_count":"5"}],False),
 ("atr_boundary_strict",[{**base,"atr_pct":"4.0","atr_cap_pass":"1"}],False),
 ("identity_required",[{**base,"eligible":"0"}],False),
 ("fractional_shares",[{**base,"final_shares":"1.5"}],False),
 ("budget_mismatch",[{**base,"risk_budget":"2.50"}],False),
 ("risk_shares_mismatch",[{**base,"risk_limited_shares":"2","final_shares":"2","shares":"2"}],False),
 ("capital_shares_mismatch",[{**base,"capital_limited_shares":"2"}],False),
 ("alias_mismatch",[{**base,"shares":"0"}],False),
 ("zero_paper_trade",[{**base,"risk_per_share":"2","risk_limited_shares":"0","final_shares":"0","shares":"0"}],False),
]
observation={**base,"signal_time_et":"11:30","signal_time_ct":"10:30","sizing_status":"observation_only"}
for c in ["account_input","risk_percent","max_position_percent","risk_budget","risk_per_share",
          "planned_entry","next_open_entry","planned_stop","bid_ask_spread","slippage_per_share","fees_per_share","round_trip_cost_per_share",
          "risk_limited_shares","capital_limited_shares","final_shares","shares"]:
    observation[c]=""
cases += [
 ("repeated_checkpoint_observation",[base,observation],True),
 ("checkpoint_daily_drift",[base,{**observation,"score":"71"}],False),
 ("multiple_paper_actions",[base,{**base,"signal_time_et":"11:30","signal_time_ct":"10:30"}],False),
 ("timezone_mismatch",[{**base,"signal_time_ct":"09:35"}],False),
 ("score_out_of_range",[{**base,"score":"101"}],False),
 ("account_out_of_scope",[{**base,"account_input":"99","risk_budget":"0.495","capital_limited_shares":"1"}],False),
 ("risk_percent_changed",[{**base,"risk_percent":"1.0","risk_budget":"2.50","risk_limited_shares":"3","final_shares":"3","shares":"3"}],False),
 ("capital_cap_changed",[{**base,"max_position_percent":"50","capital_limited_shares":"8"}],False),
 ("negative_entry",[{**base,"next_open_entry":"-14.87"}],False),
 ("cost_below_spread_slippage",[{**base,"round_trip_cost_per_share":"0.03","risk_per_share":"0.61"}],False),
 ("risk_excludes_cost",[{**base,"risk_per_share":"0.58","risk_limited_shares":"2"}],False),
 ("affordability_count_mismatch",[{**base,"estimated_affordable_shares":"0","affordability_stage_pass":"1"}],False),
 ("paper_bypasses_affordability",[{**base,"estimated_affordable_shares":"0","affordability_stage_pass":"0"}],False),
 ("unused_affordability_has_output",[{**base,"affordability_stage_used":"0"}],False),
 ("negative_fees",[{**base,"fees_per_share":"-0.01"}],False),
]
passed=0
for name,rows,want in cases:
    got,out=accepted(rows); ok=got==want
    print(("PASS" if ok else "FAIL"),name,"accepted="+str(got))
    if not ok: print(out)
    passed+=ok
print(f"PASS: {passed}/{len(cases)} V4 forward-log validator cases")
raise SystemExit(0 if passed==len(cases) else 1)
