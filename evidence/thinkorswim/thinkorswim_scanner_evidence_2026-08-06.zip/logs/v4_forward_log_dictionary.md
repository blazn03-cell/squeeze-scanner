# V4.1 forward-paper log dictionary

V4.1 is a separate paper-test arm. Record every V3-qualified candidate before applying V4 filters so rejected and zero-share cases remain in the denominator.

The V3-compatible columns retain the definitions in the V3 dictionary. V4-specific fields are:

- `mfi_ok`: 1 when prior-session MFI(14) >50 and non-falling; otherwise 0.
- `rsi_ok`: 1 when prior-session RSI(14) >50.
- `bollinger_ok`: 1 when the prior close is above the 20-period midband and normalized bandwidth expanded.
- `ichimoku_ok`: 1 when the prior close is above the displaced cloud and Kijun.
- `darvas_ok`: 1 for the simplified stable-box breakout. This is not a canonical Darvas implementation.
- `confirm_count`: integer sum from 0 through 5.
- `atr_cap_pass`: 1 only when model ATR% is strictly below 4.0.
- `eligible`: 1 only when the row passes the common-equity/ADR identity gate; excluded products remain logged with 0.
- `v4_pass`: 1 only when `eligible == 1`, `confirm_count >= 4`, and `atr_cap_pass == 1`, after the canonical V3 confirmed condition.

Frozen configuration: threshold 65, max ATR% 4.0 (strictly below), minimum confirmations 4, default indicator lengths, 0.50% risk, and 20% capital cap. Paper only. Do not delete rejects, load errors, or zero-share rows.

Use one row per **checkpoint** (`signal_date`, `signal_time_et`, `signal_time_ct`, `ticker`, `scan_type`). Record both clocks: the validator converts America/New_York to America/Chicago for that date and rejects mismatches. The scheduled 08:35/10:30/14:15 CT checkpoints normally map to 09:35/11:30/15:15 ET. Repeated observations of one date/ticker are not independent trades: completed-daily fields must remain identical, only one checkpoint may be `paper_trade`, and non-action repeats use `observation_only`. Promotion counts deduplicate by signal date/ticker. `shares` must equal `final_shares` on the action row.
