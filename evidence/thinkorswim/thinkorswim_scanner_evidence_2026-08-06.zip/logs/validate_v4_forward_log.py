"""Validate the frozen V4 forward-paper log. Logging integrity, not profitability."""
import csv, datetime as dt, math, sys
from zoneinfo import ZoneInfo
from pathlib import Path

path = Path(sys.argv[1] if len(sys.argv) > 1 else "v4_forward_paper_log.csv")
required = {
    "signal_date", "signal_time_et", "signal_time_ct", "ticker", "threshold", "scan_type", "score", "atr_pct",
    "mfi_ok", "rsi_ok", "bollinger_ok", "ichimoku_ok", "darvas_ok",
    "confirm_count", "atr_cap_pass", "v4_pass", "eligible", "load_error",
    "affordability_stage_used", "estimated_affordable_shares", "affordability_stage_pass",
    "account_input", "risk_percent", "max_position_percent", "risk_budget",
    "risk_per_share", "risk_limited_shares", "capital_limited_shares",
    "final_shares", "sizing_status", "shares", "planned_entry", "next_open_entry",
    "planned_stop", "bid_ask_spread", "slippage_per_share", "fees_per_share", "round_trip_cost_per_share"
}
components = ["mfi_ok", "rsi_ok", "bollinger_ok", "ichimoku_ok", "darvas_ok"]
binary = components + ["atr_cap_pass", "v4_pass", "eligible"]
allowed_status = {"paper_trade", "no_trade_risk", "no_trade_capital",
                  "no_trade_sizing", "invalid_inputs", "load_error", "skip",
                  "observation_only"}
errors, seen, rows_by_signal = [], set(), {}

def number(row, col, line, required_value=True):
    s = row.get(col, "").strip()
    if not s:
        if required_value: errors.append(f"line {line}: blank {col}")
        return None
    try: return float(s)
    except ValueError:
        errors.append(f"line {line}: invalid {col} {s!r}"); return None

def whole(row, col, line, required_value=True):
    x = number(row, col, line, required_value)
    if x is None: return None
    if not x.is_integer() or x < 0:
        errors.append(f"line {line}: {col} must be a nonnegative whole number")
        return None
    return int(x)

with path.open(newline="", encoding="utf-8-sig") as f:
    reader = csv.DictReader(f); rows = list(reader)
    missing = required - set(reader.fieldnames or [])
    if missing: errors.append("missing columns: " + ", ".join(sorted(missing)))
    for line, row in enumerate(rows, 2):
        ticker = row.get("ticker", "").strip().upper()
        date = row.get("signal_date", "").strip()
        try: dt.date.fromisoformat(date)
        except ValueError: errors.append(f"line {line}: invalid signal_date {date!r}")
        if not ticker: errors.append(f"line {line}: blank ticker")
        time = row.get("signal_time_et", "").strip()
        ct_time = row.get("signal_time_ct", "").strip()
        try:
            et_value = dt.time.fromisoformat(time)
            ct_value = dt.time.fromisoformat(ct_time)
            day_value = dt.date.fromisoformat(date)
            et_stamp = dt.datetime.combine(day_value, et_value, ZoneInfo("America/New_York"))
            expected_ct = et_stamp.astimezone(ZoneInfo("America/Chicago")).strftime("%H:%M")
            if ct_value.strftime("%H:%M") != expected_ct:
                errors.append(f"line {line}: signal_time_ct inconsistent with signal_time_et/date; expected {expected_ct}")
        except ValueError:
            errors.append(f"line {line}: invalid ET/CT signal time {time!r}/{ct_time!r}")
        scan_type = row.get("scan_type", "").strip()
        if not scan_type: errors.append(f"line {line}: blank scan_type")
        key = (date, time, ct_time, ticker, scan_type)
        if key in seen: errors.append(f"line {line}: duplicate checkpoint key {date}/{time}/{ticker}/{scan_type}")
        seen.add(key)
        rows_by_signal.setdefault((date, ticker), []).append((line, row))

        threshold = number(row, "threshold", line)
        if threshold is not None and threshold != 65: errors.append(f"line {line}: threshold must be 65")
        score = number(row, "score", line)
        if score is not None and not 0 <= score <= 100: errors.append(f"line {line}: score outside 0-100")
        for col in binary:
            if row.get(col, "").strip() not in {"0", "1"}:
                errors.append(f"line {line}: {col} must be populated 0/1")
        flags = [int(row[c]) for c in components if row.get(c, "").strip() in {"0", "1"}]
        count = whole(row, "confirm_count", line)
        if count is not None and not 0 <= count <= 5: errors.append(f"line {line}: confirm_count outside 0-5")
        if len(flags) == 5 and count is not None and count != sum(flags):
            errors.append(f"line {line}: confirm_count does not match five components")

        atr = number(row, "atr_pct", line)
        if atr is not None and atr < 0: errors.append(f"line {line}: atr_pct must be nonnegative")
        cap_expected = atr is not None and atr < 4.0
        if row.get("atr_cap_pass", "") in {"0", "1"} and (row["atr_cap_pass"] == "1") != cap_expected:
            errors.append(f"line {line}: atr_cap_pass inconsistent with strict atr_pct < 4.0")
        pass_expected = count is not None and count >= 4 and cap_expected and row.get("eligible") == "1"
        if row.get("v4_pass", "") in {"0", "1"} and (row["v4_pass"] == "1") != pass_expected:
            errors.append(f"line {line}: v4_pass inconsistent with eligible + confirmations + ATR cap")

        affordability_used = row.get("affordability_stage_used", "").strip()
        if affordability_used not in {"0", "1"}:
            errors.append(f"line {line}: affordability_stage_used must be 0/1")
        estimated_affordable = whole(row, "estimated_affordable_shares", line, affordability_used == "1")
        affordability_pass = row.get("affordability_stage_pass", "").strip()
        if affordability_used == "1":
            if affordability_pass not in {"0", "1"}:
                errors.append(f"line {line}: affordability_stage_pass required 0/1 when stage used")
            elif estimated_affordable is not None and (affordability_pass == "1") != (estimated_affordable >= 1):
                errors.append(f"line {line}: affordability_stage_pass inconsistent with estimated shares")
        elif affordability_pass or row.get("estimated_affordable_shares", "").strip():
            errors.append(f"line {line}: affordability outputs must be blank when stage not used")

        status = row.get("sizing_status", "").strip()
        if status and status not in allowed_status: errors.append(f"line {line}: invalid sizing_status {status!r}")
        sizing_required = (row.get("v4_pass") == "1" and
                           row.get("load_error", "").strip() in {"", "0"} and
                           status != "observation_only")
        acct = number(row, "account_input", line, sizing_required)
        rpct = number(row, "risk_percent", line, sizing_required)
        cpct = number(row, "max_position_percent", line, sizing_required)
        budget = number(row, "risk_budget", line, sizing_required)
        rps = number(row, "risk_per_share", line, sizing_required)
        entry = number(row, "next_open_entry", line, sizing_required)
        stop = number(row, "planned_stop", line, sizing_required)
        spread = number(row, "bid_ask_spread", line, sizing_required)
        slippage = number(row, "slippage_per_share", line, sizing_required)
        fees = number(row, "fees_per_share", line, sizing_required)
        cost = number(row, "round_trip_cost_per_share", line, sizing_required)
        rs = whole(row, "risk_limited_shares", line, sizing_required)
        cs = whole(row, "capital_limited_shares", line, sizing_required)
        final = whole(row, "final_shares", line, sizing_required)
        alias = whole(row, "shares", line, sizing_required)
        if sizing_required and status not in allowed_status:
            errors.append(f"line {line}: sizing_status required for passing row")
        if acct is not None and not 100 <= acct <= 1000:
            errors.append(f"line {line}: account_input outside frozen $100-$1,000 scope")
        if rpct is not None and not math.isclose(rpct, .50, abs_tol=1e-9):
            errors.append(f"line {line}: risk_percent must remain 0.50")
        if cpct is not None and not math.isclose(cpct, 20.0, abs_tol=1e-9):
            errors.append(f"line {line}: max_position_percent must remain 20")
        if rps is not None and rps <= 0: errors.append(f"line {line}: risk_per_share must be positive")
        if entry is not None and entry <= 0: errors.append(f"line {line}: next_open_entry must be positive")
        if spread is not None and spread < 0: errors.append(f"line {line}: bid_ask_spread must be nonnegative")
        if slippage is not None and slippage < 0: errors.append(f"line {line}: slippage_per_share must be nonnegative")
        if fees is not None and fees < 0: errors.append(f"line {line}: fees_per_share must be nonnegative")
        if cost is not None and cost < 0: errors.append(f"line {line}: round_trip_cost_per_share must be nonnegative")
        if None not in (spread, slippage, fees, cost) and cost + .001 < spread + slippage + fees:
            errors.append(f"line {line}: round-trip cost understates spread plus slippage plus fees")
        if None not in (entry, stop, cost, rps):
            if entry <= stop or not math.isclose(rps, entry - stop + cost, abs_tol=.011):
                errors.append(f"line {line}: entry/stop/cost/risk_per_share mismatch")
        if None not in (acct, rpct, budget) and not math.isclose(budget, acct * rpct / 100, abs_tol=.011):
            errors.append(f"line {line}: risk_budget arithmetic mismatch")
        if None not in (budget, rps, rs) and rps > 0 and rs != math.floor(budget / rps):
            errors.append(f"line {line}: risk_limited_shares arithmetic mismatch")
        if None not in (acct, cpct, entry, cs) and entry > 0 and cs != math.floor(acct * cpct / 100 / entry):
            errors.append(f"line {line}: capital_limited_shares arithmetic mismatch")
        if None not in (rs, cs, final) and final != min(rs, cs):
            errors.append(f"line {line}: final_shares is not the minimum constraint")
        if None not in (final, alias) and final != alias:
            errors.append(f"line {line}: shares alias differs from final_shares")
        if final == 0 and status == "paper_trade": errors.append(f"line {line}: zero shares cannot be paper_trade")
        if status == "paper_trade" and affordability_used == "1" and affordability_pass != "1":
            errors.append(f"line {line}: paper_trade cannot bypass failed affordability stage")
        if final is not None and final > 0 and status == "no_trade_sizing":
            errors.append(f"line {line}: positive shares inconsistent with no_trade_sizing")

# Repeated intraday checkpoints are observations of one daily signal, not
# independent trades. Daily completed-session fields must remain invariant and
# at most one checkpoint may carry the paper action.
stable_fields = ["threshold", "score", "atr_pct"] + components + [
    "confirm_count", "atr_cap_pass", "eligible", "v4_pass"]
for (date, ticker), group in rows_by_signal.items():
    clean = [(line, row) for line, row in group if row.get("load_error", "").strip() in {"", "0"}]
    for col in stable_fields:
        vals = {row.get(col, "").strip() for _, row in clean}
        if len(vals) > 1: errors.append(f"{date}/{ticker}: checkpoint drift in {col}")
    trades = [line for line, row in group if row.get("sizing_status", "").strip() == "paper_trade"]
    if len(trades) > 1: errors.append(f"{date}/{ticker}: multiple paper_trade checkpoints on lines {trades}")

if errors:
    print(f"INVALID: {len(rows)} rows, {len(errors)} errors")
    print("\n".join(errors)); raise SystemExit(1)
print(f"VALID: {len(rows)} rows")
