"""Validate prospective V4.2 alert observations. Does not evaluate profitability."""
from __future__ import annotations
import csv, datetime as dt, math, sys
from pathlib import Path

REQUIRED = [
    "session_date", "symbol", "chart_minutes", "script_version", "qualifying_bar_start_ct", "qualifying_bar_close_ct",
    "alert_time_ct", "alert_latency_seconds", "alert_sound", "time_gate", "above_vwap", "too_extended",
    "cloud_ok", "box_ok", "bb_ok", "mfi_value", "mfi_positive_flow", "mfi_negative_flow", "rsi_value",
    "vwap_distance_atr", "bid_ask_spread", "expected_slippage_per_share", "fees_per_share", "planned_entry", "planned_stop",
    "round_trip_cost_per_share", "risk_per_share", "account_equity", "risk_percent",
    "position_cap_percent", "risk_limited_shares", "capital_limited_shares",
    "calculated_shares", "action", "notes",
]
BOOL = {"yes", "no"}
VERSIONS = {"V4.2", "V4.2.1", "V4.2.2"}

def fail(message: str) -> None:
    raise ValueError(message)

def validate(path: Path) -> int:
    with path.open(newline="", encoding="utf-8-sig") as handle:
        reader = csv.DictReader(handle)
        if reader.fieldnames != REQUIRED:
            fail(f"header mismatch: expected {REQUIRED}")
        rows = list(reader)
    seen: set[tuple[str, str]] = set()
    for n, row in enumerate(rows, 2):
        prefix = f"row {n}"
        day = dt.date.fromisoformat(row["session_date"])
        symbol = row["symbol"].strip().upper()
        if not symbol or symbol != row["symbol"]: fail(f"{prefix}: symbol must be uppercase")
        minutes = int(row["chart_minutes"])
        if minutes not in (5, 15): fail(f"{prefix}: chart_minutes must be 5 or 15")
        if row["script_version"] not in VERSIONS: fail(f"{prefix}: unknown script_version")
        bar_start = dt.time.fromisoformat(row["qualifying_bar_start_ct"])
        bar_close = dt.time.fromisoformat(row["qualifying_bar_close_ct"])
        alert = dt.time.fromisoformat(row["alert_time_ct"])
        if not dt.time(8, 45) <= bar_start < dt.time(14, 30):
            fail(f"{prefix}: qualifying bar start outside frozen 08:45–14:30 CT window")
        start_dt = dt.datetime.combine(day, bar_start)
        close_dt = dt.datetime.combine(day, bar_close)
        alert_dt = dt.datetime.combine(day, alert)
        bar_length = (close_dt - start_dt).total_seconds() / 60
        if bar_length != minutes:
            fail(f"{prefix}: qualifying bar start/close must span exactly {minutes}m, got {bar_length:g}m")
        if alert_dt < close_dt:
            fail(f"{prefix}: Ring cannot arrive before qualifying bar closes")
        latency = float(row["alert_latency_seconds"])
        actual_latency = (alert_dt - close_dt).total_seconds()
        if latency < 0 or not math.isclose(latency, actual_latency, abs_tol=.5):
            fail(f"{prefix}: alert_latency_seconds mismatch")
        if row["alert_sound"] != "Ring": fail(f"{prefix}: only closed-bar Ring rows belong here")
        for field in ("time_gate", "above_vwap", "too_extended", "cloud_ok", "box_ok", "bb_ok"):
            if row[field] not in BOOL: fail(f"{prefix}: {field} must be yes/no")
        required_yes = ("time_gate", "above_vwap", "cloud_ok", "box_ok", "bb_ok")
        if any(row[field] != "yes" for field in required_yes) or row["too_extended"] != "no":
            fail(f"{prefix}: Ring violates a frozen confirmation gate")
        mfi, rsi = float(row["mfi_value"]), float(row["rsi_value"])
        positive_flow, negative_flow = float(row["mfi_positive_flow"]), float(row["mfi_negative_flow"])
        if positive_flow < 0 or negative_flow < 0: fail(f"{prefix}: negative MFI flow sum")
        if negative_flow == 0 and positive_flow == 0:
            expected_mfi = 50.0 if row["script_version"] == "V4.2.2" else 100.0
        elif negative_flow == 0:
            expected_mfi = 100.0
        else:
            expected_mfi = 100 - 100 / (1 + positive_flow / negative_flow)
        if not math.isclose(mfi, expected_mfi, abs_tol=.11): fail(f"{prefix}: MFI value/flow arithmetic mismatch")
        if not (0 <= mfi <= 100 and 0 <= rsi <= 100): fail(f"{prefix}: oscillator outside 0–100")
        if mfi <= 50 or rsi <= 50: fail(f"{prefix}: Ring requires MFI and RSI above 50")
        distance = float(row["vwap_distance_atr"])
        if not 0 <= distance <= 1.0: fail(f"{prefix}: VWAP distance outside frozen 0–1.0 ATR")
        spread_text = row["bid_ask_spread"].strip()
        spread = float(spread_text) if spread_text else None
        if spread is not None and spread < 0: fail(f"{prefix}: negative bid/ask spread")
        slippage = float(row["expected_slippage_per_share"])
        fees = float(row["fees_per_share"])
        if slippage < 0 or fees < 0: fail(f"{prefix}: negative slippage/fees")
        entry, stop = float(row["planned_entry"]), float(row["planned_stop"])
        cost, rps = float(row["round_trip_cost_per_share"]), float(row["risk_per_share"])
        if cost < 0: fail(f"{prefix}: negative round-trip cost")
        if spread is not None and cost + 1e-9 < spread + slippage + fees:
            fail(f"{prefix}: round-trip cost cannot be below spread + slippage + fees")
        if entry <= stop or abs((entry - stop + cost) - rps) > 0.011:
            fail(f"{prefix}: long entry/stop/risk mismatch")
        account, risk_pct, cap_pct = float(row["account_equity"]), float(row["risk_percent"]), float(row["position_cap_percent"])
        if not 100 <= account <= 1000: fail(f"{prefix}: account outside $100-$1,000 scope")
        if not math.isclose(risk_pct, .50): fail(f"{prefix}: risk_percent must be 0.50")
        if not math.isclose(cap_pct, 20.0): fail(f"{prefix}: position_cap_percent must be 20")
        try:
            risk_shares, cap_shares, shares = (int(row[x]) for x in
                ("risk_limited_shares", "capital_limited_shares", "calculated_shares"))
        except ValueError: fail(f"{prefix}: share fields must be whole integers")
        if min(risk_shares, cap_shares, shares) < 0: fail(f"{prefix}: negative shares")
        expected_risk = math.floor(account * risk_pct / 100 / rps)
        expected_cap = math.floor(account * cap_pct / 100 / entry)
        if risk_shares != expected_risk: fail(f"{prefix}: risk_limited_shares mismatch")
        if cap_shares != expected_cap: fail(f"{prefix}: capital_limited_shares mismatch")
        if shares != min(risk_shares, cap_shares): fail(f"{prefix}: calculated_shares is not minimum constraint")
        if row["action"] not in {"paper", "skip"}: fail(f"{prefix}: action must be paper/skip")
        if shares == 0 and row["action"] != "skip": fail(f"{prefix}: zero shares must be skip")
        if row["action"] == "paper" and spread is None: fail(f"{prefix}: paper action requires observed bid/ask spread")
        if row["action"] == "paper" and positive_flow == 0 and negative_flow == 0:
            fail(f"{prefix}: paper action cannot rely on degenerate no-flow MFI")
        key = (day.isoformat(), symbol)
        if key in seen: fail(f"{prefix}: duplicate Ring for first-confirmation-only session")
        seen.add(key)
    print(f"PASS: {len(rows)} V4.2 Ring rows validated")
    return 0

if __name__ == "__main__":
    source = Path(sys.argv[1]) if len(sys.argv) > 1 else Path(__file__).with_name("v4_2_intraday_alert_log.csv")
    try: raise SystemExit(validate(source))
    except (ValueError, TypeError) as exc:
        print(f"FAIL: {exc}", file=sys.stderr); raise SystemExit(1)
