"""Regression tests for three-checkpoint operational log."""
import csv, subprocess, sys, tempfile
from pathlib import Path
HERE=Path(__file__).parent; VALIDATOR=HERE/"validate_v4_checkpoint_log.py"
FIELDS=next(csv.reader((HERE/"V4_TOMORROW_CHECKPOINT_LOG_2026-08-07.csv").open(encoding="utf-8-sig")))

def row(ct,et,v3s,v3e,v4s,v4e):
 d={k:"" for k in FIELDS};d.update(session_date="2026-08-07",scheduled_time_ct=ct,scheduled_time_et=et,v3_scan_start_ct=v3s,v3_scan_end_ct=v3e,v3_count="2",v4_scan_start_ct=v4s,v4_scan_end_ct=v4e,v4_count="1",v3_symbols_pipe="AAA|BBB",v4_symbols_pipe="AAA",load_error_count="0",score_day_verified="yes",score_extended_hours_off="yes",chart_minutes="5",chart_extended_hours_off="yes",active_alert_study="V4_2_1_IntradayConfirm_EXPERIMENTAL")
 return d
base=[row("08:35","09:35","08:35","08:36","08:36","08:37"),row("10:30","11:30","10:30","10:31","10:31","10:32"),row("14:15","15:15","14:15","14:16","14:16","14:17")]

def accepted(rows):
 with tempfile.TemporaryDirectory() as td:
  p=Path(td)/"c.csv"
  with p.open("w",newline="",encoding="utf-8") as f:w=csv.DictWriter(f,fieldnames=FIELDS);w.writeheader();w.writerows(rows)
  r=subprocess.run([sys.executable,str(VALIDATOR),str(p),"--complete"],capture_output=True,text=True)
  return r.returncode==0,r.stdout+r.stderr

zero={**base[0],"v3_count":"0","v4_count":"0","v3_symbols_pipe":"","v4_symbols_pipe":""}
cases=[("valid",base,True),("valid_zero_result",[zero,*base[1:]],True),("timezone_mismatch",[{**base[0],"scheduled_time_et":"08:35"},*base[1:]],False),("count_mismatch",[{**base[0],"v4_count":"2"},*base[1:]],False),("not_subset",[{**base[0],"v4_symbols_pipe":"CCC"},*base[1:]],False),("duplicate_symbol",[{**base[0],"v3_count":"3","v3_symbols_pipe":"AAA|AAA|BBB"},*base[1:]],False),("bad_order",[{**base[0],"v4_scan_start_ct":"08:34"},*base[1:]],False),("setting_not_proved",[{**base[0],"chart_extended_hours_off":"no"},*base[1:]],False)]
passed=0
for name,rows,want in cases:
 got,out=accepted(rows);ok=got==want;print(("PASS" if ok else "FAIL"),name,"accepted="+str(got));passed+=ok
 if not ok:print(out)
print(f"PASS: {passed}/{len(cases)} checkpoint validator cases")
raise SystemExit(0 if passed==len(cases) else 1)
