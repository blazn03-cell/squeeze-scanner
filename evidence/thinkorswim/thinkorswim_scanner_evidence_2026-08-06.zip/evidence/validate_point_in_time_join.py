"""Require every market row to map to exactly one effective membership interval."""
import csv,datetime as dt,sys
from collections import defaultdict
from pathlib import Path
if len(sys.argv)<3:raise SystemExit("usage: validate_point_in_time_join.py membership.csv market.csv")
membership,market=map(Path,sys.argv[1:3]);intervals=defaultdict(list);errors=[]
with membership.open(newline="",encoding="utf-8-sig") as f:
 for line,r in enumerate(csv.DictReader(f),2):
  try:
   start=dt.date.fromisoformat(r["member_from"]);end=dt.date.fromisoformat(r["member_to"]) if r["member_to"] else dt.date.max
   intervals[r["security_id"].strip().upper()].append((start,end,r["identity_eligible"],line))
  except (KeyError,ValueError) as e:errors.append(f"membership line {line}: {e}")
eligible=0;total=0
with market.open(newline="",encoding="utf-8-sig") as f:
 for line,r in enumerate(csv.DictReader(f),2):
  total+=1
  try:sid=r["security_id"].strip().upper();day=dt.date.fromisoformat(r["trade_date"])
  except (KeyError,ValueError) as e:errors.append(f"market line {line}: {e}");continue
  matches=[x for x in intervals.get(sid,[]) if x[0]<=day<x[1]]
  if len(matches)!=1:errors.append(f"market line {line}: {sid}/{day} maps to {len(matches)} membership intervals")
  elif matches[0][2]=="1":eligible+=1
if errors:
 print("INVALID",len(errors));print("\n".join(errors));raise SystemExit(1)
print(f"VALID JOIN: {total} market rows, {eligible} identity-eligible rows")
