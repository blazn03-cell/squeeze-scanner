# V4 split-stage exact parity — 2026-08-06

After the repaired DAY Score column loaded all 34 fresh V3 symbols, the split-stage result was independently reconstructed from the visible component values:

1. fresh V3 membership;
2. model ATR strictly below 4.0%;
3. DAY confirmation count at least 4/5; and
4. common-equity/ADR identity gate.

The reconstructed set contained exactly nine symbols: CHD, EXPE, LTM, NWS, SAN, SCHW, SWK, WBS, and ZBH.

This matched the fresh 13:25 CT live split-stage scan exactly: **9 expected, 9 observed, zero missing, zero extra**.

This is strong same-day formula/configuration parity evidence for the split-stage workflow. It does not prove tomorrow's persistence, alert delivery, or profitability. The combined whole-universe version remains unsupported because it timed out.
