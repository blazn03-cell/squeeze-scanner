# Small-account affordability prefilter — experimental

`V4_SmallAccountAffordability_Daily_Scan_EXPERIMENTAL.ts` is a lightweight **third stage** applied only after fresh V4/V4.7 candidates. Set DAY aggregation and extended hours off.

`V4_EstimatedAffordableShares_CustomQuote_EXPERIMENTAL.ts` exposes the same estimate as a DAY watchlist column. Green means the planning assumptions estimate at least one share; dark red means zero. It is an upper-bound planning display, not permission to trade.

It asks whether at least one whole share is theoretically affordable using prior completed DAY ATR, planned entry = prior close + 0.4 ATR, 0.50% risk, 20% capital cap, and a minimum cost/share assumption. At $100 and $0.06 cost, an example $10 stock with $0.20 ATR estimates one share; a $21 price fails the capital cap and $0.30 ATR fails the risk cap.

This does **not** create an evidenced $100 opportunity. It only removes names that are mathematically impossible before chart review. Actual entry and observed spread are unknown until the Ring; the fail-closed manual sizing study must recalculate, and zero final shares means skip.

Prospective candidate rows explicitly record whether this stage was used, its estimated whole shares, and its pass/fail result. This allows estimated-versus-final affordability error to be audited instead of silently discarding zero-share outcomes.

Do not combine this formula with the whole-universe V3/V4 expression. Use the saved-query chain to avoid the already observed scanner timeout:

1. fresh canonical V3;
2. V4 or versioned V4.7 confirmation/ATR stage;
3. affordability prefilter for the chosen account;
4. Ring chart and actual-entry/spread sizing.

No historical edge is claimed. The archived historical strategy observations produced zero affordable $100 trades under frozen rules.
