"""Static invariants and arithmetic cases for the fail-closed sizing study."""
import math
from pathlib import Path

HERE = Path(__file__).resolve().parent
SCRIPTS = HERE.parent / "scripts" if (HERE.parent / "scripts").exists() else HERE
text = (SCRIPTS / "V4_1_ManualEntryRiskShares_ChartStudy.ts").read_text(encoding="utf-8-sig")
required = [
    "input entryPrice = 0.0;",
    "entryPrice > 0",
    "def atr = atrSeries[1];",
    "Floor(riskBudget / riskPerShare)",
    "Floor(accountSize * maxPositionPercent / 100 / entryPrice)",
    "then Min(riskShares, capShares) else 0",
    "ENTER ACTUAL ENTRY PRICE: SIZE DISABLED",
    "ENTER OBSERVED $/SH SPREAD: SIZE DISABLED",
    "def roundTripCostPerShare = observedSpreadPerShare + expectedRoundTripSlippagePerShare + feesPerShare;",
]
for token in required:
    assert token in text, token
assert "AddOrder" not in text

def size(account, entry, atr, spread=.02, slippage=.04, fees=0, risk_pct=.5, cap_pct=20, stop_atr=1.5):
    cost = spread + slippage + fees
    valid = 100 <= account <= 1000 and entry > 0 and atr > 0 and spread > 0 and slippage >= 0 and fees >= 0
    stop = entry - stop_atr * atr
    if not valid or stop <= 0:
        return 0
    risk_shares = math.floor(account * risk_pct / 100 / (stop_atr * atr + cost))
    cap_shares = math.floor(account * cap_pct / 100 / entry)
    return min(risk_shares, cap_shares)

cases = [
    ("missing_entry", (250, 0, 0.40), 0),
    ("missing_spread", (250, 10, 0.40, 0), 0),
    ("account_too_small", (99, 10, 0.40), 0),
    ("stop_nonpositive", (250, 1, 1), 0),
    ("capital_limited", (1000, 20, 0.10), 10),
    ("risk_limited", (1000, 5, 1.0), 3),
]
for name, args, expected in cases:
    actual = size(*args)
    assert actual == expected, (name, actual, expected)
    print("PASS", name, actual)
print(f"PASS: {len(cases)} sizing cases + script invariants")
