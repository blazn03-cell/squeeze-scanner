﻿# V4.2 experimental alert test protocol

This is a separate forward-test arm. Do not overwrite frozen V4.1 and do not trade it live based on historical results.

## Alert timing (chart timezone follows thinkorswim settings)
- Active window: 09:45–15:30 Eastern by default.
- VWAP reclaim: early warning during the crossing bar; it is not a qualified entry.
- Closed-bar confirmation: fires on the first tick of the next bar after all conditions were true on a completed bar.
- Log the qualifying bar's **start and close** separately. The Ring occurs when that bar closes, which is also when the next bar begins: five minutes after a 5m bar's start or fifteen minutes after a 15m bar's start.

## Added hypothesis
V4.2 rejects confirmations more than 1.0 intraday ATR above VWAP. This attempts to reduce chasing. It is not yet supported by out-of-sample evidence.

## Required Ring-log fields
Use the exact header in `v4_2_intraday_alert_log.csv`. It records date/symbol, chart minutes, qualifying-bar and delayed-alert times, every confirmation gate, oscillator values, VWAP distance, observed spread, entry/stop/cost/risk, frozen account/risk/cap inputs, both limiting share counts, final shares, action, and notes. Do not invent a shorter parallel schema.

## Verification gates
1. Compile with no errors on both 5-minute and 15-minute charts.
2. Confirm no alerts before 09:45 or after 15:30 Eastern.
3. Confirm the Ring occurs only after the qualifying candle has closed.
4. Compare the 5-minute and 15-minute timestamps; never treat duplicate alerts as two observations.
5. Reject any alert whose risk study returns zero shares.
6. A mechanics diagnostic may be reported after 30 independent alerts, but promotion still requires at least 100 forward-paper trades per arm and every gate in `v3_tomorrow_protocol.md`.
7. Keep the system paper-only while the interval includes zero or live scan/quote parity is unresolved.

## Interpretation
An alert proves only that the coded conditions were observed. It does not identify a profitable trade and cannot tell immediately whether it was the “right one.” Correctness is assessed first by code/alert parity, then by prospective outcomes across many observations.

## 60-day alert-frequency finding
A selected-universe Yahoo 5-minute replay showed that V4.1 can transition false-to-true multiple times per ticker/session. V4.2 now defaults `firstConfirmationOnlyPerSession = yes`, allowing only the first closed-bar confirmation sound/arrow each session. Later transitions remain visible in underlying labels but are not independent trade observations. This change is experimental and requires live compilation.
