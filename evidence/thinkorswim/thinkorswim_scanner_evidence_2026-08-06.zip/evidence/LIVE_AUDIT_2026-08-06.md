# Live thinkorswim audit — 2026-08-06

## Executive status

The separate V4 arm is now installed and runtime-verified in Stock Hacker. It does **not** demonstrate profitability; it is a stricter risk/confirmation filter that must remain paper-only until the frozen forward-test gates are met.

## Verified live configuration

- Thinkorswim was connected to realtime data.
- Canonical V3 saved query remains `V3_Confirmed_Equity_2026-08-04`.
- New saved query is `V4_Confirmed_Equity_2026-08-06`.
- V4 uses `Scan in: V3_Confirmed_Equity_2026-08-04` and one lightweight V4 study filter at daily (`D`) aggregation.
- V4 defaults are `maxATRpct = 4.0` and `minConfirms = 4`.
- The corrected V4 query was saved without the unsaved-change asterisk after replacing an initially mis-saved universe.
- `V4_IntradayConfirm_v2` compiled successfully on-platform. It must be used only on 5m/15m regular-hours charts.
- The V4 confirmation-count custom quote and small-account risk study still require final on-platform placement/visual verification.

## Live candidate comparison

At 13:14 CT, the restored V3 query returned 34 matches. The complete 34-symbol export was not captured, so no full-cohort claim is made from the visible rows alone.

At 13:25:13 CT, the split-stage V4 query completed with 9 of 9 matches:

`CHD, EXPE, LTM, NWS, SAN, SCHW, SWK, WBS, ZBH`

This is a 73.5% reduction from the live V3 count (9 versus 34). It is evidence that the ATR cap and confirmation layer discriminate; it is **not** evidence that the retained names are profitable.

The corrected scan took about 66 seconds after a manual restart. This is slow but completed without a script timeout. Evidence: `tos_v4_split_stage_results_2026-08-06_1325CT.png` and `v4_live_candidates_2026-08-06_1325CT.csv`.

## Platform defects and resolutions

1. Runtime-selected lengths in `Highest`/`Lowest` were rejected. The intraday study now computes fixed 78-bar and 26-bar alternatives separately.
2. Direct indexing of parenthesized Ichimoku expressions was rejected. Span series are now named before indexing.
3. The original intraday all-green state omitted Darvas. V4.1 requires Darvas by default and adds a completed-bar confirmation alert.
4. The combined whole-universe V4 scan compiled but produced `Error: Script execution timeout.` It is retained only as an audit artifact, not the deployment path.
5. The working architecture is a saved V3 dynamic universe feeding the lightweight V4 confirmation/ATR filter.
6. Saving while the loaded V3 setup also scanned inside V3 produced a circular-reference warning and temporarily substituted an unrelated universe. This was corrected by loading the V4 setup, selecting V3 as its external `Scan in` universe, rerunning to 9 results, and overwriting the V4 query.

## Alert interpretation

- VWAP reclaim is an intrabar heads-up and can reverse before candle close.
- Full confirmation uses the prior completed chart candle and therefore arrives at the start of the next bar (about 5 minutes on a 5m chart or 15 minutes on a 15m chart).
- Daily candidates are not entry signals. Require the intraday layer, defined stop, acceptable spread, and nonzero risk-sized shares.

## Historical evidence limits

Pinned adjusted daily test, 2021-08-04 through 2026-08-03, current-watchlist-derived universe, next-open execution, $0.03/share each side:

- V3: 59 trades, 47.46% win rate, mean 1.119%, profit factor 1.432, 95% CI -0.827% to 3.220%.
- V4: 42 trades, 50.00% win rate, mean 1.054%, profit factor 1.419, 95% CI -1.274% to 3.443%.

Every confidence interval includes zero. The universe has selection/survivorship bias. V4 reduced trade count but did not improve historical expectancy or profit factor in this test.

## Remaining priority work

1. Add and visually verify `V4_ConfirmLayer_CustomQuote_v2.ts` as `V4_ConfirmCount` on a copied watchlist layout.
2. Install and verify `V4_SmallAccountRiskShares_ChartStudy.ts`; zero shares means skip.
3. Apply `V4_IntradayConfirm_ChartStudy_v2.ts` to a 5m and 15m chart and verify both alert paths.
4. Capture the full V3 export and reconcile every V4 pass/fail reason.
5. Continue paper logging tomorrow; do not promote to real money until pre-registered gates are satisfied.

## 2026-08-06 watchlist quote configuration audit
- Captured the complete 34-symbol V3 cohort in `v3_full_cohort_2026-08-06.csv` and screenshot evidence.
- Found a material configuration defect: the V4 confirmation custom quote was still set to 4-hour aggregation. Extended-hours was off.
- The 4-hour values are preserved only as defect evidence and must not be compared with the daily V4 scan.
- Confirmed through the thinkorswim editor that the intended quote aggregation is `D` (Day); the dialog was closed without committing because the oversized modal hid its save controls. Therefore the live column remains uncorrected and must not be treated as verified.
- Scanner itself remains the verified split-stage daily implementation; the quote column is a display/parity aid only.

### Configuration re-check at 13:5x CT
A direct reopen of the active `Score` custom quote proved two simultaneous defects: aggregation was `4 h` and `Include Extended-Hours Trading session` was checked. This is stronger evidence than the earlier visual inference. The quote remains uncommitted/unchanged because the editor opened on a monitor outside the controllable window bounds. Evidence: `tos_v4_quote_config_defect_4h_extended_2026-08-06.png`. Until corrected, ignore this column completely; the verified daily split-stage scanner remains authoritative.

## P0 temporal-stability discrepancy
The 12:57 CT V3 capture (13 symbols) and later V3 watchlist capture (34 symbols) intersect on only SAN and FSLY. Jaccard similarity is 4.44%. Because the canonical formula uses completed DAY bars, this discrepancy indicates saved-query/configuration/source/capture mismatch rather than evidence of legitimate intraday signal change. Both cohorts are untrusted for parity claims until same-query settings and two repeated reruns are captured. See `v3_intraday_cohort_stability_audit_2026-08-06.md`.

## Architecture correction: dynamic source invalidated
The 12:57 CT screenshot proves a direct Stock Hacker V3 run with two DAY filters returned 13 symbols. The later 34-symbol saved dynamic watchlist is therefore best treated as stale/cached membership until disproven. Because the nine-name V4 run scanned inside that dynamic watchlist, its candidate status is invalidated. V4.4 replaces dynamic chaining with a timestamped static-list handoff and exact parity gates. See `V4_4_STATIC_HANDOFF_PROTOCOL.md`.

## Resolution of apparent V3 cohort instability
The prior P0 instability interpretation is retracted. Direct UI testing showed that **loading a saved scan query changes the filter panel but does not automatically rerun the result table**. The old result rows remain visible until `Scan` is pressed. This exactly reproduces how a V3-labeled screen can display a previous cohort.

A fresh V3 scan was explicitly run at approximately 13:57 CT and returned 34 symbols, matching the 34-symbol saved dynamic watchlist. Evidence: `tos_v3_fresh_scan_34_2026-08-06_1357CT.png`. Therefore:

- The 12:57 13-name capture is not proven to be a fresh V3 run and must not be used for temporal-stability comparison.
- The 34-name V3 cohort is re-established as the current verified source.
- The nine-name V4 cohort is restored as source-parity-reverified.
- The static-handoff protocol remains a useful fail-safe, but dynamic chaining is not invalidated by this evidence.

New operational rule: after loading any saved query, always press `Scan`, wait for completion, and record the result timestamp/count. A query title alone does not authenticate the rows below it.

## Small-account external sizing diagnostic
Using observed prices and model ATR% as an approximation of the chart study arithmetic: all nine V4 candidates size to zero shares at $100 and $250; at $500 only SAN approximates one share; at $1,000 SAN approximates three shares and NWS/WBS one share each. This is not live parity and not a trade recommendation. See `v4_small_account_sizing_diagnostic_2026-08-06.md` and `.csv`.

## 2026-08-06 continuation — experimental alert-quality arm
- Added `V4_2_IntradayConfirm_ChartStudy_EXPERIMENTAL.ts` without modifying frozen V4.1.
- Hypothesis under test: suppress the first 15 minutes, stop new confirmations at 15:30 ET, and reject closes more than 1.0 intraday ATR above VWAP.
- Closed-bar confirmation remains deliberately delayed to the next bar; VWAP reclaim remains an early warning only.
- Static checks passed, including aggregation guard, session guard, delayed-bar logic, anti-chase gate, risk prompt, and absence of order placement.
- Live thinkorswim compilation and alert-timestamp parity are still required before this arm is usable even for structured paper logging.

## 2026-08-06 live chart verification — 14:10 CT
- Inspected all open Flexible Grid workspaces. Existing active charts were 30m, 1h, 4h, and daily; none was configured to the required 5m/15m aggregation for the V4 intraday alerts.
- Configured an unused Flexible Grid pane as SAN, 5-day/5-minute, leaving the user's populated layouts unchanged.
- Located the already-installed `V4_IntradayConfirm_v2` study and applied it to that 5-minute pane.
- Live compile/render succeeded. Visible labels at verification: `VWAP WAIT`, `CLOUD WAIT`, `BOX INSIDE`, `BB ABOVE MID`, `MFI 52–55`, `RSI 47–50`, and `INTRADAY WAIT`.
- The result correctly did **not** claim a confirmation because multiple gates were false.
- Existing SAN risk chart separately rendered: `PAPER ONLY | Account input $250.00 | Risk $1.25 | Risk/share $0.78 | Capital cap $50.00 | Shares 1`, proving the small-account study renders, but not validating a fill or outcome.
- Remaining alert gate: observe an actual closed-bar transition and timestamp the Ring. A compile/render success alone does not prove alert timing.

## 2026-08-06 quote correction attempt — staged, not yet proven saved
- Reopened the live `Score` custom quote and reconfirmed the loaded code is the V4.1 prior-session confirmation-count formula.
- The live editor again showed the defect: `4h` aggregation with extended-hours enabled.
- Changed aggregation selection to `D` and disabled extended hours in the open editor.
- The editor footer/OK control remains outside the targetable modal viewport; keyboard default/accelerator attempts did not close it.
- Therefore the correction is **staged but not proven persisted**. Do not claim quote parity until the modal is explicitly saved, reopened, and shows `D` with extended hours absent/off.
- Current watchlist values remain untrusted as proof of daily parity until that save/reopen gate passes.

## 2026-08-06 quote persistence recheck
- Closed the staged editor with Escape, reopened `Score` from Column Set, and directly observed that it reverted to `4h` with extended hours enabled.
- This proves the prior staged D/off change did **not** persist.
- Re-staged D/off again, but the child formula editor still has no reachable OK control in the captured viewport. The live column therefore remains uncorrected and untrusted.
- Column Set itself has a visible OK button, but saving that parent does not substitute for accepting the child formula editor.

## 2026-08-06 live intraday checkpoint — 14:25 CT
- SAN 5-minute V4 study remained live and updating.
- Observed state: VWAP WAIT, CLOUD WAIT, BOX INSIDE, BB WAIT, MFI approximately 21–23, RSI approximately 36–39, INTRADAY WAIT.
- No closed-bar confirmation was present; therefore no Ring timing event could be validated at this checkpoint.
- The rejection is internally consistent: all six required intraday gates were not green.

## 2026-08-06 60-day alert mechanics
- Original selected-current-candidate replay: V4.1 751 transitions/55 dates; V4.2 25/15 dates.
- That V4.2 replay did not yet enforce the live study's first-confirmation-only session state; it is superseded by the corrected result documented below.
- Added first-confirmation-only-per-session logic to the experimental V4.2 script to prevent repeated sounds from being logged as independent observations.
- Static checks pass; live compile remains required.
## 14:42 CT — scoped static audit corrected
- Reclassified the small-account sizing study as an aggregation-agnostic risk chart rather than an intraday confirmation dashboard.
- Re-ran the six-script audit: 30/30 applicable checks passed.
- This does not prove live compilation of the latest V4.2 dedupe revision or alert delivery; those remain open.

## 14:55 CT — quote formula corrected and saved for the active session
- Found a stray `SCHW` token at line 1 causing `Invalid statement: SCHW at 1:18`.
- Replaced the complete formula with the canonical `V4_ConfirmLayer_CustomQuote_v2.ts` content.
- Editor showed aggregation `D`; the error pane cleared.
- Accepted the formula and saved the column set. Score values reloaded as 0-5 counts with green >=4.
- Reopened the column-set dialog and confirmed the live Score column remained on the watchlist, but thinkorswim did not expose the custom formula row for a second editor-open proof. Active-session correction is verified; restart persistence remains to be checked tomorrow.

## 14:50 CT — latest V4.2 compiled and rendered live
- Created `V4_2_IntradayConfirm_EXPERIMENTAL` from the latest 103-line script containing first-alert-per-session dedupe.
- thinkorswim accepted the script with no error pane.
- Study list exposed defaults including 0945/1530 ET and 1.0 ATR anti-chase distance.
- Applied it alongside frozen V4.1 on SAN 5m; the dashboard rendered `TIME WAIT` and `TOO EXTENDED` after the 15:30 ET cutoff.
- This proves compile/render, not alert delivery. No genuine closed-bar Ring alert was expected or observed after cutoff.

## 14:58 CT — duplicate-alert risk removed
- Running frozen V4.1 and experimental V4.2 together produced two dashboard rows and could emit overlapping alerts.
- Disabled V4.1 on the SAN V4.2 test pane; V4.2 remains the only active alert study there.
- V4.1 remains installed and frozen for a separate comparison pane/log arm.
- Operational distinction: `Ding` is only a VWAP-reclaim early warning; `Ring` is the delayed closed-bar confirmation. Never treat a Ding alone as an entry signal.

## 15:05 CT — tomorrow protocol frozen
- Added `V4_6_TOMORROW_LIVE_RUNBOOK.md` with Central-time checkpoints, explicit fresh-scan requirements, genuine-alert evidence fields, small-account hard gates, and promotion requirements.
- Thresholds remain frozen: max ATR 4%, confirms 4/5, V4.2 window 08:45–14:30 CT, anti-chase 1.0 ATR, first confirmation only.

## 15:12 CT — prospective Ring-alert log hardened
- Added an empty prospective V4.2 Ring log and validator.
- Validator enforces 5m/15m, 08:45–14:30 CT, Ring-only rows, next-bar timing, time/VWAP/anti-chase gates, oscillator ranges, 1.0 ATR maximum distance, risk arithmetic, zero-share skip, and one Ring per symbol/session.
- Empty template passed; a deliberately invalid 1.2-ATR row was correctly rejected.

## 15:18 CT — requirement-level completion matrix added
- Audited 20 explicit requirements against authoritative artifacts.
- 14 verified, 1 active-session-only, 4 incomplete, and profitable edge explicitly not demonstrated.
- Open items are restart persistence/extended-hours proof, a genuine Ring, point-in-time universe OOS, and prospective observations.

## 15:41 CT — prospective universe archive started
- Downloaded the official Nasdaq Trader `nasdaqlisted.txt` and `otherlisted.txt` snapshots.
- Both files report creation time `0806202615:41` and were SHA-256 hashed.
- This begins survivorship-safe prospective membership evidence. It does not retroactively repair historical selection bias.

## 15:41 CT — repeatable universe archiver added
- Added `archive_nasdaq_universe.py` to download both official directories, validate their footer/schema, count rows/test issues/ETFs, calculate SHA-256 hashes, and refuse changed same-day overwrites.
- Baseline contains 5,579 Nasdaq rows and 7,530 other-listed rows; raw membership is intentionally broader than the scanner universe and must be filtered point-in-time.

## 15:48 CT — prospective identity prefilter built
- Classified 13,109 official directory rows using transparent identity-only exclusions.
- Retained 5,929 potential equity/ADR identities and excluded 7,180 ETFs, test issues, warrants, units, rights, preferreds, notes/bonds, or malformed symbols.
- Corrected an initial overbroad rule so depositary shares/ADRs remain eligible; live candidate SAN is explicitly retained.
- This is only an identity prefilter. Price, volume, dollar volume, ATR, SMA, and V4 confirmation rules still must be applied with point-in-time market data.

## 15:55 CT — instrument-type contamination found
- Reconciled all 34 fresh V3 symbols to the official directory prefilter.
- 32 were eligible common-equity/ADR identities; UGL and NVDL were official ETFs.
- All nine split-stage V4 candidates were identity-eligible.
- Added a hard workflow gate: no ETF/ETN, warrant, unit, right, preferred, debt, or test issue may enter the common-equity arm.
- Did not hard-code two tickers into thinkScript; that would not generalize to newly listed products.

## 16:02 CT — historical product-type sensitivity
- Historical trade output contained two IWD ETF observations, one per arm.
- Excluding IWD left V3 at 47 trades with mean +0.685% and symbol-cluster CI -2.182% to +3.018%; V4 at 32 trades with mean +1.037% and CI -1.792% to +3.827%.
- The point estimates barely changed and both intervals still include zero. Instrument-type cleanup improves validity but does not demonstrate an edge.

## 16:08 CT — V4.6 package consistency repair
- Found the V4.5 package README had become stale: it still said V4.2 was not live-compiled and the quote remained 4h/on.
- Rebuilt as V4.6 with current verified state, 53 ZIP entries, successful CRC test, and a SHA-256 sidecar.


## 16:15 CT — package payload manifest added
- V4.6 now includes `MANIFEST_SHA256.csv` covering every payload file.
- Independent verification checked all 53 payload hashes/sizes and the ZIP CRC; zero mismatches.

## 16:22 CT — DAY quote fully loaded; aggregation impact measured
- All 34 Score cells loaded after the close.
- Compared with the old 4h observation: 27/34 counts changed and 18 symbols crossed the >=4 gate.
- Old 4h passed 9/34; corrected DAY passed 25/34 before ATR and other V4 gates.
- This proves aggregation materially changed classification. Old 4h observations are invalid for the daily arm.

## 16:28 CT — exact split-stage parity proved
- Independently reconstructed V4 from fresh V3 membership, ATR <4%, repaired DAY count >=4, and identity eligibility.
- Expected nine symbols exactly matched the fresh 13:25 CT live scan: zero missing and zero extra.
- This proves same-day component-to-scan parity for the supported split-stage workflow.

## 16:35 CT — Ring-log validator gate coverage fixed
- Found the validator checked cloud/box/Bollinger fields for yes/no syntax but did not require them to be `yes`.
- It also accepted oscillator values <=50 and negative VWAP distance even though the live V4.2 formula does not.
- Validator now requires time, above-VWAP, cloud, box, Bollinger, MFI>50, RSI>50, and 0–1.0 ATR distance. A deliberately missing cloud gate was rejected.

## 16:42 CT — delayed cutoff timing reconciled
- Found validator rejected an alert delivered exactly 14:30 CT, although V4.2 intentionally delays a valid 14:25 CT 5m qualification to the next bar.
- Validator now requires the qualifying bar before 14:30 but permits final delivery at exactly 14:30.
- Edge test passed for 14:25→14:30 and rejected a qualification beginning at 14:30.

## 16:50 CT — Ring validator regression suite
- Added 11-case regression suite covering valid 5m, final 14:30 delivery, late qualification, Ding rejection, missing cloud/box, MFI boundary, negative/overextended VWAP distance, zero-share paper action, and duplicate session signals.
- 11/11 cases passed.

## 16:58 CT — current completion matrix refreshed
- Current requirement audit: 20 verified, one active-session-only, four incomplete, and profitable edge not demonstrated.
- Remaining live proofs: restart/extended-hours persistence, genuine Ring, point-in-time historical OOS, and prospective sample collection.

## Continuation audit — V4.2.1 clarity-only candidate prepared
- Post-close dashboard showed `TOO EXTENDED` while below VWAP because negative distance and overextension shared one label.
- Prepared V4.2.1 label-only revision: negative distance says `BELOW VWAP`; >1 ATR still says `TOO EXTENDED`.
- Diff verification confirms no signal/alert equation changed. It is not installed or live-compiled; keep V4.2 active until tomorrow's compile test.

## Continuation audit — alert timing decision card and package integrity refresh
- Added an operator card distinguishing Ding from delayed Ring and translating the script window to 08:45-14:30 CT.
- Documented the exact cutoff edge: a 14:25 5m qualification may deliver at 14:30; a qualification beginning at 14:30 is rejected.
- Re-ran the Ring validator regression suite: 11/11 passed.
- Rebuilt V4.6 with 64 entries; ZIP CRC passed, all 63 payload-manifest rows matched size/SHA-256, and README mojibake was removed.
- New outer ZIP SHA-256: A70D42727AB5D05B7FFA20EFDCC1C5F47756683C3721AE689D0A8FA36356D560.
- V4.2.1 live switchover remains unverified; no claim of active installation is made.

## Continuation audit — sizing-default contradiction found and corrected
- Found the packaged risk study still defaulted to 0.25% risk / 10% capital cap, while the preregistered V4 arm, runbook, and verified SAN live observation used 0.50% / 20%.
- Corrected the study defaults to 0.50% / 20%, added invalid-input rejection, and exposed the active risk/cap configuration in a chart label.
- Recalculated the nine-name cohort for $100/$250/$500/$1,000. Approximate executable counts are 0/1/3/7 respectively; positive share count means affordability only, not a trade recommendation.
- Static audit remains 36/36. The revised sizing study has not yet received a fresh thinkorswim compile/render, so that proof remains open.

## Continuation audit — risk-study aggregation defect found
- The sizing script referenced unqualified high/low/close. On the verified 5m chart this made its ATR and prior-close inputs 5-minute data, not the intended completed daily model.
- This invalidates the earlier live sizing parity claim even though the study rendered; rendering did not prove correct aggregation semantics.
- Repaired the script with explicit DAY secondary aggregation for high, low, and close. The sizing result is now designed to remain invariant across supported chart timeframes.
- Expanded the scoped static audit to require the explicit daily reference: 37/37 checks pass.
- Fresh thinkorswim compile/render and 5m-versus-DAY output parity are still required before sizing is marked verified.

## Continuation audit — oscillator edge-case sensitivity
- Found the historical Python RSI approximation produced missing values when average loss was zero, while thinkorswim-style RSI should be 100 for positive-only movement (and 50 when both gain/loss averages are zero).
- Also tested a neutral MFI no-flow convention (50 when both positive and negative flow are zero) against the current thinkScript convention of 100.
- Reran the five-year selected-universe audit. Trade-key membership was identical: 81 total, zero added, zero removed.
- V3 and V4 means changed by less than 0.000002 percentage points; both bootstrap intervals still include zero.
- Yahoo no longer returned FLW history, but FLW supplied zero trades in both outputs. Selection/survivorship bias remains unresolved.
- Did not silently alter the frozen V4 thinkScript MFI rule. Neutral no-flow handling remains a future-version candidate only.

## Continuation audit — intraday extended-hours proof gap
- The chart studies gate alerts by clock time, but MFI/RSI/Bollinger/ATR/Ichimoku/Darvas lookbacks still consume every displayed chart bar.
- On a 5m chart, 78 bars represents one regular session only when extended-hours display is off; otherwise the intended box horizon is contaminated by overnight/premarket bars. The same applies to the 26-bar 15m proxy.
- Existing compile/render evidence does not prove the chart's extended-hours setting. Added a separate incomplete requirement and tomorrow capture procedure.
- A genuine Ring cannot satisfy protocol until aggregation and extended-hours-off are captured together.

## Continuation audit — blank spread column addressed experimentally
- The observed BidAskSpread% column was blank, leaving a material small-account execution-cost gate unavailable.
- Added an experimental live custom quote using bid/ask quote types and midpoint spread percentage. Blank/unsupported quotes remain NaN and must never be interpreted as zero.
- Default 0.25%/0.50% color bands are caution bands only, not demonstrated profitable thresholds.
- Expanded the static audit to eight scripts and live-spread invariants: 42/42 checks pass.
- Regular-hours compile and five-symbol bid/ask arithmetic parity remain required before replacing the existing column.

## Continuation audit — spread quote architecture corrected from official docs
- Schwab's official Custom Quotes documentation explicitly permits direct `bid` and `ask` functions and requires exactly one plot.
- Official `close` documentation limits non-Forex ASK/BID price types to intraday intervals covering no more than 15 days; a DAY custom quote spans one year. This makes an old DAY `close(priceType=ASK/BID)` pattern a plausible cause of blank values, but the old formula must be reopened before calling that cause proven.
- Revised the experimental spread quote to use direct current `bid`/`ask` with no historical indexing.
- Expanded static checks for direct sources and no historical bid/ask indexing: 43/43 pass.
- Live regular-hours compilation and five-symbol parity remain open.

## Continuation audit — risk-study secondary-aggregation guard hardened
- Official Schwab documentation confirms DAY secondary data is valid on 5m/15m/DAY primaries and invalid when the secondary period is below the chart primary (for example, DAY on WEEK).
- Added an explicit supported-chart guard: only 5m, 15m, and DAY are accepted. Unsupported aggregations force zero shares and display a red warning.
- Daily high/low/close remain isolated in separate DAY variables so the ATR calculation preserves secondary context.
- Static audit expanded to 44/44. Live compile and exact 5m/15m/DAY output parity remain open.

## Continuation audit — point-in-time validator lookahead bug corrected
- Found the membership validator's source-as-of test was reversed: it rejected evidence before membership start but accepted evidence first observed after start.
- Corrected the no-lookahead rule: source_asof later than member_from is rejected; on/before start is accepted.
- Made permanent security_id mandatory and changed overlap checks from ticker to permanent ID, allowing legitimate ticker reuse by distinct securities.
- Added eight regression cases; 8/8 passed. The updated template itself validates.
- This strengthens future OOS integrity but does not provide the still-missing point-in-time universe or establish an edge.

## Continuation audit — simultaneous ticker-identity collision gate added
- Permanent-ID overlap checks alone would have allowed two different securities to own the same ticker during overlapping dates, making historical signal identity ambiguous.
- Added a separate ticker-ownership interval check. Non-overlapping ticker reuse by different permanent IDs remains valid; simultaneous ownership is rejected.
- Point-in-time validator regression suite is now 9/9 passing; the template remains valid.

## Continuation audit — V4 forward-log validator hardened
- The prior validator allowed incomplete component flags, blank pass fields, fractional shares truncated to integers, duplicate signal rows, ATR-cap mismatch, and unverified sizing arithmetic.
- Replaced it with strict checks for one row/date/ticker, all five flags, count parity, strict ATR<4%, identity-inclusive V4 pass, whole shares, risk/capital arithmetic, minimum constraint, alias parity, and zero-share skip.
- Added 12 regression cases; 12/12 passed. The empty log remains valid with zero observations.
- This improves prospective evidence integrity but the required forward sample remains at zero.

## Continuation audit — whole-day checkpoint logging semantics corrected
- The hardened validator initially prohibited multiple rows per date/ticker, conflicting with the preregistered 08:35/10:30/14:15 scanner reruns.
- Changed the unique key to date/time/ticker/scan type. Same-day repeats are accepted as observation_only, while promotion counting remains deduplicated by date/ticker.
- Added invariance checks for daily score, ATR, components, identity, and pass state across non-error checkpoints, plus an at-most-one paper_trade action rule.
- Forward-log validator suite is now 15/15 passing; zero prospective observations remain.

## Continuation audit — ET/CT checkpoint ambiguity removed
- The forward CSV used only signal_time_et while the operating runbook scheduled checkpoints in CT, creating a one-hour logging-error risk.
- Added signal_time_ct and date-aware America/New_York-to-America/Chicago validation.
- Tomorrow's scheduled pairs are explicitly 09:35/11:30/15:15 ET and 08:35/10:30/14:15 CT.
- Added mismatch regression; forward-log validator suite is now 16/16 passing.

## Continuation audit — frozen sizing/log bounds enforced
- Forward validator previously documented but did not enforce the frozen 0.50% risk and 20% capital cap.
- Added account scope $100-$1,000, exact risk/cap checks, score 0-100, and positive entry/risk-per-share checks.
- Added five regressions; forward validator is now 21/21 passing. Prospective sample remains zero.

## Continuation audit — Ring validator timing and sizing gaps fixed
- The Ring validator allowed same-bar delivery even though V4.2 deliberately alerts one completed bar later.
- It also could not verify round-trip cost in risk/share, limiting share counts, frozen account controls, or whether a paper action had an observed spread.
- Expanded the Ring schema and validator: exact one-bar delay; spread/cost; $100-$1,000, 0.50%, 20%; risk/capital/final shares; zero-share skip.
- Regression suite expanded from 11 to 17 cases; 17/17 pass. Empty genuine Ring log remains valid at zero rows.
- Reconciled stale protocol language: 30 alerts may support a mechanics diagnostic, but promotion remains 100 forward-paper trades per arm plus all gates.

## Continuation audit — Ring timestamp semantics corrected
- The log field named qualifying_bar_close_ct was being used as the bar's start timestamp in the cutoff tests, creating a five-/fifteen-minute semantic ambiguity.
- Added separate qualifying_bar_start_ct and qualifying_bar_close_ct fields.
- Validator now requires the exact chart-length span and Ring at the close/next-bar boundary. Final valid 5m case is start 14:25, close/Ring 14:30 CT.
- Updated operator card and runbook: Ring is not five minutes after the close; it is at the close, five minutes after the 5m bar began (15 minutes for 15m).
- Ring validator suite is now 18/18 passing; genuine log remains empty.

## Continuation audit — exact earliest Ring times derived
- Because the alert window opens at 08:45 CT and Ring waits for that bar to close, the earliest possible Ring is 08:50 CT on 5m or 09:00 CT on 15m. Ding can occur from 08:45 CT.
- Final delivery remains 14:30 CT from a 14:25 5m or 14:15 15m qualifying bar.
- Added pre-window regression; Ring validator is now 19/19 passing.

## Continuation audit — intraday temporal static coverage expanded
- Static audit previously proved aggregation/RTH guards but not the Ring transition/dedupe architecture.
- Added checks for distinct Ding/Ring paths, [1]/[2] completed-bar transition, session reset/dedupe, and delivery not being blocked by the current cutoff bar.
- Eight-script static audit expanded from 44 to 54 checks; 54/54 pass.
- This supports the final 14:30 CT delivery design but does not replace a genuine timestamped Ring.

## Continuation audit — open-gate package reconciliation
- Consolidated all remaining requirements into one current prioritized gate document.
- P0 now explicitly covers restart persistence, one alert study, chart extended-hours proof, V4.2.1 render, repaired sizing parity, live spread parity, and a genuine Ring.
- P1 covers three fresh scanner checkpoints, prospective logging/universe archiving, and permanent-ID point-in-time OOS.
- P2 retains the 100-trade and statistical promotion gates. No requirement was reclassified as complete.

## Continuation audit — tomorrow checkpoint artifact added
- Added a prefilled three-row checkpoint CSV for 08:35/10:30/14:15 CT with matched ET clocks, V3/V4 runtimes/counts/symbols, load errors, quote settings, chart settings, and active-study fields.
- Template mode validates the schedule; strict --complete mode rejects placeholders, missing fields, non-yes setting proofs, and count/symbol mismatches.
- The blank template validates and strict mode correctly rejects it with 42 missing-proof errors. This prevents an incomplete sheet from being mistaken for evidence.

## Continuation audit — checkpoint strict-validator regression suite
- Added strict ordering: scheduled time <= V3 start/end <= V4 start/end.
- Added unique uppercase symbol lists, count/list parity, and V4-subset-of-fresh-V3 enforcement.
- Added seven regression cases covering valid completed log, timezone mismatch, count mismatch, source-subset failure, duplicate symbols, bad scan order, and missing settings proof; 7/7 pass.

## Continuation audit — legitimate zero-result checkpoints fixed
- Strict checkpoint mode mistakenly required nonempty V3/V4 symbol lists, which would reject a valid completed scan returning zero candidates.
- Changed strict semantics: counts are always required; symbol lists may be empty only when the corresponding count is zero, with count/list parity still enforced.
- Added valid-zero-result regression; checkpoint suite is now 8/8 passing.

## Continuation audit — one-command package verifier added
- Added a standard-library verifier for ZIP CRC, manifest coverage/hash/size, unmanifested entries, four bundled regression suites, and all static audit rows.
- On the built package it passed 90 payload hashes, forward 21/21, Ring 19/19, point-in-time 9/9, checkpoint 8/8, and static 54/54.

## Continuation audit — package stale-evidence scan
- Scanned the extracted current package for superseded thresholds, test counts, aggregation state, and installation claims.
- Found completion matrix still cited the old 11/11 Ring suite; corrected to 19/19 and upgraded integrity evidence to the one-command verifier.
- Other flagged references were intentionally historical evidence (old 4h observation, stale sizing defaults) or accurate current state (V4.2.1 not yet live-applied).

## Continuation audit — point-in-time market-data schema and validator
- Added permanent-ID EOD schema separating unadjusted OHLC/volume filters from indicator OHLC and retaining split factor, delisting return, source, and available date.
- Validator rejects duplicate security/date rows, future availability, invalid OHLC ranges, fractional volume, nonpositive split factors, and delisting returns below -100%.
- Market-data regression suite 7/7 passes; template validates. Actual point-in-time data remains missing.

## Continuation audit — point-in-time identity classification enforced
- Membership schema previously had permanent IDs but no instrument type, so ETF/ETN contamination could recur historically.
- Added point-in-time instrument_type and identity_eligible. Only COMMON_STOCK and ADR may be eligible; ETF/ETN/preferred/warrant/right/unit/debt/test/other are retained but excluded.
- Added valid excluded-ETF, falsely eligible ETF, and invalid-type tests. Universe validator is now 12/12 passing; actual dataset remains missing.

## Continuation audit — point-in-time membership/market join gate
- Added permanent-ID/date join validator requiring exactly one effective interval under member_from <= date < member_to.
- Rejects unknown IDs, pre-membership rows, exclusive-end rows, gaps, and multiple matches while retaining excluded products in the denominator.
- Join regression suite 5/5 passes; example templates join. Genuine point-in-time inputs remain missing.

## Continuation audit — historical optionability provenance added
- Point-in-time membership schema now requires optionability_status (YES/NO/PROXY/UNKNOWN) and source unless UNKNOWN.
- A disclosed PROXY may be retained for sensitivity analysis but cannot be labeled exact optionable-universe parity.
- Added proxy/source regressions; universe suite is now 14/14 passing and join suite remains 5/5. Data acquisition remains open.

## Continuation audit — current clean-install order added
- Added one authoritative V4.6 install sequence separating canonical V3, supported split-stage daily workflow, experimental single-study chart setup, repaired sizing, and live spread quote.
- Explicitly prohibits whole-universe combined V4, duplicate alert studies, interpreting blank spread as zero, and claiming V4.2.1 installed before live proof.
- Lists every restart, settings, scan, spread, sizing, and genuine-Ring validation gate.

## Continuation audit — spread-to-cost floor enforced
- Fixed $0.06 cost can understate execution cost when observed spread alone exceeds it.
- Added visible COST/SH label to sizing study and operating rule to set cost/share at least as high as observed spread plus expected slippage before paper sizing.
- Ring validator now rejects cost below observed spread; suite is 20/20 passing.
- Static audit added visible-cost invariant and is 55/55 passing. Revised sizing study still needs live compile.

## Continuation audit — small-account cost sensitivity
- Reclassified fixed-$0.06 share counts as upper-bound affordability, not executable candidates.
- Recomputed the nine-name cohort at $0.06/$0.10/$0.25/$0.50 cost per share for $100/$250/$500/$1,000 accounts.
- $100 remained zero at every cost. Higher costs reduced some $500/$1,000 share counts and eliminated ZBH at $0.50 for $1,000; no profitability inference is made.

## Continuation audit — candidate forward log made after-cost consistent
- Added observed bid/ask spread and round-trip cost/share to the prospective candidate log rather than leaving execution cost implicit.
- Validator now requires entry, stop, spread, slippage, and round-trip cost for actionable rows; it rejects cost below spread plus slippage.
- Position risk/share must equal next-open entry minus planned stop plus round-trip cost, preventing share sizing from silently excluding execution cost.
- Added regressions for an understated cost floor and risk/share that omits cost. Forward-log suite passes 23/23; the genuine prospective log remains empty (0 rows).

## Continuation audit — alert timing semantics corrected and sourced
- Confirmed from Schwab documentation that `Alert.BAR` means no more than once per bar; it does not mean “at bar close.”
- The V4.2 completed-bar property comes from `qualified[1]`, which becomes the completed prior bar when the next bar begins.
- Reworded timing guidance from guaranteed delivery to eligibility for evaluation at the next-bar boundary, with platform/data latency explicitly unresolved.
- Added an official-source audit covering Eastern-time inputs, earliest 5m/15m boundaries, strict cutoff behavior, and the evidence a genuine Ring still must capture.

## Continuation audit — intraday replay aligned to live first-confirmation state
- Found that the 60-day V4.2 replay counted every false-to-true transition even though the live script defaults to only the first confirmation per symbol/session.
- Added session deduplication so replay observations match the live first-confirmation-only state rule.
- Corrected V4.2 result: 22 first-session alerts across 15 dates, 40.91% wins, mean after-cost close return -0.345%; date-cluster 95% interval approximately -1.077% to +0.340%.
- The interval includes zero and the universe is today's selected nine symbols, so this remains mechanics evidence—not a demonstrated edge.

## Continuation audit — no-flow MFI false-positive candidate repaired
- Found that all active/frozen V4 MFI formulas return 100 whenever negative flow is zero, including the degenerate case where positive flow is also zero.
- Added V4.2.2 as a new experimental chart-study candidate: both sums zero returns neutral 50; genuine positive-only flow still returns 100.
- Did not overwrite frozen daily V4 or claim V4.2.2 live. It requires a fresh compile/render test and versioned forward observations.
- Nine-script scoped static audit now passes 66/66 checks; static checks do not replace thinkorswim compilation.

## Continuation audit — daily no-flow repair versioned as V4.7
- Added separate V4.7 experimental daily quote and split-stage scan; frozen V4 files remain unchanged.
- Normalized parity comparison proves only the version header and no-flow MFI branch differ from the respective V4 source files.
- Both repaired scripts return MFI 50 when positive and negative flow are zero and retain all completed-session offsets and thresholds.
- Forward rows must use `scan_type = V4.7`; V4 and V4.7 observations may not be silently pooled. Eleven-script static audit passes 78/78, while live compilation remains open.

## Continuation audit — actionable sizing made fail-closed on actual entry
- Found the prior sizing aid used prior close + 0.4 ATR as a hypothetical entry even for an intraday Ring; capital sizing could therefore use a stale price.
- Added V4.1 manual-entry sizing. Default entry is zero and forces zero shares until the actual intended/fill price is entered.
- It displays entry, ATR stop, risk/share, and cost/share and retains prior-completed-DAY ATR, 0.50% risk, 20% cap, whole shares, and $100–$1,000 bounds.
- Five arithmetic edge cases plus script invariants pass; twelve-script static audit passes 87/87. Live compile and 5m/15m/DAY parity remain open.

## Continuation audit — observed spread made a mandatory sizing input
- Found that a user-entered aggregate cost could still understate the observed spread despite the operating note.
- Changed the not-yet-live manual-entry study to require observed dollar spread/share; zero/blank-equivalent spread now forces zero shares.
- Cost/share is derived as spread + expected round-trip slippage + fees, matching the forward-log validator's cost floor.
- Added a missing-spread regression. Six sizing cases and 88/88 static checks pass; live compile remains open.

## Continuation audit — Ring log stopped assuming zero notification latency
- Found a contradiction: operating guidance acknowledged platform/data latency, but the Ring validator rejected any alert timestamp later than the bar-close boundary.
- Added mandatory script version and alert-latency seconds. Receipt must not precede the qualifying close, but factual delayed delivery is retained rather than rewritten or discarded.
- Added valid delayed-delivery, latency mismatch, negative latency, and unknown-version cases. Ring suite passes 24/24; genuine latency remains unobserved because the prospective log is empty.

## Continuation audit — Ring execution-cost schema aligned with sizing
- Found Ring rows could prove cost exceeded spread while omitting expected slippage and fees, contrary to the repaired sizing model and candidate forward log.
- Added explicit expected-slippage/share and fees/share fields; both must be nonnegative.
- Round-trip cost must cover spread + slippage + fees. Added understated-total-cost and negative-component regressions; Ring suite passes 27/27.

## Continuation audit — historical small-account implementability quantified
- Repriced 48 V3 and 33 V4 selected-universe OOS trades at $0.06/$0.10/$0.25/$0.50 total cost/share and reconstructed whole-share sizing under 0.50% risk and 20% cap.
- A $100 account afforded zero observations in both arms at every cost. Under frozen rules there is no evidenced $100 trade; rounding up would violate risk controls.
- At $0.06 cost, V4 affordability was 4/33 for $250, 11/33 for $500, and 28/33 for $1,000; most actionable cases sized to one share.
- Every symbol-cluster return interval still included zero. Current-watchlist selection bias and missing point-in-time data remain unresolved.

## Continuation audit — account-specific affordability added as a third scan stage
- Added a lightweight DAY filter that rejects candidates unable to support even one estimated whole share under the selected account, 0.50% risk, 20% cap, prior-day ATR, and minimum cost.
- It runs only after fresh V4/V4.7 results, avoiding the failed whole-universe combined architecture.
- The filter is an impossibility screen, not an entry or edge claim; actual Ring price/spread must still pass fail-closed manual sizing.
- Five arithmetic cases pass. Thirteen-script static audit passes 94/94; live compile and scanner runtime remain open.

## Continuation audit — affordability estimate exposed as a watchlist column
- Added a DAY custom quote matching the affordability scan inputs and core formulas, so impossible zero-share names are visible without opening every chart.
- Green/one-or-more remains an upper-bound estimate; only actual Ring entry/spread sizing can authorize a paper observation.
- Scan/quote formula invariants and five arithmetic cases pass. Fourteen-script static audit passes 100/100; live quote compile/parity remains open.

## Continuation audit — live UI access attempted, no state inferred
- Computer Use detected thinkorswim build 1992 running with five windows, including the Watchlist and SAN flexible-grid windows.
- The Watchlist accessibility root reported disabled. Activation failed with `GetCursorPos ... Access is denied (0x80070005)`; the permitted retry captured desktop wallpaper rather than app content.
- Per recovery rules, no further UI input was attempted and no formula, value, aggregation, or session-setting claim was made from these captures.
- The failure is recorded in `LIVE_UI_ACCESS_ATTEMPT_2026-08-06.csv`; live compile/settings gates remain open.

## Continuation audit — current-state matrix and README made verifier-enforced
+- Found the current completion matrix still referenced the superseded sizing study, 55-check evidence, and an ambiguous "latest V4.2" compile claim.
+- Replaced those rows with the manual-entry/spread sizing candidate, V4.2 fallback wording, current 100-check evidence, and explicit V4.2.2/V4.7/affordability/UI gates.
+- Added a generic current matrix and verifier checks tying 14 packaged thinkScripts to 14 statically scoped scripts, current README tokens, experimental compile status, and `not_demonstrated` profitability status.

## Continuation audit — text-encoding integrity added to package verification
- Found damaged question-mark punctuation in continuation headers and the oscillator edge-case README after prior encoding conversions.
- Repaired the current source files and added verifier checks that reject recurrence in the packaged live audit and historical README.

## Continuation audit — prospective affordability and fee provenance enforced
- Added explicit affordability-stage-used, estimated-share, and pass fields to the candidate forward log so the new prefilter's false positives and zero-share outcomes can be measured.
- When the stage is used, estimated shares must be a nonnegative integer, pass must equal estimate >= 1, and a paper action cannot bypass failure.
- Added fees/share to align candidate logging with Ring logging and manual sizing; total cost must cover spread + slippage + fees.
- Forward-log validator now passes 27/27 cases; the genuine log remains empty.

## Continuation audit — next-session runbook reconciled to current system
- Found the older tomorrow runbook confused the 0—100 Score with 0—5 confirmation count, described the superseded hypothetical-entry sizing workflow, assumed zero alert latency, and implied a same-day outcome convention.
- Added a canonical next-session runbook covering V4.2 fallback versus uncompiled V4.2.2, separate V4.7, affordability stage, manual entry/spread sizing, cost components, actual alert latency, and frozen multi-session exits.
- Package verification now requires these current operating controls.

## Continuation audit — clean install separated from full script archive
- Found the package's single scripts folder mixed current, fallback, combined-timeout, and superseded alert/sizing revisions, creating a paste-all duplicate-alert risk.
- Added `install_current/frozen_core` with five canonical V3 files plus supported V4 daily split-stage and V4.2 fallback, and `install_current/candidates_not_live_verified` with seven separately named candidates.
- Kept the 14-script folder as an audit archive only. The verifier enforces exact set sizes, one alert study per set, exclusion of superseded/combined scripts, and byte parity with archived V4 sources.

## Continuation audit — clean install editor-role map added
- Added an install-folder README mapping every frozen and candidate script to the correct thinkorswim editor, aggregation/session setting, and adoption rule.
- It explicitly distinguishes Score 0—100 from confirmation count 0—5, prohibits duplicate V4.2/V4.2.2 alert studies, treats blank spread as unknown, and keeps V4.7 separate.
- Package verification now enforces those safety instructions.

## Continuation audit — chart-close V3 sizing removed from installable core
- Re-inspected frozen `V3_RiskShares_ChartStudy_v2.ts` and confirmed capital shares depend on chart `close` while risk uses modeled ATR/buffer cost, so it is not safe as the current post-Ring sizing control.
- Moved it from installable frozen core to `reference_only_do_not_install`; it remains only for historical reproducibility.
- Frozen install core now contains seven scanner/quote/alert files. No paper action is allowed until the manual-entry/spread sizing candidate receives live compile and timeframe-parity proof.

## Continuation audit — V3 threshold-default drift removed from clean install
- Found canonical `V3_EntryConfirmed_Daily_Scan.ts` defaults to score 60 even though the registered/current workflow uses 65; a fresh paste could silently widen the universe.
- Added an install-safe, separately named copy with default 65 and retained the byte-canonical default-60 source under reference-only.
- The verifier proves the install copy differs only by one version header and the 60—65 default change, and prohibits the default-60 source from installable folders.

## Continuation audit — threshold-65 source-arm operation made explicit
- Updated the current runbook to use the separately named threshold-65 V3 source query for V4, while preserving any threshold-60 diagnostic as a separately named/logged arm.
- Added a configuration-risk report: an older biased diagnostic had 93 observations at 60 versus 59 at 65, showing the default can materially widen membership even though yesterday's 13-name cohort did not discriminate.
- The historical count difference is workload evidence only, not profitability evidence.

## Continuation audit — fallback no-flow MFI made non-actionable
- Ring logging previously recorded only the displayed MFI value, so fallback V4.2's zero/zero-flow false 100 could not be distinguished from genuine positive-only flow.
- Added positive and negative MFI flow sums and version-aware arithmetic. V4.2.2 expects neutral 50 at zero/zero; older fallback expects its coded 100 but may only be logged as `skip`, never `paper`.
- Added five regressions for arithmetic mismatch, negative flows, V4.2.2 no-flow rejection, fallback paper rejection, and fallback skip retention. Ring suite passes 32/32.

## Continuation audit — MFI flow logging made operable in the chart candidate
- The Ring schema required positive/negative MFI sums, but V4.2.2 did not display them, making manual forward logging impractical.
- Added optional-on-by-default `MF+`/`MF-` and flow-present/none labels to V4.2.2. Fallback V4.2 lacks these diagnostics and is observation-only unless sums are independently captured.
- Static audit now passes 101/101; V4.2.2 still requires live compilation and label readability proof.

## Continuation audit — Ring MFI diagnostics aligned to the qualifying bar
- Found the new MF+/MF- labels displayed the current forming delivery bar, while Ring validation belongs to the prior completed qualifying bar.
- V4.2.2 now captures `pMF[1]`/`nMF[1]` when `alertConfirmation` occurs and holds them as `LAST RING MF+ / MF-` for the session.
- Current-bar flow is explicitly labeled current and cannot be mistaken for Ring evidence. Static audit passes 102/102; live compile/readability remains open.
