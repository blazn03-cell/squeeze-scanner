# V4.6 tomorrow live runbook — America/Chicago

**Paper testing only. Historical confidence intervals include zero.** The purpose is reliability and evidence collection, not a promise of profit.

## Before 08:30 CT

1. Reopen thinkorswim and verify the Score column still shows 0–5 values.
2. Open its formula editor and capture proof of `D` aggregation. Extended-hours must be off where the editor exposes that control.
3. Confirm the SAN test pane is 5 minutes, chart extended-hours display is **off**, and only the selected experimental V4.2.x study is enabled. Keep V4.1 and superseded experimental revisions disabled on this pane to prevent duplicate sounds. Capture chart aggregation and extended-hours settings together; clock gating alone does not stop overnight bars from changing indicator lookbacks.
4. Confirm V4.2 defaults: start 0945 ET, end 1530 ET, max VWAP distance 1.0 ATR, box required, first confirmation only.
5. Recompile the revised sizing study and verify its visible `CONFIG` label says `0.5% RISK | 20% CAP`. Check $100, $250, $500, and $1,000 inputs; retain zero-share outcomes. For one symbol and identical inputs, compare the labels on a 5m chart and a DAY chart: shares, risk budget, risk used, position value, and capital cap must match exactly because the study now uses explicit DAY secondary aggregation.
6. During regular hours, compile `V4_LiveSpreadPct_CustomQuote_EXPERIMENTAL` in a copied layout. For at least five symbols, record platform bid, ask, calculated midpoint-spread percentage, and displayed column value. Require arithmetic agreement after rounding. Confirm an unavailable quote remains blank rather than appearing as zero.

## Candidate generation

At **08:35 CT**, load and explicitly press **Scan** on the frozen V3 saved query. Record start time, completion time, and count. Then run the lightweight `V4_ConfirmATR_Daily_Scan` with:

- Scan in: freshly rerun V3 saved query
- DAY aggregation; extended hours off
- maximum model ATR: 4%
- minimum confirmation count: 4/5

Do not use the combined whole-universe V4 query; it previously timed out. Saved rows are not fresh until the Scan button is pressed.

Repeat the same explicit V3→V4 sequence at **10:30 CT** and **14:15 CT**. Compare counts and symbols. Do not call a count change instability unless both source scans have fresh timestamps.

In the forward CSV, record both clocks. These scheduled checkpoints are **09:35/11:30/15:15 ET** and **08:35/10:30/14:15 CT**; the validator rejects inconsistent ET/CT pairs.

## Alert observation window

- V4.2 listens from **08:45–14:30 CT** (09:45–15:30 ET).
- `Ding` is only a VWAP-reclaim warning.
- `Ring` is the completed-bar confirmation: it fires on the first tick of the next bar, at the same clock boundary when the qualifying bar closes.
- Earliest possible Ring is 08:50 CT on 5m or 09:00 CT on 15m; the final permitted delivery boundary is 14:30 CT.
- On 5 minutes, log qualifying-bar start, its close five minutes later, and the Ring at that close/next-bar boundary. Use a fifteen-minute span on 15m.
- Record the first Ring only for each symbol/session. Do not infer a missed alert merely from a historical arrow.

For each Ring, record: symbol, qualifying-bar start and close, alert time, dashboard states, VWAP distance in ATR, bid/ask spread, proposed entry, stop, cost, both limiting share counts, final shares, and whether the output was zero shares.

## Small-account hard gates

- Test account: $250 default; risk 0.5% ($1.25); position cap 20% ($50).
- Whole shares only; never round zero to one.
- Skip if spread materially consumes the stop distance, the chart says `TOO EXTENDED`, the alert is outside the window, or sizing returns zero.
- No live order is authorized by this protocol.

## End-of-day checks

At **14:35 CT**, verify the dashboard says `TIME WAIT`; no later Ring should be treated as valid. At **15:05 CT**, log outcomes using the preregistered exit convention without changing thresholds after seeing results.

## Evidence required before promotion

1. Restart-persistent DAY quote proof.
2. One genuine in-window Ring with bar/alert timestamps.
3. Prospective paper log large enough for the existing promotion gates.
4. Point-in-time universe data including delisted securities.
5. Confidence interval excluding zero after costs and concentration checks.

Until all five are satisfied, V4.2 remains experimental and no profitable edge is established.

The existing forward promotion gate requires **at least 100 forward-paper trades per arm**, a bootstrap 95% confidence interval for mean R excluding zero, no symbol contributing over 20% of positive R, acceptable realized slippage, acceptable normal/high-volatility regime results, and scanner error rate below 1%. A Ring is not known to be a profitable signal before these gates pass.
