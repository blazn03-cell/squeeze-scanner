﻿# 60-day intraday alert-mechanics replay

This diagnostic replays the next-bar alert transition (`qualified[1] and !qualified[2]`) on Yahoo 5-minute bars for today's nine candidates. V4.2 retains only the first transition per symbol/session, matching `firstConfirmationOnlyPerSession = yes`. The replay is heavily selection-biased and exits every alert at the same-day close; it is not the daily strategy backtest and does not establish expected profit.

## Results after 10 bps per side
- V4.1: 751 alert transitions across 55 dates; 37.95% close-exit wins; mean -0.190%.
- V4.2: 22 first-session alerts across 15 dates; 40.91% wins; mean -0.345%.
- 13.45% of V4.1 transitions occurred before 09:45 ET. V4.2 correctly produced none before its configured window.

## Interpretation
V4.2 dramatically reduced alert frequency but did not improve the arbitrary alert-to-close return in this selected sample. A date-cluster bootstrap 95% interval for V4.2 was approximately -1.077% to +0.340%, including zero. The time/anti-chase gate remains a risk-control hypothesis, not a demonstrated profitability improvement. The high V4.1 count shows that conditions can cycle false/true repeatedly; alerts must be deduplicated to one observation per ticker/session.

## Required improvement
For prospective logging, retain only the first closed-bar confirmation per ticker/session. Record later transitions as diagnostics, not independent trades. Do not infer an entry from every sound alert. The 22-row result supersedes the earlier 25-transition replay, which had not applied the live study's first-confirmation-only state rule.
