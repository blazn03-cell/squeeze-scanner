# V4.2.1 clarity-only change

The V4.2 dashboard displayed `TOO EXTENDED` whenever VWAP distance was negative. Below-VWAP bars are disqualified, but they are not literally extended above VWAP, so the label could mislead the operator.

V4.2.1 changes only that label:

- distance below zero: `BELOW VWAP`
- distance from zero through 1.0 ATR: `EXTENSION OK`
- distance above 1.0 ATR: `TOO EXTENDED`

Signal equations, thresholds, alerts, plots, and first-confirmation behavior are unchanged. A unified-diff verifier found only the version comment and this label line changed (plus terminal whitespace).

V4.2.1 is **not yet installed or live-compiled**. Keep the live-tested V4.2 active until V4.2.1 compiles tomorrow; then replace it rather than running both simultaneously.
