"""Arithmetic and script-invariant tests for the affordability prefilter."""
import math
from pathlib import Path
HERE=Path(__file__).resolve().parent
SCRIPTS=HERE.parent/"scripts" if (HERE.parent/"scripts").exists() else HERE
text=(SCRIPTS/"V4_SmallAccountAffordability_Daily_Scan_EXPERIMENTAL.ts").read_text(encoding="utf-8-sig")
quote=(SCRIPTS/"V4_EstimatedAffordableShares_CustomQuote_EXPERIMENTAL.ts").read_text(encoding="utf-8-sig")
for token in ["close[1]", "def atr = atrSeries[1];", "Floor(riskBudget / riskPerShare)", "Floor(capitalBudget / plannedEntry)", "estimatedShares >= 1"]:
    assert token in text, token
assert text.count("plot scan") == 1 and "AddOrder" not in text and "Alert(" not in text
assert quote.count("plot Shares") == 1 and "AddOrder" not in quote and "VWAP" not in quote
for formula in [
    "def c = close[1];", "def atr = atrSeries[1];",
    "def plannedEntry = c + plannedEntryATRBuffer * atr;",
    "def riskPerShare = stopATR * atr + minimumRoundTripCostPerShare;",
    "Floor(riskBudget / riskPerShare)", "Floor(capitalBudget / plannedEntry)",
]:
    assert formula in text and formula in quote, formula

def shares(account, close, atr, cost=.06, risk_pct=.5, cap_pct=20, stop_atr=1.5, buffer=.4):
    if not 100 <= account <= 1000 or min(close,atr,cost) <= 0: return 0
    planned=close+buffer*atr
    return min(math.floor(account*risk_pct/100/(stop_atr*atr+cost)), math.floor(account*cap_pct/100/planned))

cases=[
 ("100_feasible_one_share",(100,10,.20),1),
 ("100_price_cap_reject",(100,21,.20),0),
 ("100_risk_reject",(100,10,.30),0),
 ("below_scope_reject",(99,10,.20),0),
 ("250_three_shares",(250,10,.20),3),
]
for name,args,want in cases:
    got=shares(*args); assert got==want,(name,got,want); print("PASS",name,got)
print(f"PASS: {len(cases)} affordability cases + scan/quote parity invariants")
