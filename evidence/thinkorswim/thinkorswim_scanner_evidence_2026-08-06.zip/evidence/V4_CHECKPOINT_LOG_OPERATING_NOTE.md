# V4 checkpoint log operating note

Use `V4_TOMORROW_CHECKPOINT_LOG_2026-08-07.csv` for the three fresh split-stage scanner runs.

1. Before collection, template validation:
   `python validate_v4_checkpoint_log.py V4_TOMORROW_CHECKPOINT_LOG_2026-08-07.csv`
2. Replace every placeholder and fill scan start/end, counts, pipe-separated symbols, error count, settings proofs, chart minutes, and the sole active alert study.
3. After collection, strict validation:
   `python validate_v4_checkpoint_log.py V4_TOMORROW_CHECKPOINT_LOG_2026-08-07.csv --complete`

Strict mode requires all three configuration flags to be `yes` and every operational field populated. It also requires scheduled→V3→V4 timestamp order, unique uppercase symbols, count/list parity, and the V4 result to be a subset of the fresh V3 source. A completed zero-result scan is valid with count `0` and an empty symbol list. Regression suite: 8/8 passed. This log measures scanner reliability; candidate-level and Ring observations still belong in their separate validated CSVs.
