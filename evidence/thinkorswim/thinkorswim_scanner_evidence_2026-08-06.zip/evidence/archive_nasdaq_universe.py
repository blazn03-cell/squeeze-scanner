"""Archive official Nasdaq Trader symbol directories without overwriting history."""
from __future__ import annotations
import csv, datetime as dt, hashlib, json, urllib.request
from pathlib import Path

BASE = "https://www.nasdaqtrader.com/dynamic/SymDir/"
FILES = ("nasdaqlisted.txt", "otherlisted.txt")
ROOT = Path(__file__).with_name("prospective_universe_snapshots")

def sha256(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest().upper()

def parse(data: bytes) -> tuple[int, str, int, int]:
    text = data.decode("utf-8-sig").replace("\r\n", "\n")
    lines = [line for line in text.splitlines() if line]
    if len(lines) < 3 or not lines[-1].startswith("File Creation Time:"):
        raise ValueError("missing Nasdaq file-creation footer")
    rows = list(csv.DictReader(lines[:-1], delimiter="|"))
    if not rows or "Test Issue" not in rows[0]: raise ValueError("unexpected directory schema")
    live = sum(row.get("Test Issue") == "N" for row in rows)
    etfs = sum(row.get("ETF") == "Y" for row in rows)
    return len(rows), lines[-1].split(":", 1)[1].strip("|"), live, etfs

def main() -> None:
    day = dt.date.today().isoformat()
    folder = ROOT / day
    folder.mkdir(parents=True, exist_ok=True)
    manifest = {"archive_date_local": day, "source": BASE, "files": []}
    for name in FILES:
        request = urllib.request.Request(BASE + name, headers={"User-Agent": "scanner-audit/1.0"})
        with urllib.request.urlopen(request, timeout=30) as response:
            data = response.read()
        count, created, non_test, etfs = parse(data)
        target = folder / name
        if target.exists() and target.read_bytes() != data:
            raise RuntimeError(f"refusing to overwrite changed same-day snapshot: {target}")
        target.write_bytes(data)
        manifest["files"].append({"name": name, "sha256": sha256(data),
                                  "file_creation_time": created, "rows": count,
                                  "non_test_rows": non_test, "etf_rows": etfs})
    manifest_path = folder / "manifest.json"
    encoded = json.dumps(manifest, indent=2, sort_keys=True) + "\n"
    if manifest_path.exists() and manifest_path.read_text(encoding="utf-8") != encoded:
        raise RuntimeError(f"refusing to overwrite changed manifest: {manifest_path}")
    manifest_path.write_text(encoded, encoding="utf-8")
    print(json.dumps(manifest, indent=2))

if __name__ == "__main__": main()
