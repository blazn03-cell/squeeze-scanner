"""Build a transparent identity-only equity prefilter from archived Nasdaq directories."""
from __future__ import annotations
import csv, re, sys
from collections import Counter
from pathlib import Path

EXCLUDED_NAME = re.compile(
    # Depositary shares/ADRs are intentionally retained: SAN is one of the live
    # candidates, so excluding that identity class would contradict the tested
    # universe. Preferred depositary issues are still caught when named preferred.
    r"\b(ETF|ETN|WARRANTS?|RIGHTS?|UNITS?|PREFERRED|PREFERENCE|"
    r"SENIOR NOTES?|SUBORDINATED NOTES?|DEBENTURES?|BONDS?|TRUST CERTIFICATES?)\b", re.I)

def load(path: Path, source: str):
    lines = path.read_text(encoding="utf-8-sig").splitlines()
    for row in csv.DictReader(lines[:-1], delimiter="|"):
        symbol = (row.get("Symbol") or row.get("ACT Symbol") or "").strip()
        name = row.get("Security Name", "").strip()
        reasons = []
        if row.get("Test Issue") != "N": reasons.append("test_issue")
        if row.get("ETF") == "Y": reasons.append("etf")
        if not symbol or not re.fullmatch(r"[A-Z][A-Z0-9.\-]{0,9}", symbol): reasons.append("symbol_format")
        match = EXCLUDED_NAME.search(name)
        if match: reasons.append("name_" + match.group(1).lower().replace(" ", "_"))
        yield {"symbol": symbol, "security_name": name, "source": source,
               "exchange_or_market": row.get("Exchange") or row.get("Market Category", ""),
               "identity_eligible": "yes" if not reasons else "no",
               "exclusion_reasons": ";".join(dict.fromkeys(reasons))}

def main(folder: Path):
    rows = list(load(folder / "nasdaqlisted.txt", "nasdaq"))
    rows += list(load(folder / "otherlisted.txt", "other"))
    out = folder / "identity_prefilter.csv"
    with out.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=rows[0].keys()); writer.writeheader(); writer.writerows(rows)
    counts = Counter(row["identity_eligible"] for row in rows)
    reasons = Counter(reason for row in rows for reason in row["exclusion_reasons"].split(";") if reason)
    summary = folder / "identity_prefilter_summary.csv"
    with summary.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.writer(handle); writer.writerow(["metric", "value"])
        writer.writerow(["total_rows", len(rows)]); writer.writerow(["eligible_rows", counts["yes"]])
        writer.writerow(["excluded_rows", counts["no"]])
        for reason, count in reasons.most_common(): writer.writerow([f"reason_{reason}", count])
    print(f"rows={len(rows)} eligible={counts['yes']} excluded={counts['no']}")

if __name__ == "__main__":
    folder = Path(sys.argv[1]) if len(sys.argv) > 1 else Path(__file__).with_name("prospective_universe_snapshots") / "2026-08-06"
    main(folder)
