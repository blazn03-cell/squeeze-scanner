# V4 MFI no-flow reliability audit — 2026-08-06

## Defect

The frozen daily confirmation quote, split-stage scan, and V4.2/V4.2.1 intraday studies use `if negativeFlow == 0 then 100`. When both positive and negative money flow are zero—possible with missing/zero-volume bars or unchanged typical price—this reports MFI 100 even though there is no positive-flow evidence.

This is a reliability false positive. Stable-universe liquidity reduces its frequency but does not make the formula logically correct, especially when chart session settings or sparse bars differ.

## Candidate repair

`V4_2_2_IntradayConfirm_ChartStudy_EXPERIMENTAL.ts` changes only the degenerate branch:

```thinkscript
def mfi = if nMF == 0 and pMF == 0 then 50
    else if nMF == 0 then 100
    else 100 - 100 / (1 + pMF / nMF);
```

Neutral 50 does not pass the strict `mfi > 50` gate. Genuine all-positive flow still returns 100.

## Version-control rule

Do not silently overwrite the frozen daily V4 arm or the currently observed V4.2 chart study. V4.2.2 is a new experimental reliability candidate and requires a fresh thinkorswim compile/render check before use. If adopted, record the version in every Ring row; results from different versions must not be pooled without a version indicator.

This correction removes a logical false positive. It does not demonstrate profitability.
