# V4 live spread quote operating note

`V4_LiveSpreadPct_CustomQuote_EXPERIMENTAL.ts` is a candidate replacement for the blank `BidAskSpread%` column observed in the watchlist.

- It calculates `(ask - bid) / midpoint * 100` from the direct current `bid` and `ask` functions that Schwab documents for Custom Quotes.
- It is intended for regular market hours; historical, delayed, after-hours, or unsupported quote contexts may be blank.
- **Blank means unavailable, not zero.** A blank row must not pass a liquidity or execution-cost gate.
- Default colors mark up to 0.25% green, 0.25%-0.50% yellow, and above 0.50% red. These are operational caution bands, not historically proven profitability thresholds.
- For actual paper sizing, compare the dollar spread with the planned per-share stop distance. Percent-of-price alone is not sufficient.

The script has passed static checks but has not yet been compiled or observed live. Do not replace the existing column until it compiles during regular hours and is cross-checked against the platform's displayed bid and ask for at least five symbols, including one blank/unavailable case.

## Platform limitation behind the repair

Schwab documents ASK/BID price types through `close(priceType=...)` as restricted for non-Forex symbols to intraday intervals covering no more than 15 days. A DAY custom quote has a one-year calculation interval, so using that pattern can produce unsupported/blank values. The direct `bid` and `ask` functions are specifically documented as available in Custom Quotes and cannot be historically indexed. This makes them the more appropriate source for a current-spread column. The exact cause of the user's old blank column remains an inference until its formula and aggregation are reopened.
