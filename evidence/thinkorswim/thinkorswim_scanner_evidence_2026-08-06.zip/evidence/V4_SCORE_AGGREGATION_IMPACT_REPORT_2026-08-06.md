# Score aggregation impact — 2026-08-06

The repaired Score column completed loading for all 34 fresh V3 symbols after the close. Its DAY values were compared with the previously observed 4-hour values.

- 27/34 symbols changed confirmation count.
- The DAY count was higher for 26 symbols, unchanged for seven, and lower for one.
- The `>=4` gate passed 9/34 under the old 4-hour observation versus 25/34 under DAY.
- Eighteen symbols flipped sides of the `>=4` gate.

This is direct evidence that aggregation was not a cosmetic defect. A 4-hour custom quote measures a different bar structure and materially changes candidate classification. Historical and forward V4 evidence must use completed DAY sessions; old 4-hour Score values must not be mixed into the daily arm.

The DAY quote alone is not the final V4 scan: the split-stage scan also applies the fresh V3 source and model-ATR cap. Therefore 25 DAY quote passes do not imply 25 tradable V4 candidates.

One identity-gate failure (`NVDL`, an ETF) also had a DAY count of four. Instrument-type screening remains mandatory even when the technical confirmation gate passes.
