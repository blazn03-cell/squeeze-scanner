# V4 alert-semantics audit — 2026-08-06

## Finding

The V4.2/V4.2.1 Ring is a **completed-bar-derived alert**, but not because `Alert.BAR` means “wait for close.” Schwab documents `Alert.BAR` only as limiting an alert to once per bar. The one-bar delay is created by the script itself:

```thinkscript
def rawClosedBarConfirmation = qualified[1] and !qualified[2];
```

On the first tick of a new bar, `[1]` refers to the now-completed preceding bar. Consequently, the Ring can be evaluated at that new-bar boundary. Platform or data latency can make the audible notification arrive later; no exact wall-clock delivery guarantee is claimed.

The Ding is different: `reclaim` uses the current forming bar and is therefore an early warning only. It can disappear from the final historical bar state and must never be logged as a Ring or entry confirmation.

## Time-zone and boundary proof

Schwab documents `SecondsFromTime()` / `SecondsTillTime()` inputs in Eastern time. Script inputs 09:45–15:30 therefore correspond on the 2026-08-06 session to 08:45–14:30 America/Chicago.

- Earliest qualifying 5-minute bar starts 09:45 ET and completes at 09:50 ET; earliest Ring evaluation is 08:50 CT.
- Earliest qualifying 15-minute bar starts 09:45 ET and completes at 10:00 ET; earliest Ring evaluation is 09:00 CT.
- Because `SecondsTillTime(1530) > 0` is strict, a bar timestamped 15:30 ET cannot newly qualify.
- A 5-minute bar timestamped 15:25 ET may qualify and be evaluated at 15:30 ET. A 15-minute bar timestamped 15:15 ET may likewise be evaluated at 15:30 ET.

These conclusions require standard time-based 5-minute or 15-minute bars. They do not apply to tick/range charts, delayed feeds, replay anomalies, closed markets, or a chart with incorrect session settings.

## Official references

- Schwab thinkScript `Alert.BAR`: https://toslc.thinkorswim.com/center/reference/thinkScript/Constants/Alert/Alert-BAR
- Schwab thinkScript `Alert()`: https://toslc.thinkorswim.com/center/reference/thinkScript/Functions/Others/Alert.html
- Schwab thinkScript `SecondsFromTime()`: https://toslc.thinkorswim.com/center/reference/thinkScript/Functions/Date---Time/SecondsFromTime

## Remaining live proof

The code path and synthetic validator cases establish intended mechanics, not actual notification delivery. A genuine live Ring must still record the qualifying-bar timestamp, alert-arrival timestamp, aggregation, symbol, chart session setting, and screenshot. Until then, notification latency and restart/session-setting persistence remain unverified.
