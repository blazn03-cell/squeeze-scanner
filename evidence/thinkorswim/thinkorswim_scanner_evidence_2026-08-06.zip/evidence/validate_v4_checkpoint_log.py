"""Validate tomorrow's three scanner checkpoint rows. Reliability only."""
import csv, datetime as dt, sys
from pathlib import Path
from zoneinfo import ZoneInfo

path=Path(sys.argv[1] if len(sys.argv)>1 else Path(__file__).with_name("V4_TOMORROW_CHECKPOINT_LOG_2026-08-07.csv"))
complete="--complete" in sys.argv[2:]
required=["session_date","scheduled_time_ct","scheduled_time_et","v3_scan_start_ct","v3_scan_end_ct","v3_count","v4_scan_start_ct","v4_scan_end_ct","v4_count","v3_symbols_pipe","v4_symbols_pipe","load_error_count","score_day_verified","score_extended_hours_off","chart_minutes","chart_extended_hours_off","active_alert_study","notes"]
errors=[]
with path.open(newline="",encoding="utf-8-sig") as f:
 r=csv.DictReader(f); rows=list(r)
 if r.fieldnames!=required: errors.append("header mismatch")
if len(rows)!=3: errors.append("exactly three checkpoints required")
seen=set()
for n,row in enumerate(rows,2):
 try:
  day=dt.date.fromisoformat(row["session_date"]); ct=dt.time.fromisoformat(row["scheduled_time_ct"]); et=dt.time.fromisoformat(row["scheduled_time_et"])
  expected=dt.datetime.combine(day,ct,ZoneInfo("America/Chicago")).astimezone(ZoneInfo("America/New_York")).strftime("%H:%M")
  if et.strftime("%H:%M")!=expected: errors.append(f"line {n}: ET/CT mismatch; expected {expected}")
 except ValueError as e: errors.append(f"line {n}: invalid date/time ({e})")
 key=(row["session_date"],row["scheduled_time_ct"])
 if key in seen: errors.append(f"line {n}: duplicate checkpoint")
 seen.add(key)
 for flag in ["score_day_verified","score_extended_hours_off","chart_extended_hours_off"]:
  if row[flag] not in {"yes","no","yes_or_no"}: errors.append(f"line {n}: invalid {flag}")
  if complete and row[flag]!="yes": errors.append(f"line {n}: completed proof requires {flag}=yes")
 for field in ["v3_count","v4_count","load_error_count"]:
  if row[field]:
   try:
    x=int(row[field]); assert x>=0
   except (ValueError,AssertionError): errors.append(f"line {n}: {field} must be nonnegative integer")
 if row["chart_minutes"] and row["chart_minutes"] not in {"5","15"}: errors.append(f"line {n}: chart_minutes must be 5 or 15")
 if complete:
  for field in ["v3_scan_start_ct","v3_scan_end_ct","v3_count","v4_scan_start_ct","v4_scan_end_ct","v4_count","load_error_count","chart_minutes","active_alert_study"]:
   if not row[field].strip(): errors.append(f"line {n}: completed log requires {field}")
 if row["v3_count"]:
  v3_symbols=[x for x in row["v3_symbols_pipe"].split("|") if x]
  count=len(v3_symbols)
  if count!=int(row["v3_count"]): errors.append(f"line {n}: V3 count/symbol mismatch")
  if len(set(v3_symbols))!=len(v3_symbols) or any(x!=x.upper() for x in v3_symbols): errors.append(f"line {n}: V3 symbols must be unique uppercase")
 if row["v4_count"]:
  v4_symbols=[x for x in row["v4_symbols_pipe"].split("|") if x]
  count=len(v4_symbols)
  if count!=int(row["v4_count"]): errors.append(f"line {n}: V4 count/symbol mismatch")
  if len(set(v4_symbols))!=len(v4_symbols) or any(x!=x.upper() for x in v4_symbols): errors.append(f"line {n}: V4 symbols must be unique uppercase")
 if row["v3_count"] and row["v4_count"] and int(row["v4_count"])>int(row["v3_count"]): errors.append(f"line {n}: V4 count exceeds V3 source")
 if row["v3_count"] and row["v4_count"]:
  v3_set={x for x in row["v3_symbols_pipe"].split("|") if x};v4_set={x for x in row["v4_symbols_pipe"].split("|") if x}
  if not v4_set.issubset(v3_set): errors.append(f"line {n}: V4 symbols not subset of V3")
 if complete:
  try:
   scheduled=dt.datetime.combine(day,ct)
   v3s=dt.datetime.combine(day,dt.time.fromisoformat(row["v3_scan_start_ct"]));v3e=dt.datetime.combine(day,dt.time.fromisoformat(row["v3_scan_end_ct"]));v4s=dt.datetime.combine(day,dt.time.fromisoformat(row["v4_scan_start_ct"]));v4e=dt.datetime.combine(day,dt.time.fromisoformat(row["v4_scan_end_ct"]))
   if not scheduled<=v3s<=v3e<=v4s<=v4e: errors.append(f"line {n}: scan timestamps not scheduled V3 then V4 order")
  except ValueError as e: errors.append(f"line {n}: invalid scan timestamp ({e})")
if errors:
 print("INVALID",len(errors));print("\n".join(errors));raise SystemExit(1)
print(f"VALID TEMPLATE/LOG: {len(rows)} checkpoints")
