﻿"""Cost/affordability sensitivity for archived selected-universe OOS trades."""
import pandas as pd, numpy as np
from pathlib import Path
HERE=Path(__file__).resolve().parent
trades=(HERE/'v4_oos_parity_audit_2026-08-06/trades.csv')
if not trades.exists(): trades=HERE.parent/'historical/trades.csv'
d=pd.read_csv(trades)
d['model_stop_distance']=np.where(d.r_multiple.abs()>1e-12,(d['exit']-d['entry'])/d.r_multiple,np.nan)
rows=[]; rng=np.random.default_rng(20260806)
for cost in [.06,.10,.25,.50]:
 for arm,g0 in d.groupby('arm'):
  g=g0.copy(); g['entry_costed']=g.entry_raw+cost/2; g['exit_costed']=g.exit_raw-cost/2; g['ret']=100*(g.exit_costed/g.entry_costed-1)
  sc=g.groupby('ticker').ret.agg(['sum','count']).to_numpy(); idx=rng.integers(0,len(sc),(20000,len(sc))); z=sc[idx]; means=z[:,:,0].sum(1)/z[:,:,1].sum(1);lo,hi=np.quantile(means,[.025,.975])
  for acct in [100,250,500,1000]:
   risk=np.floor((acct*.005)/(g.model_stop_distance+cost)).clip(lower=0); cap=np.floor((acct*.20)/g.entry_costed).clip(lower=0); shares=np.minimum(risk,cap); ok=shares>=1
   rows.append(dict(arm=arm,cost_per_share=cost,account=acct,trades=len(g),symbols=g.ticker.nunique(),all_trade_win_rate_pct=(g.ret>0).mean()*100,all_trade_mean_return_pct=g.ret.mean(),symbol_cluster_ci_low_pct=lo,symbol_cluster_ci_high_pct=hi,affordable_observations=int(ok.sum()),affordable_pct=ok.mean()*100,affordable_win_rate_pct=(g.loc[ok,'ret']>0).mean()*100 if ok.any() else np.nan,affordable_mean_return_pct=g.loc[ok,'ret'].mean() if ok.any() else np.nan,median_shares_if_affordable=float(np.median(shares[ok])) if ok.any() else 0,max_shares=int(shares.max())))
out=pd.DataFrame(rows); target=HERE/'V4_HISTORICAL_COST_AND_AFFORDABILITY_SENSITIVITY_2026-08-06.csv';out.to_csv(target,index=False);print(out.to_string(index=False))
