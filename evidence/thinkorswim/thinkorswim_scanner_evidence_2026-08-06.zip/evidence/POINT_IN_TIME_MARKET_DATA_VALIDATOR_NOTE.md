# Point-in-time market-data validator note

The historical gate now has a separate permanent-ID EOD schema for raw filter data and indicator data. It rejects duplicate security/date rows, future availability dates, inconsistent/negative OHLC, fractional or negative volume, nonpositive split factors, and delisting returns below -100%.

**Regression result: 7/7 passed.** The included example row validates. This is infrastructure only: no genuine point-in-time market dataset has been acquired, and no unbiased OOS edge is demonstrated.
