"""Validate point-in-time universe intervals before any promotion backtest.

Usage: python validate_point_in_time_universe.py membership_intervals.csv
Required columns: security_id, ticker, instrument_type, identity_eligible, optionability_status, optionability_source,
member_from, member_to, source, source_asof
Dates are ISO YYYY-MM-DD. member_to is exclusive and may be blank for active.
"""
import csv, datetime as dt, sys
from collections import defaultdict
from pathlib import Path

p = Path(sys.argv[1] if len(sys.argv) > 1 else "membership_intervals.csv")
required = {"security_id", "ticker", "instrument_type", "identity_eligible", "optionability_status", "optionability_source", "member_from", "member_to", "source", "source_asof"}
instrument_types = {"COMMON_STOCK", "ADR", "ETF", "ETN", "PREFERRED", "WARRANT", "RIGHT", "UNIT", "DEBT", "TEST_ISSUE", "OTHER"}
errors, intervals, ticker_intervals = [], defaultdict(list), defaultdict(list)

def date(s, line, field, allow_blank=False):
    if allow_blank and not s:
        return dt.date.max
    try:
        return dt.date.fromisoformat(s)
    except ValueError:
        errors.append(f"line {line}: invalid {field} {s!r}")
        return None

with p.open(newline="", encoding="utf-8-sig") as f:
    r = csv.DictReader(f)
    missing = required - set(r.fieldnames or [])
    if missing:
        errors.append("missing columns: " + ", ".join(sorted(missing)))
    for line, row in enumerate(r, 2):
        sid = row.get("security_id", "").strip().upper()
        t = row.get("ticker", "").strip().upper()
        instrument = row.get("instrument_type", "").strip().upper()
        eligible = row.get("identity_eligible", "").strip()
        optionability = row.get("optionability_status", "").strip().upper()
        start = date(row.get("member_from", ""), line, "member_from")
        end = date(row.get("member_to", ""), line, "member_to", True)
        asof = date(row.get("source_asof", ""), line, "source_asof")
        if not sid: errors.append(f"line {line}: blank security_id")
        if not t: errors.append(f"line {line}: blank ticker")
        if instrument not in instrument_types: errors.append(f"line {line}: invalid instrument_type {instrument!r}")
        if eligible not in {"0", "1"}: errors.append(f"line {line}: identity_eligible must be 0/1")
        expected_eligible = instrument in {"COMMON_STOCK", "ADR"}
        if eligible in {"0", "1"} and (eligible == "1") != expected_eligible:
            errors.append(f"line {line}: identity_eligible inconsistent with instrument_type")
        if optionability not in {"YES", "NO", "PROXY", "UNKNOWN"}:
            errors.append(f"line {line}: invalid optionability_status {optionability!r}")
        if optionability != "UNKNOWN" and not row.get("optionability_source", "").strip():
            errors.append(f"line {line}: optionability_source required unless status UNKNOWN")
        if not row.get("source", "").strip(): errors.append(f"line {line}: blank source")
        if start and end and start >= end: errors.append(f"line {line}: non-positive interval")
        # Evidence first observed after the membership effective date would use
        # future knowledge for dates between start and source_asof.
        if start and asof and asof > start:
            errors.append(f"line {line}: source_asof follows membership start (lookahead)")
        if sid and start and end:
            intervals[sid].append((start, end, line))
            if t: ticker_intervals[t].append((start, end, line, sid))

for sid, xs in intervals.items():
    xs.sort()
    for a, b in zip(xs, xs[1:]):
        if b[0] < a[1]:
            errors.append(f"{sid}: overlapping intervals on lines {a[2]} and {b[2]}")

# A ticker may be reused by a different permanent security only after the prior
# security's interval ends. Simultaneous ownership makes signal identity ambiguous.
for ticker, xs in ticker_intervals.items():
    xs.sort()
    for a, b in zip(xs, xs[1:]):
        if b[0] < a[1]:
            errors.append(f"{ticker}: overlapping ticker ownership on lines {a[2]} ({a[3]}) and {b[2]} ({b[3]})")

if errors:
    print("INVALID POINT-IN-TIME UNIVERSE")
    print("\n".join(errors))
    raise SystemExit(1)
print(f"VALID: {sum(map(len, intervals.values()))} intervals, {len(intervals)} permanent security IDs")
