"""Validate market-data rows before point-in-time OOS testing."""
import csv, datetime as dt, sys
from pathlib import Path
path=Path(sys.argv[1] if len(sys.argv)>1 else "point_in_time_market_data.csv")
required=["security_id","trade_date","open_unadjusted","high_unadjusted","low_unadjusted","close_unadjusted","volume_unadjusted","split_factor","open_indicator","high_indicator","low_indicator","close_indicator","delisting_return","source","available_date"]
errors=[];seen=set()
def num(row,col,line,blank=False):
 s=row[col].strip()
 if blank and not s:return None
 try:return float(s)
 except ValueError:errors.append(f"line {line}: invalid {col} {s!r}");return None
with path.open(newline="",encoding="utf-8-sig") as f:
 r=csv.DictReader(f);rows=list(r)
 if r.fieldnames!=required:errors.append("header mismatch")
 for line,row in enumerate(rows,2):
  sid=row["security_id"].strip().upper()
  if not sid:errors.append(f"line {line}: blank security_id")
  if not row["source"].strip():errors.append(f"line {line}: blank source")
  try:
   day=dt.date.fromisoformat(row["trade_date"]);available=dt.date.fromisoformat(row["available_date"])
   if available!=day:errors.append(f"line {line}: EOD available_date must equal trade_date")
  except ValueError as e:errors.append(f"line {line}: invalid date ({e})");day=None
  key=(sid,row["trade_date"])
  if key in seen:errors.append(f"line {line}: duplicate security/date")
  seen.add(key)
  u=[num(row,x,line) for x in ["open_unadjusted","high_unadjusted","low_unadjusted","close_unadjusted"]]
  i=[num(row,x,line) for x in ["open_indicator","high_indicator","low_indicator","close_indicator"]]
  vol=num(row,"volume_unadjusted",line);factor=num(row,"split_factor",line);dl=num(row,"delisting_return",line,True)
  for name,vals in [("unadjusted",u),("indicator",i)]:
   if all(x is not None for x in vals):
    o,h,l,c=vals
    if min(vals)<=0:errors.append(f"line {line}: {name} OHLC must be positive")
    if h<max(o,l,c) or l>min(o,h,c):errors.append(f"line {line}: inconsistent {name} OHLC range")
  if vol is not None and (vol<0 or not vol.is_integer()):errors.append(f"line {line}: volume must be nonnegative whole number")
  if factor is not None and factor<=0:errors.append(f"line {line}: split_factor must be positive")
  if dl is not None and dl < -1:errors.append(f"line {line}: delisting_return below -100%")
if errors:
 print("INVALID",len(errors));print("\n".join(errors));raise SystemExit(1)
print(f"VALID: {len(rows)} point-in-time market rows")
