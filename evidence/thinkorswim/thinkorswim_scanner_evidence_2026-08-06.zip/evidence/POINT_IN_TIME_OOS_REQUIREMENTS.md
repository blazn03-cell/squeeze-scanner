# Point-in-time OOS requirements

The current historical approximation cannot establish an edge because it starts from today's watchlist. A valid promotion test must reconstruct what could actually have entered the scanner on each historical date.

## Required inputs
1. Membership intervals for the historical optionable-equity universe, with permanent security IDs, effective start/end dates, and source-as-of dates no later than the membership effective date.
2. Delisted symbols and identifier history; ticker reuse must map to a permanent security identifier.
3. Split/dividend-adjusted OHLCV plus unadjusted prices used for price filters.
4. Historical optionability where available. If unavailable, label the test as an equity-liquidity proxy rather than exact scanner parity.
5. Point-in-time earnings/calendar data if an earnings exclusion is tested.

## No-lookahead rules
- A security is eligible on date `d` only if `member_from <= d < member_to`.
- Data published after `d` cannot alter eligibility or indicator values at `d`.
- Signals use the completed session and execute no earlier than the next session open.
- Corporate-action mappings must be known as of the action date, not today's symbol history.
- Rejected candidates, missing bars, delistings, and zero-share outcomes remain in the audit denominator.

## Required reports
- Coverage by date and percentage of candidates with complete data.
- Delisting/missing-data counts and reasons.
- Trade and symbol-cluster bootstrap confidence intervals after costs.
- Cost sensitivity and leave-one-symbol-out concentration.
- Calendar walk-forward folds with frozen parameters.
- Separate results by ATR band, liquidity band, regime, and year.

Use `point_in_time_market_data_template.csv` and its validator for permanent-ID EOD rows. Unadjusted OHLC/volume drive price and dollar-volume filters; separately supplied indicator OHLC drive technical calculations; split factor, delisting return, source, and date-available are retained explicitly.

## Promotion gate
Do not call the result a demonstrated edge unless the prospective and point-in-time evidence agree, after-cost confidence intervals exclude zero, concentration is acceptable, and live scanner/quote parity is reproducible. This validator checks membership-file integrity only; it does not prove that a source is genuinely point-in-time.
