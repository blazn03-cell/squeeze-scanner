﻿# Intraday candidate replay — 2026-08-06 checkpoint

Yahoo 5-minute regular-session bars were used to approximate the frozen V4.1 chart conditions for all nine split-stage candidates and the experimental V4.2 time/anti-chase gates. This is not thinkorswim alert proof and cannot reproduce TOS VWAP/indicator values exactly.

## Findings
- Frozen V4.1 approximation produced qualifying bars for CHD, EXPE, NWS, and SAN; the first qualifying bar for each was 09:30 ET.
- V4.2's 09:45 start and one-ATR VWAP anti-chase gate removed the opening-bar qualifications for CHD, EXPE, and NWS.
- SAN retained one approximate V4.2 qualifying bar at 09:55 ET, which would imply a next-bar closed-candle alert around 10:00 ET on a 5-minute chart.
- LTM, SCHW, SWK, WBS, and ZBH had no approximate qualifying bars by the checkpoint.
- Eight of nine candidates were below their opening price at the checkpoint; this does not establish that any signal caused or avoided a profit because no standardized entry/exit was executed.

## Reliability implication
Opening-bar qualifications are especially vulnerable to session-boundary effects: VWAP has only one session bar while rolling MFI/RSI/cloud/box inputs include prior-session history. The experimental delayed-start gate is operationally justified for forward testing, but one day is not evidence of a profitable improvement.

## Decision
Keep V4.1 frozen for comparison and V4.2 separate. Do not retrofit today's result into the preregistered arm. Log future 09:30-only versus post-09:45 qualifications prospectively.
