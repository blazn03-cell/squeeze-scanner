# V4 intraday extended-hours configuration risk

**Status: live setting not yet proved. Paper testing only.**

The V4.1/V4.2 chart studies gate alerts to regular-session clock times, but the indicator lookbacks still consume every bar loaded by the chart. The scripts do not reconstruct regular-session-only lookbacks internally.

This matters because:

- the 5-minute Darvas proxy uses 78 bars, intended to represent one 6.5-hour regular session;
- the 15-minute proxy uses 26 bars for the same purpose;
- MFI, RSI, Bollinger, ATR, and Ichimoku lookbacks also inherit the chart's bar stream;
- when extended-hours bars are displayed, overnight and premarket bars can therefore alter the box, oscillators, volatility, and cloud even though alerts are time-gated.

## Required proof

Before treating an intraday alert as protocol-valid:

1. Open chart settings and prove extended-hours display is off.
2. Confirm the chart aggregation is exactly 5 minutes or 15 minutes.
3. Reload the study and capture the settings plus dashboard in one timestamped evidence row.
4. Do not compare a regular-hours-only replay with a chart that includes extended-hours bars.

The existing live compile/render proves that the code runs; it does not prove regular-hours-only input data. Until the setting is captured, genuine Ring validation remains incomplete.
