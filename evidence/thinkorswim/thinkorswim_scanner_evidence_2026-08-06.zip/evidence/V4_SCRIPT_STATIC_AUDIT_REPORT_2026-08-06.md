# V4 script static audit — current

Fourteen scoped scripts were checked for editor-role invariants, balanced expressions, absence of order placement, scanner single-output behavior, completed-session daily references, quote isolation from VWAP, live-spread direct bid/ask sourcing and unavailable-value handling, intraday aggregation/RTH guards, Ding/Ring separation, completed-bar transition offsets, experimental anti-chase/session-deduplication/final-boundary delivery architecture, neutral no-flow MFI handling in V4.2.2 and V4.7 daily scan/quote, account-specific affordability scan/quote parity, and risk-study daily-reference/whole-share/capital-cap/aggregation-guard/fail-closed-entry behavior.

**Result: 102/102 checks passed.**

The temporal checks confirm that experimental Ring delivery derives from the prior completed bar and is not blocked merely because the current delivery bar is at the 15:30 ET cutoff. They are static checks, not a substitute for a genuine timestamped Ring.

Risk-study cost input is now visible as COST/SH; V4.2.2, risk-study, and spread-quote live compilation/parity remain pending.

