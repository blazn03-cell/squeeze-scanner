# V4.6 open gates — prioritized current state

**Decision: paper-test only. No demonstrated profitable edge.** Historical and replay confidence intervals include zero; point-in-time OOS data and prospective observations are missing.

## P0 — platform correctness before trusting an alert

1. **Restart persistence:** after restarting thinkorswim, reopen the Score formula and prove DAY aggregation plus extended hours off; confirm 0-5 values reload.
2. **Single alert study:** keep only the selected V4.2.x revision enabled. Disable V4.1 and superseded experimental revisions on that pane.
3. **Chart data scope:** prove 5m or 15m and extended-hours display off together. Clock-time gating alone does not keep overnight bars out of lookbacks.
4. **V4.2.2 live render:** compile/apply the reliability revision and verify `BELOW VWAP`, exactly one dashboard, and neutral MFI 50 when both money-flow sums are zero. V4.2 remains the proved fallback until this succeeds.
5. **Sizing repair:** compile the fail-closed manual-entry risk study; prove zero entry or zero observed spread returns zero shares, then prove identical labels on 5m, 15m, and DAY for the same actual entry/spread/slippage inputs; check $100/$250/$500/$1,000.
6. **Spread repair:** compile the direct bid/ask custom quote during regular hours and match five symbols to displayed bid/ask arithmetic; blank must remain unknown, not zero.
7. **V4.7 daily parity:** compile the new daily quote and split-stage scan under separate names; prove DAY/extended-off settings and log `scan_type = V4.7`. Do not replace frozen V4 or pool versions.
8. **Affordability stage:** compile the account-specific DAY filter after V4/V4.7; prove a zero-result $100 scan is accepted and never rounded up. Recheck with actual entry/spread after Ring.
7. **Genuine Ring:** capture qualifying-bar start/close, Ring at the close/next-bar boundary, every gate, spread, cost, and sizing. Synthetic/static tests do not satisfy this gate.

## P1 — prospective reliability

1. Run fresh V3→V4 scans at 08:35, 10:30, and 14:15 CT using the explicit Scan button; record both ET/CT clocks, counts, symbols, runtimes, and load failures.
2. Require same-day completed-daily fields to remain invariant across non-error checkpoints.
3. Archive the official prospective universe and identity classification daily.
4. Log every candidate, reject, unavailable spread, load error, and zero-share outcome. Validator suites currently pass, but the genuine forward logs contain zero observations.

## P1 — unbiased historical evidence

Acquire a permanent-ID point-in-time universe with delistings, non-overlapping ticker ownership, historical optionability or a disclosed proxy, corporate actions, adjusted indicator prices, unadjusted filter prices, and source-known dates. The current selected-symbol Yahoo history cannot satisfy this gate.

## P2 — promotion evidence

Do not promote until there are at least 100 forward-paper trades per arm, after-cost bootstrap and symbol-cluster confidence intervals exclude zero, no symbol supplies more than 20% of positive R, slippage is acceptable, normal/high-volatility regimes are adequate, and scanner errors remain below 1%.

A Ring means coded conditions aligned. It does not mean the trade is known to be profitable.

## Latest live-access gate

Restore/unminimize the thinkorswim Watchlist window before the next checkpoint. The latest attempt detected five thinkorswim windows, but the Watchlist root was disabled, activation returned access denied, and retry capture showed only desktop wallpaper. No settings were verified.
