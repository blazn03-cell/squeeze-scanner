import csv,subprocess,sys,tempfile
from pathlib import Path
HERE=Path(__file__).parent;V=HERE/"validate_point_in_time_join.py"
UF=next(csv.reader((HERE/"point_in_time_universe_template.csv").open()));MF=next(csv.reader((HERE/"point_in_time_market_data_template.csv").open()))
u=dict(zip(UF,["ID1","AAA","COMMON_STOCK","1","YES","PRIMARY_OPTIONS","2024-01-02","2024-06-03","PRIMARY","2024-01-02"]))
m=dict(zip(MF,["ID1","2024-01-02","10","10.5","9.8","10.2","100000","1","10","10.5","9.8","10.2","","PRIMARY","2024-01-02"]))
def ok(us,ms):
 with tempfile.TemporaryDirectory() as td:
  up=Path(td)/"u.csv";mp=Path(td)/"m.csv"
  for p,fields,rows in [(up,UF,us),(mp,MF,ms)]:
   with p.open("w",newline="") as f:w=csv.DictWriter(f,fieldnames=fields);w.writeheader();w.writerows(rows)
  return subprocess.run([sys.executable,str(V),str(up),str(mp)],capture_output=True).returncode==0
cases=[("valid",[u],[m],True),("unknown_id",[u],[{**m,"security_id":"ID2"}],False),("before_start",[u],[{**m,"trade_date":"2024-01-01","available_date":"2024-01-01"}],False),("exclusive_end",[u],[{**m,"trade_date":"2024-06-03","available_date":"2024-06-03"}],False),("excluded_identity_retained",[{**u,"instrument_type":"ETF","identity_eligible":"0"}],[m],True)]
p=0
for n,us,ms,w in cases:g=ok(us,ms);hit=g==w;print(("PASS" if hit else "FAIL"),n,"accepted="+str(g));p+=hit
print(f"PASS: {p}/{len(cases)} point-in-time join cases");raise SystemExit(0 if p==len(cases) else 1)
