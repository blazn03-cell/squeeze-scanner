# V4.1 manual-entry sizing audit — 2026-08-06

## Defect in the previous chart aid

`V4_SmallAccountRiskShares_ChartStudy.ts` estimates entry as prior daily close plus 0.4 ATR. That is useful as a premarket planning price, but an intraday Ring can occur far from that estimate. Capital-limited shares could therefore be calculated from a stale hypothetical price rather than the actual intended fill.

## Fail-closed repair

`V4_1_ManualEntryRiskShares_ChartStudy.ts` requires `entryPrice > 0` and `observedSpreadPerShare > 0`. Both default to zero, independently disabling sizing until supplied. After a Ring, enter the actual intended/fill price and the observed dollar spread/share. The study derives round-trip cost/share as observed spread + expected round-trip slippage + fees, preventing a manually entered cost from falling below those components.

The model then uses:

- prior completed DAY ATR(14);
- stop = actual entry − 1.5 ATR;
- round-trip cost/share = spread/share + expected round-trip slippage/share + fees/share;
- risk/share = 1.5 ATR + round-trip cost/share;
- risk shares = floor(0.50% account risk ÷ risk/share);
- capital shares = floor(20% account cap ÷ actual entry);
- final shares = smaller whole-share count.

Account input remains restricted to $100–$1,000. Invalid aggregation/input, nonpositive stop, missing entry, or missing spread all force zero shares. The same manual entry and settings should produce identical labels on 5m, 15m, and DAY; live compile/parity remains required.

This is risk-control logic, not evidence of profitability.
