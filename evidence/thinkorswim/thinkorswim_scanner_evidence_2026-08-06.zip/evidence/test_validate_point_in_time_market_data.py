import csv,subprocess,sys,tempfile
from pathlib import Path
HERE=Path(__file__).parent;V=HERE/"validate_point_in_time_market_data.py";FIELDS=next(csv.reader((HERE/"point_in_time_market_data_template.csv").open()))
base=dict(zip(FIELDS,["ID1","2024-01-02","10","10.5","9.8","10.2","100000","1","10","10.5","9.8","10.2","","PRIMARY","2024-01-02"]))
def ok(rows):
 with tempfile.TemporaryDirectory() as td:
  p=Path(td)/"m.csv"
  with p.open("w",newline="") as f:w=csv.DictWriter(f,fieldnames=FIELDS);w.writeheader();w.writerows(rows)
  return subprocess.run([sys.executable,str(V),str(p)],capture_output=True).returncode==0
cases=[("valid",[base],True),("duplicate",[base,base],False),("future_available",[{**base,"available_date":"2024-01-03"}],False),("bad_high",[{**base,"high_unadjusted":"9"}],False),("fractional_volume",[{**base,"volume_unadjusted":"1.5"}],False),("zero_factor",[{**base,"split_factor":"0"}],False),("delist_below_minus_one",[{**base,"delisting_return":"-1.1"}],False)]
p=0
for n,r,w in cases:g=ok(r);hit=g==w;print(("PASS" if hit else "FAIL"),n,"accepted="+str(g));p+=hit
print(f"PASS: {p}/{len(cases)} market-data validator cases");raise SystemExit(0 if p==len(cases) else 1)
