"""Prove V4.7 daily candidates differ only by header and MFI no-flow branch."""
from pathlib import Path

HERE = Path(__file__).resolve().parent
SCRIPTS = HERE.parent / "scripts" if (HERE.parent / "scripts").exists() else HERE
PAIRS = [
    ("V4_ConfirmATR_Daily_Scan.ts", "V4_7_ConfirmATR_Daily_Scan_EXPERIMENTAL.ts"),
    ("V4_ConfirmLayer_CustomQuote_v2.ts", "V4_7_ConfirmLayer_CustomQuote_EXPERIMENTAL.ts"),
]

def lines(name):
    value = (SCRIPTS / name).read_text(encoding="utf-8-sig").splitlines()
    while value and value[-1] == "":
        value.pop()
    return value

for frozen_name, candidate_name in PAIRS:
    frozen = lines(frozen_name)
    candidate = lines(candidate_name)
    assert candidate[0].startswith("# V4.7 EXPERIMENTAL"), candidate_name
    candidate = candidate[1:]
    normalized = []
    i = 0
    while i < len(candidate):
        line = candidate[i]
        if line.startswith("def mfi = if ") and " then 50" in line:
            assert i + 2 < len(candidate)
            assert "else if" in candidate[i + 1] and "then 100" in candidate[i + 1]
            assert candidate[i + 2].lstrip().startswith("else 100 - 100 / (1 +")
            normalized.append(
                "def mfi = if nMF == 0 then 100 else 100 - 100 / (1 + pMF / nMF);"
                if "nMF" in line else
                "def mfi = if negMF == 0 then 100 else 100 - 100 / (1 + posMF / negMF);"
            )
            i += 3
        else:
            normalized.append(line)
            i += 1
    assert normalized == frozen, f"unregistered difference in {candidate_name}"
    print("PASS only header + neutral no-flow MFI branch:", candidate_name)

print("PASS: 2/2 V4.7 daily parity checks")
