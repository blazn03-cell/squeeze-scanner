# V4 risk-study secondary-aggregation documentation audit

Schwab documents `high(period = AggregationPeriod.DAY)[1]` as the pattern for a prior-day value and states that a secondary aggregation cannot be lower than the chart's primary aggregation:

https://toslc.thinkorswim.com/center/reference/thinkScript/tutorials/Advanced/Chapter-11---Referencing-Secondary-Aggregation

The revised risk study:

- defines daily high, low, and close in separate secondary-aggregation variables;
- calculates true range and its 14-day average entirely from those daily variables;
- uses the prior completed daily close and ATR;
- supports only 5m, 15m, and DAY time charts, where DAY is equal to or higher than the primary aggregation;
- forces zero shares and displays a red warning on unsupported aggregations.

This resolves the static aggregation design defect. A live thinkorswim compile plus identical 5m/15m/DAY label values is still required.
