# Point-in-time validator correction — 2026-08-06

The original membership validator contained a lookahead-direction error: it rejected source evidence dated before membership began but accepted evidence first observed after membership began. For point-in-time testing, later evidence cannot justify eligibility on earlier dates.

Corrections:

- `source_asof > member_from` is now rejected as lookahead;
- evidence dated on or before the effective start is accepted;
- permanent `security_id` is mandatory;
- point-in-time instrument type and identity eligibility are mandatory; only common stock and ADR classify eligible;
- optionability status and its source are mandatory unless explicitly `UNKNOWN`; a disclosed `PROXY` is accepted for sensitivity work but is not exact scanner parity;
- overlap is checked by permanent ID, while ticker ownership is separately required not to overlap; this permits legitimate non-overlapping ticker reuse but rejects ambiguous simultaneous ownership;
- the template and requirements were updated;
- nine regression cases cover valid membership, pre-effective evidence, lookahead, missing IDs, bad intervals, permanent-ID overlap, valid ticker reuse, simultaneous ticker collision, and missing schema.

**Regression result: 14/14 passed.** This validates membership-file integrity only. A `PROXY` status must be disclosed and cannot be called exact optionable-universe parity. It does not supply the still-missing point-in-time historical universe or demonstrate profitability.
