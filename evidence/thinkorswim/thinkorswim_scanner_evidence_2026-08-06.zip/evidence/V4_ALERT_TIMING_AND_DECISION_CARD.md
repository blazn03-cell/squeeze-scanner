# V4 alert timing and decision card

**Paper testing only. A Ring is rule confirmation, not proof that a trade will profit.**

## Clock (America/Chicago / Central Time)

- Monitoring window: **08:45 through 14:30 CT** (09:45-15:30 ET in thinkScript).
- `DING`: same-bar VWAP-reclaim early warning. Do not treat it as an entry.
- `RING`: eligible for evaluation on the first tick of the next bar, at the clock boundary when the qualifying bar closes. Data/platform latency can delay the audible notification.
  - 5-minute chart: 5 minutes after that qualifying bar started; earliest possible Ring is **08:50 CT**.
  - 15-minute chart: 15 minutes after that qualifying bar started; earliest possible Ring is **09:00 CT**.
- A qualification beginning at 14:30 CT is rejected. A valid 14:25 CT 5-minute qualification may deliver its delayed Ring at exactly 14:30 CT.
- After the cutoff, `TIME WAIT` means no new setup should be acted on.

## A valid experimental V4.2 Ring requires

1. The completed qualifying bar is inside the time window.
2. Price is above VWAP and between 0 and 1.0 ATR above it.
3. Price is above the Ichimoku cloud.
4. The stable Darvas-box breakout condition is true.
5. The Bollinger confirmation condition is true.
6. MFI(14) is greater than 50.
7. RSI(14) is greater than 50.
8. It is the first qualifying confirmation for that symbol/session.

Before paper entry, also require the daily split-stage workflow: fresh V3 membership, model ATR below 4%, confirmation count at least 4/5, and eligible common-equity/ADR identity. The risk study must return at least one affordable share; **zero shares means skip and must not be rounded up**.

Bid/ask spread, expected slippage, and fees must be recorded. A blank spread is unknown, not zero. Round-trip cost/share must cover all three components.

## How soon can it be called "right"?

- Immediately after Ring: only **technically valid under the frozen rules**.
- After the trade closes: one observed outcome, not evidence of an edge.
- After at least 100 forward-paper trades per arm, with costs, concentration/regime checks, scanner error below 1%, and a bootstrap 95% confidence interval for mean R excluding zero: evidence can be reassessed.

Historical and intraday replay confidence intervals currently include zero. No profitable edge has been demonstrated.

`Alert.BAR` only limits firing to once per bar; it does not itself guarantee close-only evaluation. The script's `[1]` reference supplies the completed-bar delay. Live delivery timing still requires a genuine Ring record.

For every Ring, record the exact script version, qualifying-bar boundary, actual alert-receipt time, and latency in seconds. Do not alter a delayed timestamp to make it equal the expected boundary.

Also record positive and negative MFI flow sums. If both are zero, skip: older fallback code can display MFI 100 without positive-flow evidence, while V4.2.2 correctly treats the state as neutral 50.
