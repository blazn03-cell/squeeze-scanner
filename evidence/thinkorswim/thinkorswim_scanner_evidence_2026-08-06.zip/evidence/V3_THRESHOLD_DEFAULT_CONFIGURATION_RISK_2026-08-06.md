# V3 threshold-default configuration risk — 2026-08-06

## Finding

The byte-canonical `V3_EntryConfirmed_Daily_Scan.ts` declares `scoreThreshold = 60`, while the current V4 source workflow and candidate forward-log validator are fixed at 65. A fresh paste with defaults could therefore admit score-60—64 names without an obvious formula error.

An older selected-universe robustness diagnostic produced 93 threshold-60 trades versus 59 threshold-65 trades (34 additional observations, about 57.6% more). That study predates later parity corrections and has selection bias, so it does **not** estimate current profitability. It does demonstrate that the default difference can materially change workload and membership outside the 13-name cohort where all scores were >=65.

## Control

- Install `V3_EntryConfirmed_Daily_Scan_Threshold65_INSTALL.ts` for the current V4 source arm.
- Preserve the canonical default-60 source only under reference-only.
- If a threshold-60 diagnostic arm is retained, give it a separate saved-query name and version tag; do not feed it silently into the threshold-65 V4 arm.
- Forward candidate validation remains locked to threshold 65.

The package verifier proves the install variant differs only by its header and the 60—65 default. This is configuration control, not evidence of edge.
