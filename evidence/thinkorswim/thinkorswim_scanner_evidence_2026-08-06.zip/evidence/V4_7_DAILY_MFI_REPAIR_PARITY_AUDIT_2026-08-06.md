# V4.7 daily MFI repair parity audit — 2026-08-06

V4.7 is a **new experimental reliability arm**, not a rewrite of the frozen V4 daily arm.

Files:

- `V4_7_ConfirmATR_Daily_Scan_EXPERIMENTAL.ts`
- `V4_7_ConfirmLayer_CustomQuote_EXPERIMENTAL.ts`

Automated normalized comparison confirms each candidate differs from its V4 source only by a version header and the MFI zero-flow branch. Both use identical semantics:

- positive flow = 0 and negative flow = 0 → MFI 50;
- negative flow = 0 and positive flow > 0 → MFI 100;
- otherwise use the standard money-ratio calculation.

The scan and quote retain prior-completed-session offsets, strict MFI `> 50`, ATR `< 4.0`, confirmation threshold 4/5, and all frozen lengths. This prevents the daily ranking column and scan from disagreeing about the repaired branch.

Static parity does not prove thinkorswim compilation or historical edge. Save V4.7 under new names, keep V4 unchanged, and do not pool V4 and V4.7 forward observations without a version field.
