# V4 canonical small-account sizing diagnostic - 2026-08-06

**External arithmetic only; paper testing, not an order recommendation.** This reconciles the V4 package to its preregistered sizing inputs: **0.50% account risk, 20% capital cap, 1.5 ATR stop, 0.4 ATR entry buffer, and $0.06 round-trip cost/share**.

The prior diagnostic used the script's stale 0.25%/10% defaults even though the frozen V4 protocol used 0.50%/20%. It also allowed ATR and prior close to inherit the chart aggregation, making the earlier 5m live render unsuitable as daily-sizing evidence. The script now uses explicit DAY secondary aggregation and corrected defaults. Exact chart values can still differ slightly from this external approximation because thinkorswim calculates the actual prior-session ATR.

## Upper-bound affordability under the fixed $0.06 cost assumption

- $100: none
- $250: SAN (1 sh)
- $500: NWS (1 sh), SAN (3 sh), WBS (1 sh)
- $1,000: CHD (1 sh), LTM (1 sh), NWS (3 sh), SAN (7 sh), SCHW (1 sh), WBS (2 sh), ZBH (1 sh)

These counts can only stay the same or fall when observed spread plus expected slippage exceeds $0.06. They are not proof that the candidates were executable. Zero shares is a required skip and must never be rounded to one. A positive share count only establishes provisional mechanical affordability; all scanner, alert, spread, timing, and cost gates still apply, and profitability remains unproven.
