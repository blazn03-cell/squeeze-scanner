# V4 forward-log validator hardening — 2026-08-06

The prior validator could accept incomplete indicator flags, blank pass fields, fractional shares truncated to integers, inconsistent ATR-cap flags, duplicate observations, and incorrect sizing arithmetic.

The replacement enforces:

- one row per date/time/ticker/scan checkpoint, while repeated checkpoints are deduplicated to one daily signal;
- threshold exactly 65;
- all five component flags and eligibility/pass flags populated as 0/1;
- confirmation count 0-5 and equal to all five components;
- strict ATR cap (`atr_pct < 4.0`);
- V4 pass equals identity eligibility + confirmation gate + ATR gate;
- nonnegative whole-share fields without truncation;
- risk-budget, risk-share, capital-share, minimum-constraint, and deprecated-alias arithmetic;
- zero shares cannot be marked `paper_trade`.
- completed-daily fields cannot drift across same-day checkpoints;
- at most one checkpoint per date/ticker may carry `paper_trade`; repeats use `observation_only`.
- ET and CT checkpoint timestamps are both required and date-aware timezone conversion must agree.
- account input must remain within $100-$1,000, risk must remain 0.50%, capital cap 20%, score 0-100, and entry/risk-per-share positive.
- optional affordability-stage use is explicit; when used, estimated whole shares and pass/fail must agree, and a paper action cannot bypass a failed stage;
- round-trip cost must cover observed spread plus slippage plus fees, and risk/share must equal next-open entry minus stop plus that cost.

**Regression result: 27/27 passed.** The empty prospective log validates as zero rows. This proves validator gate coverage, not profitability or sample sufficiency.
