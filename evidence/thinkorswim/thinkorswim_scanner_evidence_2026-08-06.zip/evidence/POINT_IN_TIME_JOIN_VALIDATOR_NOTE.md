# Point-in-time membership/market join validator

Every EOD market row must map by permanent security ID and trade date to exactly one membership interval under `member_from <= date < member_to`. Unknown IDs, pre-membership rows, end-boundary rows, gaps, and overlapping matches are rejected. Excluded products may remain in the joined denominator but are counted separately from identity-eligible rows.

**Regression result: 5/5 passed.** This validates join mechanics only; genuine point-in-time inputs remain missing.
