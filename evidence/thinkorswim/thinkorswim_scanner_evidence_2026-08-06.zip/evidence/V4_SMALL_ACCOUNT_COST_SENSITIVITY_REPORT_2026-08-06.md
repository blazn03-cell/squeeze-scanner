# V4 small-account cost sensitivity - 2026-08-06

**External arithmetic only; paper testing, not recommendations.** Share counts use 0.50% risk, 20% cap, and the same approximate entries/ATR stops as the nine-name diagnostic. Cost/share scenarios are $0.06, $0.10, $0.25, and $0.50.

## $100 account
- Cost $0.06/share: none
- Cost $0.10/share: none
- Cost $0.25/share: none
- Cost $0.50/share: none

## $250 account
- Cost $0.06/share: SAN (1 sh)
- Cost $0.10/share: SAN (1 sh)
- Cost $0.25/share: SAN (1 sh)
- Cost $0.50/share: SAN (1 sh)

## $500 account
- Cost $0.06/share: NWS (1 sh), SAN (3 sh), WBS (1 sh)
- Cost $0.10/share: NWS (1 sh), SAN (3 sh), WBS (1 sh)
- Cost $0.25/share: NWS (1 sh), SAN (3 sh), WBS (1 sh)
- Cost $0.50/share: NWS (1 sh), SAN (2 sh), WBS (1 sh)

## $1,000 account
- Cost $0.06/share: CHD (1 sh), LTM (1 sh), NWS (3 sh), SAN (7 sh), SCHW (1 sh), WBS (2 sh), ZBH (1 sh)
- Cost $0.10/share: CHD (1 sh), LTM (1 sh), NWS (3 sh), SAN (7 sh), SCHW (1 sh), WBS (2 sh), ZBH (1 sh)
- Cost $0.25/share: CHD (1 sh), LTM (1 sh), NWS (2 sh), SAN (6 sh), SCHW (1 sh), WBS (2 sh), ZBH (1 sh)
- Cost $0.50/share: CHD (1 sh), LTM (1 sh), NWS (2 sh), SAN (4 sh), SCHW (1 sh), WBS (2 sh)

Observed spread plus expected slippage must not be understated. Higher costs can only reduce affordability. This sensitivity does not estimate returns or demonstrate an edge.
