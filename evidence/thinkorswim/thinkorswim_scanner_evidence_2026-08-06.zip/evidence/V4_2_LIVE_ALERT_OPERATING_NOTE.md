﻿# V4.2 live alert operating note

- Keep only **one alert-producing study active per chart pane**. Running V4.1 and V4.2 together can duplicate labels and alerts.
- On the SAN 5m V4.2 test pane, V4.1 was disabled on 2026-08-06; V4.2 remains active.
- `Sound.Ding` = VWAP reclaim **early warning only**. Do not enter from this sound alone.
- `Sound.Ring` = completed-bar confirmation on the first tick of the next bar (the qualifying bar's close boundary), after the time, anti-chase, indicator, and first-confirmation gates.
- A Ring still is not proof the trade will win. Apply the position-size study and skip zero-share outputs.
- Use a separate pane if comparing frozen V4.1 prospectively, and log one observation per arm without double-counting a candidate.
