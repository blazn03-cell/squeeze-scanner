"""Regression tests for validate_point_in_time_universe.py."""
import csv, subprocess, sys, tempfile
from pathlib import Path

VALIDATOR = Path(__file__).with_name("validate_point_in_time_universe.py")
FIELDS = ["security_id", "ticker", "instrument_type", "identity_eligible", "optionability_status", "optionability_source", "member_from", "member_to", "source", "source_asof"]

def run(rows, fields=FIELDS):
    with tempfile.TemporaryDirectory() as td:
        p = Path(td) / "u.csv"
        with p.open("w", newline="", encoding="utf-8") as f:
            w = csv.DictWriter(f, fieldnames=fields)
            w.writeheader(); w.writerows(rows)
        result = subprocess.run([sys.executable, str(VALIDATOR), str(p)], text=True,
                                capture_output=True)
        return result.returncode == 0, result.stdout + result.stderr

base = dict(security_id="ID1", ticker="AAA", instrument_type="COMMON_STOCK", identity_eligible="1", optionability_status="YES", optionability_source="PRIMARY_OPTIONS", member_from="2024-01-02",
            member_to="2024-06-03", source="PRIMARY", source_asof="2024-01-02")
cases = []
cases.append(("valid", [base], True))
cases.append(("announced_before_effective", [{**base, "source_asof":"2023-12-20"}], True))
cases.append(("lookahead_source", [{**base, "source_asof":"2024-01-03"}], False))
cases.append(("blank_security_id", [{**base, "security_id":""}], False))
cases.append(("nonpositive_interval", [{**base, "member_to":"2024-01-02"}], False))
cases.append(("overlap_same_id", [base, {**base, "ticker":"AAB", "member_from":"2024-05-01", "member_to":"2024-08-01"}], False))
cases.append(("ticker_reuse_distinct_ids", [base, {**base, "security_id":"ID2", "member_from":"2024-07-01", "member_to":""}], True))
cases.append(("simultaneous_ticker_collision", [base, {**base, "security_id":"ID2", "member_from":"2024-05-01", "member_to":"2024-08-01"}], False))
cases.append(("valid_etf_excluded", [{**base, "instrument_type":"ETF", "identity_eligible":"0"}], True))
cases.append(("etf_falsely_eligible", [{**base, "instrument_type":"ETF", "identity_eligible":"1"}], False))
cases.append(("invalid_instrument_type", [{**base, "instrument_type":"MYSTERY"}], False))
cases.append(("valid_optionability_proxy", [{**base, "optionability_status":"PROXY", "optionability_source":"DISCLOSED_PROXY"}], True))
cases.append(("missing_optionability_source", [{**base, "optionability_source":""}], False))
cases.append(("missing_security_id_column", [{k:v for k,v in base.items() if k!="security_id"}], False, [x for x in FIELDS if x!="security_id"]))

passed = 0
for item in cases:
    name, rows, expected, *custom = item
    ok, output = run(rows, custom[0] if custom else FIELDS)
    hit = ok == expected
    print(("PASS" if hit else "FAIL"), name, "accepted=" + str(ok))
    if not hit: print(output)
    passed += hit
print(f"PASS: {passed}/{len(cases)} point-in-time validator cases")
raise SystemExit(0 if passed == len(cases) else 1)
