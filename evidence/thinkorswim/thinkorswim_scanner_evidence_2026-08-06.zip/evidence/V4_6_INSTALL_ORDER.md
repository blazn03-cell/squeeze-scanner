# V4.6 clean install order

**Paper testing only. Do not place live orders from these scripts.**

## Keep unchanged

Keep the five canonical V3 scripts and saved V3 query. Do not overwrite the frozen V3 arm or its forward log.

## Daily split-stage workflow

1. `V4_ConfirmLayer_CustomQuote_v2.ts` — custom quote named `V4_ConfirmCount`; set **DAY** and extended hours **off**.
2. `V4_ConfirmATR_Daily_Scan.ts` — the only study filter in the second-stage V4 query; set **DAY**, extended hours **off**, and Scan in = freshly rerun canonical V3 saved query.
3. Do not use `V4_EntryConfirmed_Daily_Scan_v2.ts` against the whole universe; it is retained for formula/audit parity because that combined architecture timed out live.

Optional parallel reliability arm: install `V4_7_ConfirmLayer_CustomQuote_EXPERIMENTAL.ts` and `V4_7_ConfirmATR_Daily_Scan_EXPERIMENTAL.ts` under new names. They change only no-flow MFI handling. Do not overwrite or stop the frozen V4 arm. Log their rows with `scan_type = V4.7` so versions are not silently pooled.

Optional account-specific third stage: apply `V4_SmallAccountAffordability_Daily_Scan_EXPERIMENTAL.ts` only to fresh V4/V4.7 results, with DAY and extended hours off. Set the actual account size and a conservative minimum cost/share. This is an early impossibility filter; actual-entry/spread sizing after Ring remains authoritative.

Optional matching watchlist column: add `V4_EstimatedAffordableShares_CustomQuote_EXPERIMENTAL.ts`, DAY/extended off, with identical inputs. Green/one-or-more is only a planning upper bound; zero means skip immediately.

## Intraday chart

4. Install `V4_2_2_IntradayConfirm_ChartStudy_EXPERIMENTAL.ts` as a new experimental study on a **5m or 15m regular-hours-only** chart. It carries forward V4.2.1 clarity and neutralizes a zero-positive/zero-negative-flow MFI window.
5. Disable V4.1, V4.2, V4.2.1, and every superseded alert-producing revision on that same pane before applying V4.2.2. Exactly one alert study may remain enabled.
6. Compile and verify `BELOW VWAP`, one dashboard, start 09:45 ET, end 15:30 ET, max distance 1 ATR, box required, first confirmation only, and no-flow MFI = 50. Until this live proof succeeds, keep the previously compiled V4.2 as the active fallback instead of claiming V4.2.2 installed.

## Sizing and spread

7. Replace the hypothetical-entry sizing revision with `V4_1_ManualEntryRiskShares_ChartStudy.ts`. Defaults: $250, 0.50% risk, 20% cap, 1.5 ATR stop, entry price zero, observed spread zero, and expected round-trip slippage $0.04/share. Zero entry or spread deliberately disables sizing. After a Ring, enter the actual intended/fill price and observed dollar spread/share. Verify visible ENTRY, STOP, RISK/SH, COST/SH, SPREAD/SH, and SLIP/SH labels. It supports only 5m, 15m, and DAY and must match across all three when inputs match.
8. Add `V4_LiveSpreadPct_CustomQuote_EXPERIMENTAL.ts` to a **copied** watchlist layout during regular hours. It uses direct current bid/ask. Blank means unavailable, never zero.

## Required validation before use

- Restart persistence of DAY/off Score configuration.
- Chart extended-hours display off.
- Fresh V3→V4 scans at 08:35, 10:30, and 14:15 CT.
- Five-symbol spread arithmetic parity.
- $100/$250/$500/$1,000 sizing checks and cross-aggregation parity.
- One genuine Ring with start/close/alert timestamps and validated risk fields.

Historical confidence intervals include zero, prospective logs are empty, and point-in-time OOS data are missing. Installation success is not profitability evidence.
