# Point-in-time data-source decision

## Decision

Use a survivorship-safe security database with permanent identifiers, historical names/tickers, daily prices and volume, corporate actions, and delisting events/returns. **CRSP daily stock data is the preferred specification** if access is available.

CRSP/WRDS documentation identifies permanent security/company identifiers, price and volume history, historical identity fields, corporate actions, and security delisting information. Its delisting records include delisting dates, reason codes, prices/amounts, and returns. Those fields address the largest unresolved defect in the current Yahoo replay: present-day symbol selection and omission of securities that disappeared.

Primary references:

- https://wrds-www.wharton.upenn.edu/pages/grid-items/crsp-stock-database-structure/
- https://wrds-www.wharton.upenn.edu/documents/399/Data_Descriptions_Guide.pdf
- https://wrds-www.wharton.upenn.edu/demo/crsp/form/

## Why the free sources are insufficient by themselves

Nasdaq Trader publishes current symbol-directory files that are refreshed during the day. This is useful for a **prospective daily archive**, but a current directory is not a complete historical point-in-time universe unless snapshots were retained every day. It also does not by itself provide the complete adjusted OHLCV and delisting-return history required for this test.

- https://www.nasdaqtrader.com/trader.aspx?id=symboldirdefs

SEC EDGAR provides filing histories and stable CIK identifiers. It can help map issuer identity and verify corporate history, but EDGAR is not an exchange-membership tape and does not supply the daily market fields needed to reconstruct the scanner universe.

- https://www.sec.gov/search-filings

## Minimum extract

For every U.S. common-equity security/date in the study window: permanent security id, permanent company id, effective ticker/name interval, exchange/listing status, share/security type, adjusted open/high/low/close, volume, shares outstanding, distributions/split factors, delisting date/code/return, and acquisition links when applicable.

Universe membership must be computed **for each date using only information effective by that date**. Apply the frozen price, volume, dollar-volume, ATR, and SMA rules to all eligible securities; never start from today's watchlist.

## Acceptable fallback

Starting tomorrow, archive Nasdaq-listed and other-listed directory snapshots daily and retain every file timestamp. This creates valid prospective membership evidence but cannot retroactively repair the existing historical sample. Historical conclusions remain exploratory until a CRSP-equivalent extract is available.
