"""Verify scanner evidence ZIP integrity and bundled regression suites."""
from __future__ import annotations
import csv, hashlib, subprocess, sys, tempfile, zipfile
from pathlib import Path

zip_path=Path(sys.argv[1] if len(sys.argv)>1 else "thinkorswim_scanner_evidence_2026-08-06.zip")
errors=[]
with zipfile.ZipFile(zip_path) as z:
    bad=z.testzip()
    if bad: errors.append(f"ZIP CRC failure: {bad}")
    rows=list(csv.DictReader(z.read("MANIFEST_SHA256.csv").decode("ascii").splitlines()))
    for row in rows:
        try: data=z.read(row["path"])
        except KeyError: errors.append(f"manifest path missing: {row['path']}"); continue
        if len(data)!=int(row["size_bytes"]): errors.append(f"size mismatch: {row['path']}")
        if hashlib.sha256(data).hexdigest().upper()!=row["sha256"]: errors.append(f"hash mismatch: {row['path']}")
    expected={r["path"] for r in rows}|{"MANIFEST_SHA256.csv"}
    extra=set(z.namelist())-expected
    if extra: errors.append("unmanifested ZIP entries: "+", ".join(sorted(extra)))
    with tempfile.TemporaryDirectory() as td:
        z.extractall(td); root=Path(td)
        suites=[root/"logs/test_validate_v4_forward_log.py",
                root/"logs/test_validate_v4_2_intraday_alert_log.py",
                root/"evidence/test_validate_point_in_time_universe.py",
                root/"evidence/test_validate_point_in_time_market_data.py",
                root/"evidence/test_validate_point_in_time_join.py",
                root/"evidence/test_validate_v4_checkpoint_log.py"]
        suites.append(root/"evidence/verify_v4_7_daily_parity.py")
        suites.append(root/"evidence/test_v4_1_manual_sizing.py")
        suites.append(root/"evidence/test_v4_small_account_affordability.py")
        for suite in suites:
            r=subprocess.run([sys.executable,str(suite)],cwd=suite.parent,text=True,capture_output=True)
            print(r.stdout,end="")
            if r.returncode: errors.append(f"regression suite failed: {suite.relative_to(root)}\n{r.stderr}")
        static=list(csv.DictReader((root/"evidence/V4_SCRIPT_STATIC_AUDIT_2026-08-06.csv").open(encoding="utf-8-sig")))
        failed=[r for r in static if r["pass"]!="1"]
        if failed: errors.append(f"static audit has {len(failed)} failed rows")
        v422_text=(root/"scripts/V4_2_2_IntradayConfirm_ChartStudy_EXPERIMENTAL.ts").read_text(encoding="utf-8-sig")
        for token in ("alertConfirmation then pMF[1]", "alertConfirmation then nMF[1]", "lastRingPositiveFlow[1]", "LAST RING MF+"):
            if token not in v422_text: errors.append(f"V4.2.2 missing completed-Ring flow diagnostic: {token}")
        script_files=list((root/"scripts").glob("*.ts"))
        scoped_scripts={r["file"] for r in static}
        if len(script_files)!=14 or len(scoped_scripts)!=14:
            errors.append(f"script/static scope mismatch: files={len(script_files)} scoped={len(scoped_scripts)}")
        readme=(root/"README.md").read_text(encoding="utf-8-sig")
        for token in ("Fourteen-script scoped static audit: 102/102 pass", "nine bundled regression suites pass", "V4.2.2", "has not been live-compiled/applied", "No genuine closed-bar Ring"):
            if token not in readme: errors.append(f"README missing current-state token: {token}")
        matrix=list(csv.DictReader((root/"evidence/SCANNER_COMPLETION_MATRIX_CURRENT.csv").open(encoding="utf-8-sig")))
        matrix_by_requirement={r["requirement"]:r for r in matrix}
        for requirement in ("V4.2.2 no-flow MFI candidate compile/render", "V4.7 daily scan/quote compile and parity", "Account affordability scan/quote compile and parity", "Latest live UI access"):
            if requirement not in matrix_by_requirement: errors.append(f"completion matrix missing: {requirement}")
        if matrix_by_requirement.get("Profitable edge demonstrated",{}).get("status")!="not_demonstrated":
            errors.append("completion matrix must keep profitable edge not_demonstrated")
        live_audit=(root/"evidence/LIVE_AUDIT_2026-08-06.md").read_text(encoding="utf-8-sig")
        if "Continuation audit ?" in live_audit or "?latest V4.2?" in live_audit:
            errors.append("live audit contains damaged punctuation/encoding")
        edge_readme=(root/"historical/v4_oos_edgecase_sensitivity_2026-08-06/README.md").read_text(encoding="utf-8-sig")
        if "today?s" in edge_readme or "rerun ? 2026" in edge_readme:
            errors.append("historical edge-case README contains damaged punctuation/encoding")
        runbook=(root/"evidence/NEXT_SESSION_LIVE_RUNBOOK_CURRENT.md").read_text(encoding="utf-8-sig")
        for token in ("daily Score (0—100)", "confirmation count (0—5)", "threshold-65 install scan", "never reset it to the canonical source default of 60", "V4.2 is the last live-compiled fallback", "MF+`/`MF-` labels", "observation-only unless the sums are independently captured", "entry=0 or spread=0 returns zero shares", "actual receipt time", "never round up", "Do not replace the frozen multi-session exit policy"):
            if token not in runbook: errors.append(f"current runbook missing: {token}")
        frozen_dir=root/"install_current/frozen_core"
        candidate_dir=root/"install_current/candidates_not_live_verified"
        frozen_names={p.name for p in frozen_dir.glob("*.ts")}
        candidate_names={p.name for p in candidate_dir.glob("*.ts")}
        if len(frozen_names)!=7: errors.append(f"frozen install set must contain 7 scripts, got {len(frozen_names)}")
        if len(candidate_names)!=7: errors.append(f"candidate install set must contain 7 scripts, got {len(candidate_names)}")
        if {n for n in frozen_names if "IntradayConfirm" in n}!={"V4_2_IntradayConfirm_ChartStudy_EXPERIMENTAL.ts"}:
            errors.append("frozen install set must have exactly the V4.2 alert study")
        if {n for n in candidate_names if "IntradayConfirm" in n}!={"V4_2_2_IntradayConfirm_ChartStudy_EXPERIMENTAL.ts"}:
            errors.append("candidate install set must have exactly the V4.2.2 alert study")
        forbidden={"V4_2_1_IntradayConfirm_ChartStudy_EXPERIMENTAL.ts", "V4_IntradayConfirm_ChartStudy_v2.ts", "V4_SmallAccountRiskShares_ChartStudy.ts", "V4_EntryConfirmed_Daily_Scan_v2.ts", "V3_EntryConfirmed_Daily_Scan.ts"}
        if forbidden & (frozen_names|candidate_names): errors.append("clean install set contains superseded/combined script")
        reference_names={p.name for p in (root/"install_current/reference_only_do_not_install").glob("*.ts")}
        if reference_names!={"V3_RiskShares_ChartStudy_v2.ts", "V3_EntryConfirmed_Daily_Scan.ts"}:
            errors.append(f"reference-only set mismatch: {sorted(reference_names)}")
        if "V3_RiskShares_ChartStudy_v2.ts" in frozen_names|candidate_names:
            errors.append("chart-close V3 sizing reference must not be installable")
        for name in (frozen_names|candidate_names) & {p.name for p in script_files}:
            install_path=(frozen_dir/name) if name in frozen_names else (candidate_dir/name)
            if install_path.read_bytes()!=(root/"scripts"/name).read_bytes():
                errors.append(f"install/archive hash mismatch: {name}")
        threshold65=frozen_dir/"V3_EntryConfirmed_Daily_Scan_Threshold65_INSTALL.ts"
        canonical=(root/"install_current/reference_only_do_not_install/V3_EntryConfirmed_Daily_Scan.ts")
        if not threshold65.exists(): errors.append("frozen install set missing threshold-65 V3 scan")
        else:
            configured=threshold65.read_text(encoding="utf-8-sig").splitlines()
            source=canonical.read_text(encoding="utf-8-sig").splitlines()
            if not configured or not configured[0].startswith("# INSTALL CONFIG: frozen threshold 65"):
                errors.append("threshold-65 V3 scan missing install header")
            normalized=[line.replace("input scoreThreshold = 65;", "input scoreThreshold = 60;") for line in configured[1:]]
            if normalized!=source: errors.append("threshold-65 V3 scan differs beyond registered default/header")
        install_readme=(root/"install_current/README.md").read_text(encoding="utf-8-sig")
        for token in ("Do not paste every file", "Score 0-100", "Confirmation count 0-5", "frozen 65 default", "do not reset to 60", "reference_only_do_not_install", "Do not install either reference file", "No paper action is allowed until the manual-entry candidate compiles", "never enable both", "blank is unknown", "do not overwrite/pool with V4", "NEXT_SESSION_LIVE_RUNBOOK_CURRENT.md"):
            if token not in install_readme: errors.append(f"install README missing safety instruction: {token}")
if errors:
    print(f"FAIL: {len(errors)} package-verification errors")
    print("\n".join(errors)); raise SystemExit(1)
print(f"PASS: ZIP CRC, {len(rows)} payload hashes, {len(suites)} regression suites, and {len(static)} static checks")
