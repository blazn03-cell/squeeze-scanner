# V4 Ring validator hardening — 2026-08-06

The Ring validator now requires:

- an explicit script version, separate qualifying-bar start/close times, and an exact chart-length span;
- alert receipt no earlier than the close/next-bar evaluation boundary, with observed nonnegative latency recorded in seconds;
- all frozen confirmation gates;
- MFI/RSI above 50 and VWAP distance from 0 through 1 ATR;
- positive/negative MFI flow sums and version-aware MFI arithmetic; a degenerate zero/zero-flow fallback signal may be logged only as a skip, never a paper action;
- nonnegative observed spread, expected slippage, and fees, with spread mandatory for a paper action;
- risk per share equal to entry-minus-stop plus round-trip cost;
- $100-$1,000 account scope, 0.50% risk, and 20% capital cap;
- correct risk-limited, capital-limited, and minimum final whole-share counts;
- zero shares to be skipped;
- one Ring per symbol/session.

**Regression result: 32/32 passed.** Round-trip cost must be at least observed spread + expected slippage + fees. Earliest evaluation boundary is 08:50 CT on 5m or 09:00 CT on 15m; the final boundary is 14:30 CT. Actual audible receipt may be later and is retained as latency rather than rejected. No genuine Ring has been logged, so live alert behavior and profitability remain unproved.
