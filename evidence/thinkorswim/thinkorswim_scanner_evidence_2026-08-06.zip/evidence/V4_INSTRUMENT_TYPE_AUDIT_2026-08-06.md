# V4 instrument-type audit — 2026-08-06

The fresh 34-symbol V3 cohort was reconciled against the official Nasdaq Trader identity snapshot.

- 32/34 were retained by the common-equity/ADR identity prefilter.
- `UGL` and `NVDL` are classified as ETFs by the official directory.
- All nine split-stage V4 candidates (CHD, EXPE, LTM, NWS, SAN, SCHW, SWK, WBS, ZBH) passed the identity prefilter.

This proves the saved V3 universe is **not strictly common equity**, despite its equity workflow label. Leveraged/single-stock ETFs can have different path dependency, volatility, liquidity, and corporate mechanics from common stocks. They must not be mixed into the equity arm without a separately preregistered product-type test.

## Immediate hard gate

Before logging or paper-entering any V4 candidate, reconcile it to the same-day official directory snapshot. Require `identity_eligible=yes`. Skip ETF/ETN, warrant, unit, right, preferred, debt, and test issues. Do not add a hand-picked two-symbol exclusion to thinkScript; that would fail as new products appear.

## Platform limitation

The current thinkScript stages do not expose a reliable general ETF/common-stock classifier. Therefore instrument-type exclusion is a workflow/universe control, not a score component. A future curated point-in-time common-equity watchlist may be used as the Stage-0 scan universe after import-size and symbol-mapping tests.

This finding does not change today's nine V4 candidates, but it narrows the valid population for prospective evidence and prevents product-type contamination.
