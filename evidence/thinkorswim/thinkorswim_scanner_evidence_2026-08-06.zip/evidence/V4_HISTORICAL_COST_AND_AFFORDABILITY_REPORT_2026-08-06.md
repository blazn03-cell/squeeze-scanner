# Historical cost and small-account affordability sensitivity — 2026-08-06

This reuses the archived selected-universe OOS trades (V3: 48; V4: 33), applies symmetric round-trip costs of $0.06/$0.10/$0.25/$0.50 per share, and reconstructs whole-share affordability using the frozen 0.50% risk and 20% capital cap. The model stop distance is recovered from each archived trade's R calculation.

## Most important result

**A $100 account could afford zero of 48 V3 and zero of 33 V4 historical observations at every tested cost.** Under the frozen whole-share risk rules, this scanner currently has no evidenced $100 implementation. Rounding up to one share would violate the registered risk or capital cap.

At $0.06/share total cost:

| Account | V3 affordable | V4 affordable |
|---:|---:|---:|
| $100 | 0/48 (0%) | 0/33 (0%) |
| $250 | 8/48 (16.7%) | 4/33 (12.1%) |
| $500 | 18/48 (37.5%) | 11/33 (33.3%) |
| $1,000 | 39/48 (81.3%) | 28/33 (84.8%) |

At $0.50/share, V4 affordability falls to 0/33, 2/33, 5/33, and 27/33 respectively. Most affordable observations still size to one share.

## Return sensitivity

Across all observations—not just affordable subsets—V4 mean return declines from +1.039% at $0.06/share to +0.233% at $0.50/share. Symbol-cluster 95% intervals include zero at every tested cost. V3 declines from +0.694% to -0.286%; its intervals also include zero.

Affordable-only returns are included in the CSV but are extremely selection-sensitive and based on as few as two observations. They are diagnostics, not an edge estimate.

## Limitations

- The universe is today's selected watchlist tested historically, so selection/survivorship bias remains.
- Costs are scenarios, not historical quote-level spreads.
- Whole-share affordability is evaluated per observation without portfolio overlap/cash reservation.
- Genuine point-in-time membership and delisting-complete market data remain missing.

The result supports risk control, not profitability. For $100, the evidence-based action is **skip**, not loosen the cap or round up.
