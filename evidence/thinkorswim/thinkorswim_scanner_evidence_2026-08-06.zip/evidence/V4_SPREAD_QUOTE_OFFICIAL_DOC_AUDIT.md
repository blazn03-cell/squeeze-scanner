# V4 spread quote official-documentation audit

Official Schwab thinkScript documentation supports the revised architecture:

- Custom Quotes permit direct `bid` and `ask` functions and require exactly one plot: https://toslc.thinkorswim.com/center/howToTos/thinkManual/MarketWatch/Quotes/customquotes
- `bid` returns the current bid in Custom Quotes and cannot be historically indexed: https://toslc.thinkorswim.com/center/reference/thinkScript/Functions/Fundamentals/bid
- `ask` returns the current ask in Custom Quotes and cannot be historically indexed: https://toslc.thinkorswim.com/center/reference/thinkScript/Functions/Fundamentals/ask
- ASK/BID price types used through `close` are limited for non-Forex symbols to intraday intervals no greater than 15 days: https://toslc.thinkorswim.com/center/reference/thinkScript/Functions/Fundamentals/close

Therefore the experimental quote uses direct current `bid`/`ask`, one plot, and no historical indexing. This is static/documentary support only; live compile and arithmetic parity remain required.
