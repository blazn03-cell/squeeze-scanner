import numpy as np, pandas as pd, yfinance as yf
from pathlib import Path
OUT=Path('work/v4_oos_results');OUT.mkdir(parents=True,exist_ok=True)
TICKERS="COO BBWI R NMFC PCOR FF APEI RYTM CACI CQP CWH NPO CRTO MIR RH PNFP ENOV GO BNS FLW LECO LNC PVH RJF SABR ARE GEL HLF HNI BKE IWD PFG PNR SOLV GPN TT DC QUAD PODD BALL CROX HRTG OMF PRIM ASUR CCK FLYW GXO SPY QQQ".split()
def rsi_wilder(c,n=14):
 d=c.diff(); up=d.clip(lower=0); dn=(-d.clip(upper=0)); au=up.ewm(alpha=1/n,adjust=False,min_periods=n).mean(); ad=dn.ewm(alpha=1/n,adjust=False,min_periods=n).mean(); return 100-100/(1+au/ad.replace(0,np.nan))
def features(d):
 c,h,l,v=d.Close,d.High,d.Low,d.Volume
 ema20=c.ewm(span=20,adjust=False).mean(); sma50=c.rolling(50).mean(); sma200=c.rolling(200).mean()
 trend=np.select([(c>ema20)&(ema20>sma50)&(sma50>sma200),(c>ema20)&(ema20>sma50),c>sma50],[100,70,40],default=0)
 prev=c.shift(1); tr=pd.concat([h-l,(h-prev).abs(),(l-prev).abs()],axis=1).max(axis=1); atr=tr.rolling(14).mean()
 prior=h.shift(1).rolling(20).max(); dist=(prior-c)/atr; structure=(100-35*dist).clip(0,100)
 base=v.shift(1).rolling(30).mean(); rv=v/base; participation=(rv/2.5*100).clip(upper=100)
 r5=(h-l).rolling(5).mean(); r20=(h-l).rolling(20).mean(); compression=((1.25-r5/r20)*200).clip(0,100)
 candle=((c-l)/(h-l).replace(0,np.nan)*100).fillna(50).clip(0,100); roc=(c/c.shift(20)-1)*100; momentum=((roc+5)/25*100).clip(0,100)
 av=v.rolling(20).mean(); adv=(c*v).rolling(20).mean(); atrpct=100*atr/c
 # Exact V3 stable-universe defaults.  This was previously only price + ADV,
 # which admitted names that the live two-stage scanner could never see.
 liquid=(c>=5)&(c<=500)&(av>=500_000)&(adv>=20_000_000)&(atrpct>=1)&(atrpct<=8)&(c>sma50)
 raw=.25*trend+.25*structure+.15*participation+.15*compression+.10*candle+.10*momentum
 ext=(c-ema20)/atr; penalty=np.select([ext<=2,ext<=3],[1,.75],default=.5); score=pd.Series(np.where(liquid,raw*penalty,0),index=d.index)
 tp=(h+l+c)/3; mf=tp*v; pos=mf.where(tp>tp.shift(1),0).rolling(14).sum(); neg=mf.where(tp<tp.shift(1),0).rolling(14).sum(); mfi=np.where(neg==0,100,100-100/(1+pos/neg)); mfi=pd.Series(mfi,index=c.index)
 rsi=rsi_wilder(c); mid=c.rolling(20).mean(); sd=c.rolling(20).std(ddof=0); bw=(4*sd)/mid
 ten=(h.rolling(9).max()+l.rolling(9).min())/2; kij=(h.rolling(26).max()+l.rolling(26).min())/2; ca=((ten+kij)/2).shift(26); cb=((h.rolling(52).max()+l.rolling(52).min())/2).shift(26)
 box=h.shift(1).rolling(20).max(); stable=(h.shift(1).rolling(20).max()==h.shift(3).rolling(20).max())
 confirms=((mfi>50)&(mfi>=mfi.shift(1))).astype(int)+(rsi>50).astype(int)+((c>mid)&(bw>bw.shift(1))).astype(int)+((c>pd.concat([ca,cb],axis=1).max(axis=1))&(c>kij)).astype(int)+((c>box)&stable).astype(int)
 return pd.DataFrame(dict(open=d.Open,close=c,high=h,low=l,atr=atr,ema20=ema20,priorHigh=prior,rv=rv,ext=ext,score=score,atrpct=atrpct,universe=liquid,confirms=confirms))
def run(f,arm,max_atr=4.0,min_conf=4):
 ts=[];pos=None;pe=False;px=None
 rows=list(f.itertuples())
 for i,r in enumerate(rows):
  if pe and pos is None and np.isfinite(r.open): pos={'date':r.Index,'entry_raw':r.open,'entry':r.open+.03,'atr':rows[i-1].atr,'bars':0};pe=False
  if px and pos is not None and np.isfinite(r.open):
   ex=r.open-.03; risk=1.5*pos['atr'];ts.append(dict(entry_date=pos['date'],exit_date=r.Index,entry_raw=pos['entry_raw'],exit_raw=r.open,entry=pos['entry'],exit=ex,return_pct=(ex/pos['entry']-1)*100,r_multiple=(ex-pos['entry'])/risk,reason=px));pos=None;px=None
  if pos is not None:
   pos['bars']+=1
   if r.close<=pos['entry']-1.5*pos['atr']:px='ATR Stop'
   elif r.close>=pos['entry']+3*pos['atr']:px='ATR Target'
   elif pos['bars']>=15:px='Time Exit'
   elif r.close<r.ema20:px='EMA Exit'
  elif not pe:
   v3=bool(r.universe) and np.isfinite(r.score) and r.score>=65 and r.close>r.priorHigh and r.rv>=1.2 and r.ext<=3
   ok=v3 if arm=='v3' else v3 and r.atrpct<max_atr and r.confirms>=min_conf
   if ok:pe=True
 return ts
raw=yf.download(TICKERS,start='2021-08-04',end='2026-08-04',auto_adjust=True,group_by='ticker',threads=True,progress=False)
alltr=[]; sens=[]
for t in TICKERS:
 try:
  d=raw[t].dropna(how='all');
  if len(d)<250:continue
  f=features(d);split=int(len(f)*.7);test=f.iloc[split:]
  for arm in ['v3','v4']:
   for z in run(test,arm):alltr.append(dict(ticker=t,arm=arm,**z))
  # Sensitivity is diagnostic only. The preregistered arm remains cap=4/conf=4.
  for cap in [3.0,4.0,5.0]:
   for conf in [3,4,5]:
    for z in run(test,'v4',cap,conf):sens.append(dict(ticker=t,max_atr_pct=cap,min_confirms=conf,**z))
 except Exception as e: print('ERR',t,e)
tr=pd.DataFrame(alltr);tr.to_csv(OUT/'trades.csv',index=False)
sens=pd.DataFrame(sens);sens.to_csv(OUT/'sensitivity_trades.csv',index=False)
rng=np.random.default_rng(7);rows=[]
for arm,g in tr.groupby('arm'):
 x=g.return_pct.to_numpy()/100; boots=np.array([rng.choice(x,len(x),replace=True).mean() for _ in range(5000)]);gw=x[x>0].sum();gl=-x[x<0].sum()
 rows.append(dict(arm=arm,trades=len(x),symbols=g.ticker.nunique(),win_rate=(x>0).mean()*100,mean_return_pct=x.mean()*100,profit_factor=gw/gl,ci_low=np.quantile(boots,.025)*100,ci_high=np.quantile(boots,.975)*100))
summary=pd.DataFrame(rows);summary.to_csv(OUT/'summary.csv',index=False);print(summary.to_string(index=False))

# Cost sensitivity. bps is charged on both entry and exit. The 0.03/share
# row reproduces the preregistered approximation used in the primary summary.
cost_rows=[]
for arm,g in tr.groupby('arm'):
 for label,bps,fixed in [('gross',0,0),('5bps_side',5,0),('10bps_side',10,0),('25bps_side',25,0),('fixed_0.03_side',0,.03)]:
  ent=g.entry_raw*(1+bps/10000)+fixed; ex=g.exit_raw*(1-bps/10000)-fixed
  x=(ex/ent-1)*100
  cost_rows.append(dict(arm=arm,cost_model=label,trades=len(x),win_rate=(x>0).mean()*100,mean_return_pct=x.mean(),total_compounded_pct=(np.prod(1+x/100)-1)*100))
pd.DataFrame(cost_rows).to_csv(OUT/'cost_sensitivity.csv',index=False)

# Concentration audit: remove each symbol and recompute mean. Large swings
# indicate that the aggregate result depends on a small number of names.
loo=[]
for arm,g in tr.groupby('arm'):
 for ticker in sorted(g.ticker.unique()):
  x=g.loc[g.ticker!=ticker,'return_pct']
  loo.append(dict(arm=arm,removed_ticker=ticker,trades=len(x),mean_return_pct=x.mean(),delta_vs_full_pct=x.mean()-g.return_pct.mean()))
pd.DataFrame(loo).to_csv(OUT/'leave_one_symbol_out.csv',index=False)

# Cluster bootstrap by symbol (not by trade) retains within-symbol dependence.
cb=[]
for arm,g in tr.groupby('arm'):
 syms=np.array(sorted(g.ticker.unique())); vals=[]
 for _ in range(5000):
  picked=rng.choice(syms,len(syms),replace=True)
  sample=pd.concat([g.loc[g.ticker==s,'return_pct'] for s in picked],ignore_index=True)
  vals.append(sample.mean())
 cb.append(dict(arm=arm,symbols=len(syms),cluster_ci_low=np.quantile(vals,.025),cluster_ci_high=np.quantile(vals,.975)))
pd.DataFrame(cb).to_csv(OUT/'symbol_cluster_bootstrap.csv',index=False)

# Parameter-grid stability. This does not authorize choosing the best cell
# after seeing results; it tests whether the frozen 4/4 result is isolated.
sr=[]
for (cap,conf),g in sens.groupby(['max_atr_pct','min_confirms']):
 x=g.return_pct.to_numpy(); syms=np.array(sorted(g.ticker.unique())); vals=[]
 for _ in range(2000):
  picked=rng.choice(syms,len(syms),replace=True)
  vals.append(pd.concat([g.loc[g.ticker==s,'return_pct'] for s in picked],ignore_index=True).mean())
 sr.append(dict(max_atr_pct=cap,min_confirms=conf,trades=len(g),symbols=len(syms),win_rate=(x>0).mean()*100,mean_return_pct=x.mean(),cluster_ci_low=np.quantile(vals,.025),cluster_ci_high=np.quantile(vals,.975)))
pd.DataFrame(sr).to_csv(OUT/'parameter_sensitivity.csv',index=False)
