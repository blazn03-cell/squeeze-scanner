# Oscillator edge-case sensitivity rerun — 2026-08-06

**Conclusion: no trade membership changed, and no edge was demonstrated.**

Two formula edge cases were audited:

1. The Python RSI approximation returned missing when average loss was zero; thinkorswim-style handling should return 100 when gains are positive, 0 when losses are positive, and 50 when both are zero.
2. The current thinkScript MFI returns 100 when both positive and negative money flow are zero. A neutral sensitivity variant returns 50 for that no-flow case while retaining 100 for positive-only flow.

- Original trades: 81
- Edge-case sensitivity trades: 81
- Added trade keys: 0
- Removed trade keys: 0

- V3 mean return: original 0.693606% vs sensitivity 0.693607%
- V3 sensitivity 95% trade bootstrap CI: -1.605% to 3.169% (includes zero)
- V4 mean return: original 1.039007% vs sensitivity 1.039008%
- V4 sensitivity 95% trade bootstrap CI: -1.575% to 3.930% (includes zero)

The rerun again uses today's selected ticker universe and Yahoo-adjusted history, so it does not repair selection/survivorship bias. Yahoo reported FLW as unavailable on the rerun; FLW supplied zero trades in both the archived and rerun outputs. The neutral no-flow MFI rule is therefore only a candidate for a future preregistered version, not a proven improvement and not a silent change to the frozen V4 arm.
