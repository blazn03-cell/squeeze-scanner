﻿# V4 historical parity audit — 2026-08-06

## Result
After adding the exact V3 stable-universe defaults (price $5–$500, 20-day average volume >=500,000, average dollar volume >=$20M, model ATR% 1–8, and close above SMA50), the current-watchlist historical approximation produced:

| Arm | Trades | Symbols | Win rate | Mean/trade after $0.03/share each side | Trade-bootstrap 95% CI |
|---|---:|---:|---:|---:|---:|
| V3 | 48 | 22 | 43.75% | 0.694% | -1.605% to 3.169% |
| V4 | 33 | 20 | 48.48% | 1.039% | -1.575% to 3.930% |

The symbol-cluster bootstrap was also inconclusive: V3 -2.079% to 2.988%; V4 -1.698% to 3.755%. Both include zero.

## Cost sensitivity
The mean remained positive in this sample through 25 bps per side, but compounded V3 performance was almost erased at that cost. This is not proof that live fills will match the model.

## Concentration warning
Removing PRIM changed mean return by -0.944 percentage points for V3 and -1.011 points for V4. V3 became negative without PRIM. This is strong evidence of small-sample/name concentration.

## Important limitations
- The universe is derived from today's watchlist, so selection and survivorship bias remain.
- The final 30% of each symbol's available history is chronological, but this is not a point-in-time-universe test.
- Yahoo adjusted daily bars cannot reproduce thinkorswim scans, corporate actions, spreads, alerts, or intraday order paths exactly.
- Stops and targets are evaluated on closes and executed at the next open; gap and intrabar behavior are approximated.
- FLW had no data and was omitted.
- Results do not demonstrate a profitable edge. Both ordinary and symbol-cluster confidence intervals include zero.

## Decision
Keep V4 paper-only. The new confirmation layer may improve risk selection, but promotion requires prospective logs, reproducible live scan/quote parity, and confidence intervals excluding zero after costs.

## Parameter sensitivity update
A diagnostic 3x3 grid tested ATR caps 3/4/5% against minimum confirmation counts 3/4/5. This is robustness analysis, not permission to optimize after observing results.

- Frozen 4%/4 arm: 33 trades, 20 symbols, +1.039% mean; symbol-cluster CI -1.821% to +3.775%.
- 3%/4: 22 trades, 14 symbols, +1.711% mean; CI -0.386% to +4.560%.
- 4%/5 and 5%/5 were negative in this biased sample, with only 15–16 trades. This suggests requiring all five confirmations may be too restrictive and concentrated, not that a looser threshold is proven superior.
- Eight of nine grid cells had intervals that included zero or were negative. No alternative cell establishes an edge.

Decision: keep the preregistered 4%/4 paper arm unchanged. Do not select 3%/3 or 3%/4 based on this sample. Test any future parameter change as a separately registered arm.
