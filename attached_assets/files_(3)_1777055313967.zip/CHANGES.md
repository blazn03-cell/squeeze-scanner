# Scanner v3 — Ichimoku + COIN FLIP

## Three asks, three fixes

### 1. Conflict verdict → COIN FLIP
Conflict between tech and macro no longer says "CASH" (which implied avoidance). Now says **COIN FLIP · 50%** — captures the reality that tech and macro are split and you genuinely can't tell which wins. Framework memory updated to match.

Full verdict state machine:
| Tech (Ichimoku) | Macro (Tide) | Verdict | Conf |
|---|---|---|---|
| BULLISH | BULLISH | **CALLS** | 50-95% (Ichimoku strength × winProb) |
| BEARISH | BEARISH | **PUTS** | 50-95% (Ichimoku strength × winProb) |
| BULLISH | BEARISH | **COIN FLIP** | 50% (conflict) |
| BEARISH | BULLISH | **COIN FLIP** | 50% (conflict) |
| NEUTRAL | anything | **CASH** | 50% (price inside cloud = no trend) |
| anything | NEUTRAL | **CASH** | 50% (no tide = no tailwind) |
| No Ichimoku data | — | **PENDING** | — (waits for next scan) |

### 2. Full Ichimoku cloud + math
New client-side function `computeIchimoku(bars)` runs on 5-minute OHLC bars fetched from `/api/stock/{ticker}/ohlc/5m`. Calculates:

- **Tenkan-sen** (9-period conversion line) — (9p high + 9p low) / 2
- **Kijun-sen** (26-period base line) — (26p high + 26p low) / 2
- **Senkou Span A** (leading edge) — (Tenkan + Kijun) / 2
- **Senkou Span B** (trailing edge, 52-period) — (52p high + 52p low) / 2
- **Chikou Span** confirmation — close vs 26 bars ago
- **TK Cross** detection — bullish/bearish crossover between Tenkan and Kijun
- **Price zone** — above / inside / below the cloud
- **Cloud color** — green (Span A > Span B) or red (Span B > Span A)

Bias synthesis follows standard Ichimoku rules:
- Above green cloud + T > K → **BULLISH STRONG**
- Above green cloud + T flat → BULLISH MODERATE
- Above red cloud → BULLISH WEAK (recovery, not trend)
- Below red cloud + T < K → **BEARISH STRONG**
- Below red cloud + T flat → BEARISH MODERATE
- Below green cloud → BEARISH WEAK (pullback)
- Inside cloud → **NEUTRAL TRANSITION** (no trend — wait for break)

New **ICHIMOKU section** in each expanded card shows:
- Bias + Strength header in big letters (BULLISH STRONG / etc)
- Plain-English summary of what the cloud is telling you
- All 4 components as number tiles (Tenkan / Kijun / Span A / Span B)
- Three-panel read: Price vs Cloud · TK Cross · Chikou confirmation

### 3. Bias removal
The fake "TECH BIAS = squeeze-bullish / flush-bearish" mapping is gone. A squeeze signal doesn't automatically mean bullish — the stock could be near major resistance. Now Ichimoku decides, which is the actual chart read.

Macro bias (from UW market tide) stays because it's a separate data source — the aggregate direction of call vs put premium across the market.

The old `TECH BIAS · IV RANK · MACRO` 3-column strip is replaced by:
- Full Ichimoku section (big, front and center)
- Compact `MACRO · IV RANK · SUGGESTED STRATEGY` strip below it

## Architecture notes

**OHLC fetch scope:** Top 12 tickers by premium get 5m OHLC (400 bars ≈ 5 trading days). Tickers ranked 13+ show "PENDING" until they make the top cut. If you want broader coverage, bump `ohlcTickers = sortedTickers.slice(0, 12)` in `fetchUWDirect`.

**Token efficiency:** Ichimoku is stripped from the Claude payload before classification — Claude doesn't need it, and OHLC data is heavy. Ichimoku is attached to signals post-classification client-side.

**Cost impact:** +12 parallel OHLC fetches to UW per scan. OHLC endpoint is light; scan time impact is negligible thanks to `Promise.all`. UW API cost per your existing paid tier — no new charges.

**Graceful degradation:** If UW OHLC returns fewer than 55 bars (insufficient for Ichimoku math), `computeIchimoku` returns null and the ticker shows "No 5m OHLC data — PENDING" with a clear explanation.

**Bar shape handling:** UW OHLC responses vary slightly — code normalizes `{open, high, low, close, start_time}` vs `{o, h, l, c, t}` vs `{timestamp}`. If you see "PENDING" on tickers that should have data, check browser console for malformed OHLC responses and tell me what fields they use.

## Memory updated

Your saved framework rule now reads:
> Tech bias from Ichimoku cloud on 5m bars (not squeeze/flush category). Bullish tech + Bullish macro = CALLS full size. Bearish tech + Bearish macro = PUTS full size. Conflict = COIN FLIP at 50% confidence. Tech or macro NEUTRAL = CASH. No Ichimoku data = PENDING.

## To deploy

Same as before:
```bash
cp /path/to/new/index.html ./index.html
git add index.html
git commit -m "v3: ichimoku engine + COIN FLIP for conflict"
git push
```

## What I still didn't build

- **TTM Squeeze / Schaff Trend Cycle / MFI** (the other indicators on your VZ chart). Ichimoku is the directional anchor; these are momentum confirmers. If you want them added as supporting signals to raise/lower verdict confidence, easy — just say.
- **Cloud visualization** (actual chart). Numbers are there. If you want a mini SVG of price-vs-cloud rendered inline, I'll wire it up.
- **Deeper timeframes** (15m / 1h / daily Ichimoku for longer holds). Currently 5m only since that matched your chart.

## Known concerns to watch for on first run

1. **OHLC endpoint response shape.** I built against the standard `{open, high, low, close, start_time}` schema that matches UW's documented OHLC crypto endpoint and the API reference. If stock OHLC uses different field names, Ichimoku won't compute and you'll see all PENDING. Fix is trivial — one line in `computeIchimoku`. Report what you see.

2. **`5m` candle_size literal.** Based on UW docs convention. If they use `"5min"` or `"5"` instead, URL returns empty data. Same quick fix.

3. **Bar ordering.** UW typically returns newest-first. Code sorts ascending before computing. If ordering is already ascending you'll see a mild inefficiency (redundant sort) but correctness holds.
